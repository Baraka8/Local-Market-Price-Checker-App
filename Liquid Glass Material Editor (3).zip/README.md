
  # Liquid Glass Material Editor

  This is a code bundle for Liquid Glass Material Editor. The original project is available at https://www.figma.com/design/ahujpcoBGdBxnQqUc9qrCI/Liquid-Glass-Material-Editor.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  