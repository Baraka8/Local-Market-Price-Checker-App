# Price Submission & Approval Flow

## Complete End-to-End Flow

### 1️⃣ **Vendor Submits a Price**

**Location:** Vendor Dashboard → Submit Price Tab

**Steps:**
1. Login as a Vendor (any email, select "🏪 Vendor" role)
2. Go to "Submit Price" tab (default tab)
3. Fill in the form:
   - Select Category (e.g., "Vegetables")
   - Select Product (e.g., "Tomatoes")
   - Select Market Location (e.g., "Kimironko Market")
   - Enter Price (e.g., "800")
   - Enter Quantity (default is 1)
4. Click "Submit Price"

**What Happens:**
- ✅ A new `PriceSubmission` object is created with status "pending"
- ✅ The submission is added to `globalPriceSubmissions` array
- ✅ A notification is created for the admin
- ✅ Vendor sees a success toast message
- ✅ Form resets after 2 seconds

---

### 2️⃣ **Admin Receives Notification**

**Location:** Admin Dashboard

**What Happens:**
- 🔔 The "Price Approvals" tab shows a red badge with the number of pending submissions
- 🔔 The "Notifications" tab also shows a red badge
- 🔔 Admin can click on "Notifications" to see the details:
  - "New Price Submission"
  - "VendorName submitted ProductName at MarketName for Price RWF"

---

### 3️⃣ **Admin Reviews & Approves/Rejects**

**Location:** Admin Dashboard → Price Approvals Tab (First Tab)

**What Admin Sees:**
- 📊 Statistics cards showing:
  - Pending count
  - Approved today
  - Rejected today
  - Total submissions

- 🔍 Search bar to search by product, market, or vendor
- 🔘 Filter buttons: All, Pending, Approved, Rejected (default: Pending)

- 📋 List of price submissions, each showing:
  - Product name
  - Market location
  - Vendor name
  - Submission age (color-coded: green <24h, yellow <48h, red >48h)
  - Price in large text
  - Status badge (Pending/Approved/Rejected)

**Admin Actions:**
For each pending submission, admin can:
- ✅ Click "✓ Approve" button (green) → Approves the price
  - Status changes to "approved"
  - Toast notification: "Price for [Product] has been approved!"
  - Action buttons disappear

- ❌ Click "✗ Reject" button (red) → Rejects the submission
  - Status changes to "rejected"
  - Toast notification: "Price for [Product] has been rejected."
  - Action buttons disappear

---

## Testing the Complete Flow

### Test Scenario:

1. **Open two browser windows/tabs**
   - Window 1: Login as Vendor
   - Window 2: Login as Admin

2. **In Vendor Window:**
   - Go to "Submit Price" tab
   - Select: Vegetables → Tomatoes → Kimironko Market
   - Enter Price: 850
   - Click "Submit Price"

3. **In Admin Window:**
   - The "Price Approvals" tab badge should update (showing the new pending count)
   - You'll see the new submission appear in the list:
     - Product: Tomatoes
     - Market: Kimironko Market
     - Vendor: [Your vendor name]
     - Price: 850 RWF per kg
     - Age: 0h ago (green)
   - Click "✓ Approve" to approve it

4. **Result:**
   - Submission status changes to "approved"
   - Toast notification appears
   - The approve/reject buttons disappear

---

## Current Implementation Details

### Data Storage:
- **globalPriceSubmissions**: Array in `/App.tsx` that stores all vendor submissions
- **globalNotifications**: Array in `/App.tsx` that stores all notifications
- **Mock Data**: Initial submissions in `/lib/mockData.ts` for demo purposes

### Real-Time Updates:
- Admin dashboard polls every 500ms to check for new submissions
- Notification badge updates every 1000ms
- This simulates real-time updates (in production, use WebSockets or Server-Sent Events)

### Components Involved:
1. **SubmitPrice.tsx** - Vendor submission form
2. **PriceApprovals.tsx** - Admin approval interface
3. **NotificationManagement.tsx** - Admin notifications view
4. **App.tsx** - Global state management

---

## Mock Data Available

There are **6 pending submissions** already in the system for testing:
1. Rice (Local) - Kimironko Market - 1,200 RWF
2. Tomatoes - Nyabugogo Market - 800 RWF
3. Beans - Kimisagara Market - 1,100 RWF
4. Bananas - Nyabugogo Market - 3,000 RWF
5. Chicken (Whole) - Kimironko Market - 5,500 RWF
6. Cooking Oil - Kicukiro Market - 4,200 RWF

You can approve or reject these immediately when you login as admin!
