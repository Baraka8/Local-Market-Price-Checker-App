# 🔧 TROUBLESHOOTING GUIDE

## ❌ AUTHENTICATION ERRORS

### **Error: "Invalid login credentials"**

**What it means:** The email/password combination doesn't match any account in the database.

**Solutions:**
1. ✅ **Create account first** - Click "Sign Up" and create an account before trying to login
2. ✅ **Check spelling** - Make sure email and password are typed correctly
3. ✅ **Use correct password** - If you changed your password, use the new one
4. ✅ **Wait after signup** - Give it 1-2 seconds after creating account before signing in
5. ✅ **Try a new email** - If all else fails, create account with different email

**Quick Fix:**
```
1. Go to Sign Up page
2. Create account: test@example.com / test123
3. Wait for success message
4. Auto-login should work
5. If not, manually sign in with same credentials
```

---

### **Error: "No session returned"**

**What it means:** Login succeeded but session wasn't created properly.

**Solutions:**
1. ✅ **Refresh the page** - Browser needs to reload with new session
2. ✅ **Clear cookies** - Old cookies might be interfering
3. ✅ **Try incognito mode** - Tests without cached data
4. ✅ **Check Supabase connection** - Make sure you connected your project

**Quick Fix:**
```
1. Press Ctrl+Shift+Delete (Clear browsing data)
2. Select "Cookies and site data"
3. Click "Clear data"
4. Refresh page
5. Try logging in again
```

---

### **Error: "Failed to fetch profile"**

**What it means:** Account exists but profile data is missing or corrupted.

**Solutions:**
1. ✅ **Create account through Sign Up** - Don't manually add to database
2. ✅ **Wait and retry** - Sometimes backend needs a moment
3. ✅ **Check backend logs** - Look in browser console (F12)
4. ✅ **Recreate account** - Delete and create new account

**Quick Fix:**
```
1. Open browser console (F12)
2. Look for detailed error message
3. If "user:undefined", account wasn't created properly
4. Create new account with different email
```

---

### **Error: "User already registered"**

**What it means:** This email is already taken.

**Solutions:**
1. ✅ **Sign in instead** - Click "Already have account? Sign In"
2. ✅ **Use different email** - Try another email address
3. ✅ **Reset password** - (Feature coming soon)

**Quick Fix:**
```
1. Click "Already have an account? Sign In"
2. Enter existing credentials
3. If you forgot password, create new account with different email
```

---

## 🔐 PASSWORD ERRORS

### **Error: "Current password is incorrect"**

**What it means:** When changing password, the current password you entered is wrong.

**Solutions:**
1. ✅ **Double-check spelling** - Make sure you're typing correctly
2. ✅ **Use the password you login with** - It's your current password
3. ✅ **Logout and login** - Verify your current password first

**Quick Fix:**
```
1. Click Cancel on password dialog
2. Logout
3. Try logging in with what you think is your password
4. If it works, that's your current password
5. Go back to change password with correct current password
```

---

### **Error: "New passwords do not match"**

**What it means:** The "New Password" and "Confirm Password" fields don't match.

**Solutions:**
1. ✅ **Type carefully** - Make sure both are identical
2. ✅ **Copy/paste** - Type once, then copy to confirm field
3. ✅ **Check caps lock** - Passwords are case-sensitive

---

### **Error: "Password must be at least 6 characters"**

**What it means:** Your new password is too short.

**Solutions:**
1. ✅ **Use longer password** - At least 6 characters
2. ✅ **Mix characters** - Use letters and numbers (e.g., "pass123")

---

## 💾 DATABASE ERRORS

### **Error: "Failed to submit price"**

**What it means:** Price submission to backend failed.

**Solutions:**
1. ✅ **Check login** - Make sure you're logged in as Vendor
2. ✅ **Fill all fields** - Product, market, price, quantity, unit
3. ✅ **Use valid numbers** - Price and quantity must be positive numbers
4. ✅ **Try again** - Could be temporary network issue

**Quick Fix:**
```
1. Refresh the page
2. Make sure you're logged in
3. Fill out form completely
4. Submit again
```

---

### **Error: "Failed to approve submission"**

**What it means:** Admin can't approve the vendor's price submission.

**Solutions:**
1. ✅ **Check admin role** - Only admins can approve
2. ✅ **Submission exists** - Make sure submission wasn't deleted
3. ✅ **Refresh page** - Get latest data
4. ✅ **Try again** - Click approve again

---

### **Error: "Failed to update profile"**

**What it means:** Profile changes couldn't be saved.

**Solutions:**
1. ✅ **Check all fields** - Make sure name and email are filled
2. ✅ **Use valid email** - Must be proper email format
3. ✅ **Stay logged in** - Don't logout while saving
4. ✅ **Try again** - Network might have hiccuped

---

## 👥 USER MANAGEMENT ERRORS

### **Error: "Only admins can view all users"**

**What it means:** You're trying to access admin-only features.

**Solutions:**
1. ✅ **Login as admin** - Must have admin role
2. ✅ **Check your role** - Profile shows current role
3. ✅ **Contact admin** - Ask admin to change your role

---

### **Error: "Failed to update user role"**

**What it means:** Admin couldn't change someone's role.

**Solutions:**
1. ✅ **Refresh page** - Get latest user data
2. ✅ **Try again** - Click update role again
3. ✅ **Check user exists** - User might have been deleted

---

### **Error: "Failed to delete user"**

**What it means:** Couldn't remove user from system.

**Solutions:**
1. ✅ **Confirm deletion** - Make sure you clicked confirm
2. ✅ **User isn't you** - Can't delete yourself
3. ✅ **Try again** - Network issue might have occurred

---

## 🔍 SEARCH & FILTER ERRORS

### **Problem: No results found**

**What it means:** Search/filter didn't match any items.

**Solutions:**
1. ✅ **Check spelling** - Make sure search term is correct
2. ✅ **Clear filters** - Remove filters and search again
3. ✅ **Try broader search** - Use fewer keywords
4. ✅ **Data might not exist** - Add data first (vendors, prices, etc.)

---

### **Problem: Filter not working**

**What it means:** Selecting filter doesn't change results.

**Solutions:**
1. ✅ **Refresh page** - Reload to get latest data
2. ✅ **Clear all filters** - Reset to default
3. ✅ **Try different filter** - Test other filters

---

## 📊 PRICE DISPLAY ERRORS

### **Problem: Prices not updating after approval**

**What it means:** Consumer sees old prices after admin approved new ones.

**Solutions:**
1. ✅ **Refresh the page** - Browser might have cached old data
2. ✅ **Check approval** - Make sure admin actually clicked "Approve"
3. ✅ **Check market** - Make sure you're looking at same market
4. ✅ **Wait a moment** - Give database 2-3 seconds to update

**Quick Fix:**
```
1. Press F5 to refresh
2. Search for product again
3. Should show updated price
```

---

### **Problem: Price shows 0 or undefined**

**What it means:** Price data is missing or corrupted.

**Solutions:**
1. ✅ **No price submitted yet** - Vendor needs to submit price first
2. ✅ **Admin hasn't approved** - Wait for admin approval
3. ✅ **Wrong market selected** - Change to market with prices

---

## 🔔 NOTIFICATION ERRORS

### **Problem: Not receiving notifications**

**What it means:** Expected notification didn't appear.

**Solutions:**
1. ✅ **Refresh page** - Notifications load on page load
2. ✅ **Check role** - Notifications are role-specific
3. ✅ **Wait a moment** - Can take 5-10 seconds to appear
4. ✅ **Check notification tab** - Go to Notifications page

---

### **Problem: Notification count wrong**

**What it means:** Badge shows incorrect number.

**Solutions:**
1. ✅ **Mark as read** - Read notifications to clear count
2. ✅ **Refresh page** - Update count
3. ✅ **Multiple unread** - Count shows all unread notifications

---

## 🌐 LANGUAGE ERRORS

### **Problem: Language not changing**

**What it means:** UI still shows in wrong language.

**Solutions:**
1. ✅ **Click language switcher** - Top right corner
2. ✅ **Select desired language** - EN/RW/FR
3. ✅ **Refresh page** - Some text might need reload
4. ✅ **Clear cache** - Browser might have cached old translations

---

### **Problem: Text shows in English**

**What it means:** Some strings don't have translations yet.

**Solutions:**
1. ✅ **This is expected** - Some text remains in English
2. ✅ **Core features translated** - Main UI is translated
3. ✅ **Error messages** - Some errors might be English only

---

## 🖼️ IMAGE UPLOAD ERRORS

### **Error: "Failed to upload image"**

**What it means:** Price tag image couldn't be uploaded.

**Solutions:**
1. ✅ **Check file size** - Must be under 5MB
2. ✅ **Use supported format** - JPG, PNG, or WebP
3. ✅ **Image is optional** - Skip image and submit anyway
4. ✅ **Try smaller image** - Compress or resize image

---

## 📥 EXPORT ERRORS

### **Problem: Export not downloading**

**What it means:** Data export didn't create file.

**Solutions:**
1. ✅ **Check browser settings** - Allow downloads
2. ✅ **Disable popup blocker** - Might be blocking download
3. ✅ **Try different format** - Try CSV instead of PDF
4. ✅ **Check if data exists** - Need data to export

---

## 💻 BROWSER ERRORS

### **Problem: Page won't load**

**What it means:** App isn't rendering properly.

**Solutions:**
1. ✅ **Hard refresh** - Ctrl+F5 (Windows) or Cmd+Shift+R (Mac)
2. ✅ **Clear cache** - Clear browser cache and cookies
3. ✅ **Try different browser** - Chrome, Firefox, Safari, Edge
4. ✅ **Check internet** - Make sure you're connected

---

### **Problem: Buttons not working**

**What it means:** Clicks aren't doing anything.

**Solutions:**
1. ✅ **Wait for loading** - Page might still be loading
2. ✅ **Refresh page** - Reload to reset state
3. ✅ **Check console** - Open DevTools (F12) for errors
4. ✅ **Try different button** - Test if other buttons work

---

### **Problem: Styling looks broken**

**What it means:** CSS isn't loading properly.

**Solutions:**
1. ✅ **Hard refresh** - Ctrl+F5 to reload styles
2. ✅ **Clear cache** - Remove cached stylesheets
3. ✅ **Check browser** - Update to latest version
4. ✅ **Zoom level** - Reset browser zoom to 100%

---

## 🔄 SESSION ERRORS

### **Problem: Keeps logging out**

**What it means:** Session isn't persisting.

**Solutions:**
1. ✅ **Enable cookies** - Browser must allow cookies
2. ✅ **Don't use private mode** - Session won't persist in incognito
3. ✅ **Check expiry** - Sessions expire after 1 hour (Supabase default)
4. ✅ **Stay on same domain** - Don't switch domains

---

### **Problem: "Not authenticated" error**

**What it means:** Action requires login but session is missing.

**Solutions:**
1. ✅ **Login again** - Session might have expired
2. ✅ **Refresh page** - Reload session
3. ✅ **Clear cookies and login** - Fresh start

---

## 🚨 EMERGENCY FIXES

### **Nothing is working!**

**Nuclear option - Complete reset:**
```
1. Logout from app
2. Close all browser tabs
3. Press Ctrl+Shift+Delete
4. Clear cookies and cache
5. Close browser completely
6. Reopen browser
7. Go back to app
8. Create new account
9. Test basic features
10. Should work now!
```

---

### **Can't access admin features**

**Solution:**
```
1. Create new account
2. Select "⚙️ System Admin" role during signup
3. Login with admin credentials
4. Access admin features
```

---

### **Database seems corrupted**

**Solution:**
```
1. This is rare with Supabase
2. Refresh page multiple times
3. Logout and login
4. If persists, contact Supabase support
5. Or create fresh Supabase project
```

---

## 📞 GETTING HELP

### **Before asking for help:**
1. ✅ Read this troubleshooting guide
2. ✅ Check browser console for errors (F12)
3. ✅ Try the quick fixes listed above
4. ✅ Test in different browser
5. ✅ Clear cache and cookies

### **When reporting an issue:**
Include:
- What you were trying to do
- What error message you saw
- Which role you're logged in as
- Browser and version
- Screenshot of error (if possible)
- Console error messages (F12 → Console tab)

---

## ✅ VERIFICATION CHECKLIST

**Before reporting a bug, verify:**

- [ ] I created an account (didn't skip signup)
- [ ] I'm using correct email and password
- [ ] I refreshed the page
- [ ] I cleared browser cache
- [ ] I checked I'm logged in as correct role
- [ ] I read the error message carefully
- [ ] I tried the quick fix for this error
- [ ] I'm using a modern browser (Chrome, Firefox, Safari, Edge)
- [ ] My internet connection is stable
- [ ] I waited a few seconds (network might be slow)

---

## 🎯 MOST COMMON FIXES

**90% of issues are solved by:**

1. **Creating account first** - Don't try to login without signing up
2. **Refreshing the page** - Press F5
3. **Clearing browser cache** - Ctrl+Shift+Delete
4. **Waiting after signup** - Give it 1-2 seconds before login
5. **Using correct credentials** - Double-check email/password

---

## 💡 PRO TIPS

### **Tip 1: Use Browser DevTools**
Press F12 to see detailed errors. Look in Console tab.

### **Tip 2: Test in Incognito**
Opens fresh session without cached data. Good for testing.

### **Tip 3: Keep Admin Account**
Always have a working admin account for testing and recovery.

### **Tip 4: Use Test Credentials**
Create test@example.com accounts for easy testing.

### **Tip 5: Document What Works**
Keep note of working credentials and test flows.

---

## 📚 RELATED DOCUMENTATION

- `/TESTING_GUIDE.md` - Full testing instructions
- `/BONUS_FEATURES.md` - Feature documentation
- `/DATABASE_IMPLEMENTATION.md` - Technical details
- `/COMPLETE_FEATURE_LIST.md` - Feature overview

---

## 🎉 SUCCESS INDICATORS

**You'll know it's fixed when:**
- ✅ Can create account
- ✅ Can login with credentials
- ✅ Dashboard loads correctly
- ✅ Features work as expected
- ✅ No error messages
- ✅ Changes persist on refresh

---

**Still having issues?** Check the browser console (F12) for detailed error messages. Most problems are simple fixes related to authentication or caching.

**Happy Troubleshooting!** 🔧