# 🚀 START HERE - First Time Setup

## ❌ SEEING "Invalid login credentials"?

**This is NORMAL for a fresh installation!**

### **Why this happens:**
- ✅ Your database is empty (no accounts yet)
- ✅ You need to CREATE an account first
- ✅ THEN you can login

---

## 🎯 3 SIMPLE STEPS TO GET STARTED

### **STEP 1: Click "Sign Up" ✨**

On the login page, you'll see:
```
[Already have an account? Sign In]
      ⬇️
Don't have an account? Sign Up  ← CLICK THIS!
```

---

### **STEP 2: Fill Out the Form 📝**

```
Full Name: [Your Name]
Email: [your.email@example.com]
Password: [min 6 characters]
Role: [Choose one: Admin, Vendor, Business, Consumer]
```

**Example:**
```
Full Name: Admin User
Email: admin@test.com
Password: admin123
Role: ⚙️ System Admin
```

---

### **STEP 3: Click "Create Account" 🎉**

- ✅ Account will be created
- ✅ You'll be auto-logged in
- ✅ Dashboard will appear!

**Total time: 30 seconds!**

---

## 🎊 THAT'S IT!

You're now ready to use the app!

---

## 📋 CREATE MULTIPLE TEST ACCOUNTS

### **Recommended Setup:**

#### **1. Admin Account** 👨‍💼
```
Click "Sign Up"
Name: Admin User
Email: admin@test.com
Password: admin123
Role: ⚙️ System Admin
→ Create Account
```

#### **2. Vendor Account** 🏪
```
Logout (or use incognito window)
Click "Sign Up"
Name: Vendor User
Email: vendor@test.com
Password: vendor123
Role: 🏪 Vendor
→ Create Account
```

#### **3. Business Account** 💼
```
Logout
Click "Sign Up"
Name: Business Owner
Email: business@test.com
Password: business123
Role: 💼 Small Business Owner
→ Create Account
```

#### **4. Consumer Account** 👤
```
Logout
Click "Sign Up"
Name: Consumer User
Email: consumer@test.com
Password: consumer123
Role: 👤 Consumer
→ Create Account
```

---

## 💡 UNDERSTANDING THE ERRORS

### **"Invalid login credentials"**
```
❌ PROBLEM: Trying to login without creating account
✅ SOLUTION: Click "Sign Up" first!
```

### **"User already registered"**
```
❌ PROBLEM: Email already exists
✅ SOLUTION: Page auto-switches to Sign In - just add password!
```

### **"No session returned"**
```
❌ PROBLEM: Backend hiccup
✅ SOLUTION: Refresh page and try again
```

---

## 🔄 THE LOGIN FLOW

```
┌─────────────────────────────────────┐
│     First Time User (You!)          │
└─────────────────┬───────────────────┘
                  │
                  ▼
         ┌────────────────┐
         │  Login Page    │
         └────────┬───────┘
                  │
                  ▼
         ┌────────────────┐
    ┌───│ Try to Sign In?│───┐
    │   └────────────────┘   │
    │                        │
   NO                       YES
    │                        │
    ▼                        ▼
┌──────────┐      ┌──────────────────────┐
│ Sign Up  │      │ ❌ Invalid credentials│
└────┬─────┘      └──────────┬───────────┘
     │                       │
     ▼                       ▼
┌──────────┐      ┌──────────────────────┐
│Fill Form │      │ Toast: "Create       │
└────┬─────┘      │ account first!"      │
     │            └──────────┬───────────┘
     ▼                       │
┌──────────┐                │
│ Create   │                │
│ Account  │◄───────────────┘
└────┬─────┘
     │
     ▼
┌──────────┐
│Auto-Login│
└────┬─────┘
     │
     ▼
┌──────────┐
│Dashboard │
└──────────┘
   ✅ DONE!
```

---

## 🎯 QUICK START CHECKLIST

- [ ] Open the app
- [ ] See login page
- [ ] Click "Sign Up"
- [ ] Fill: Name, Email, Password, Role
- [ ] Click "Create Account"
- [ ] Wait 1-2 seconds
- [ ] ✅ You're in!

---

## 🚦 TROUBLESHOOTING

### **Problem: "I keep seeing 'Invalid login credentials'"**

**Checklist:**
1. ✅ Did you click "Sign Up"? (Not "Sign In")
2. ✅ Did you fill out the form completely?
3. ✅ Did you click "Create Account"?
4. ✅ Did you wait for success message?

**If YES to all:**
- Try logging out and logging in
- Try a different email
- Check browser console (F12) for details

---

### **Problem: "I created an account but can't login"**

**Try this:**
1. Refresh the page (F5)
2. Click "Sign In" (not Sign Up)
3. Enter the SAME email and password you used
4. Make sure password is correct (min 6 chars)
5. Click "Sign In"

**Still not working?**
- Try creating account with different email
- Clear browser cookies
- Try incognito mode

---

### **Problem: "Quick Test buttons don't work"**

**This is normal!**

The quick test buttons are shortcuts that:
1. ✅ Auto-fill credentials
2. ❌ DON'T create accounts automatically

**To use them:**
1. Create accounts manually first (see above)
2. THEN use the quick buttons
3. They'll auto-fill your credentials
4. Just click "Sign In"

---

## 📊 WHAT HAPPENS AFTER SIGNUP?

### **Immediate:**
```
Second 0: Click "Create Account"
Second 1: Toast: "Account created successfully!"
Second 2: Auto-login starts
Second 3: Toast: "Welcome, [Your Name]!"
Second 4: Dashboard appears
          ↓
       ✅ YOU'RE IN!
```

### **You'll see:**
- Your role-specific dashboard
- Navigation tabs
- Welcome message
- All features ready to use!

---

## 🎨 ROLE-SPECIFIC FEATURES

### **👨‍💼 Admin**
- Approve vendor prices
- Manage users
- View analytics
- Manage categories & markets

### **🏪 Vendor**
- Submit prices
- Track submissions
- View sales data
- Get notifications

### **💼 Business**
- Analyze price trends
- Compare markets
- Export data
- Planning tools

### **👤 Consumer**
- Search products
- Compare prices
- Save favorites
- Get price alerts

---

## 🎓 NEXT STEPS

### **After Creating Your First Account:**

1. **Explore the Dashboard**
   - Click through the tabs
   - See what features are available
   - Familiarize yourself with the UI

2. **Create More Accounts**
   - Try different roles
   - See how each dashboard differs
   - Test the complete workflow

3. **Test Key Features**
   - Vendor: Submit a price
   - Admin: Approve it
   - Consumer: See updated price
   - Business: Export data

4. **Read the Docs**
   - [`TESTING_GUIDE.md`](./TESTING_GUIDE.md) - Complete testing
   - [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md) - Quick fixes
   - [`README.md`](./README.md) - Full overview

---

## 🎯 SUCCESS CRITERIA

**You're successful when you can:**

✅ Create an account  
✅ Login without errors  
✅ See your dashboard  
✅ Navigate between tabs  
✅ Use role-specific features  

---

## 💬 COMMON QUESTIONS

### **Q: Do I need to verify my email?**
A: No! Auto-confirmed for testing.

### **Q: Can I use the same email for multiple roles?**
A: No, each email = one account. Use different emails.

### **Q: What if I forget my password?**
A: Create new account with different email (reset feature coming soon).

### **Q: Are the quick test buttons actual accounts?**
A: No, they just auto-fill. You must create accounts first.

### **Q: Why do I need to create accounts manually?**
A: Database starts empty. This is your fresh installation!

### **Q: How long does account creation take?**
A: ~30 seconds to fill form, instant creation.

### **Q: Will my accounts persist?**
A: Yes! Stored in Supabase database permanently.

---

## 🔗 HELPFUL LINKS

| What You Need | Where to Go |
|---------------|-------------|
| **First time setup** | This file! |
| **Testing instructions** | [`TESTING_GUIDE.md`](./TESTING_GUIDE.md) |
| **Quick error fixes** | [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md) |
| **Detailed troubleshooting** | [`TROUBLESHOOTING.md`](./TROUBLESHOOTING.md) |
| **Feature overview** | [`README.md`](./README.md) |
| **Technical details** | [`DATABASE_IMPLEMENTATION.md`](./DATABASE_IMPLEMENTATION.md) |

---

## ⚡ TL;DR (Too Long, Didn't Read)

```
1. Click "Sign Up"
2. Fill: admin@test.com / admin123 / Admin role
3. Click "Create Account"
4. ✅ Done!
```

**That's literally it!** 🎉

---

## 🎊 CONGRATULATIONS!

Once you create your first account, you'll have:

✅ Full access to the app  
✅ Real authentication working  
✅ Your own dashboard  
✅ All features unlocked  

**Welcome to Rwanda Market Price Checker!** 🇷🇼

---

**Having issues?** Check [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md) for instant solutions!

**Ready to test?** Read [`TESTING_GUIDE.md`](./TESTING_GUIDE.md) for complete workflows!

**Need details?** See [`README.md`](./README.md) for full documentation!

---

**Remember:** You're seeing "Invalid login credentials" because you haven't created an account yet. This is completely normal! Just click "Sign Up" and you're on your way! 🚀
