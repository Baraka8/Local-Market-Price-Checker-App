# 🚀 Complete Guide: How to Set Prices Automatically

There are **4 different ways** to automatically populate prices in the system. Choose the method that best fits your needs!

---

## ⚡ Method 1: Admin Bulk Import Feature (EASIEST - Recommended!)

### **What is it?**
A brand new admin interface with **one-click auto-generation** of prices. No code editing required!

### **How to Use:**

1. **Login as Admin:**
   - Email: `admin@test.com`
   - Select: **⚙️ Admin** role

2. **Go to "Bulk Import" Tab** (new tab with Upload icon)

3. **Choose an option:**

#### **Option A: Fill Missing Products Only** ⭐ RECOMMENDED
- Click **"Fill Missing Products"** button
- Automatically generates prices ONLY for products without any price data
- Takes ~1.5 seconds
- Shows success message with count
- **Perfect for adding prices gradually**

#### **Option B: Generate All Products**
- Click **"Generate All Products"** button
- Creates comprehensive price data across ALL products and ALL markets
- Each product appears in 1-3 random markets
- Takes ~2 seconds
- **Perfect for full database population**

### **What Gets Generated:**
✅ Realistic prices based on category ranges:
  - Grains: 800-2,500 RWF
  - Vegetables: 300-1,500 RWF
  - Fruits: 500-4,000 RWF
  - Meat: 3,000-8,000 RWF
  - Dairy: 500-2,000 RWF
  - Staples: 1,000-5,000 RWF

✅ Price variations (±10%)
✅ Random trends (up/down/stable)
✅ Fresh timestamps (0-48 hours ago)
✅ Star ratings (3.5-5.0)
✅ Review counts
✅ Some products get reviews with comments
✅ Status: **Pre-approved** (immediately visible to consumers)

### **Advantages:**
- ✅ No code editing
- ✅ Instant results
- ✅ One-click operation
- ✅ Prices are immediately visible
- ✅ Can be done repeatedly
- ✅ Perfect for testing

---

## 📊 Method 2: CSV Bulk Import (For Structured Data)

### **What is it?**
Upload multiple prices at once using CSV format. Great if you have existing price data in spreadsheets.

### **How to Use:**

1. **Login as Admin** → Go to **"Bulk Import"** tab

2. **Download the CSV Template:**
   - Click **"Download Template"** button
   - Opens a CSV file with the correct format

3. **Edit the CSV:**
```csv
productId,marketId,price
p1,m1,1200
p4,m2,850
p9,m1,3500
p13,m3,5200
p18,m2,4300
```

4. **Import:**
   - Copy your CSV data
   - Paste into the textarea
   - Click **"Import Prices"**
   - Success! All prices are imported and auto-approved

### **Product IDs:**
```
p1  = Rice (Local)        p11 = Oranges
p2  = Rice (Imported)     p12 = Pineapple
p3  = Beans (Red)         p13 = Chicken (Whole)
p4  = Tomatoes            p14 = Beef
p5  = Onions              p15 = Fish
p6  = Potatoes            p16 = Milk
p7  = Cabbage             p17 = Eggs
p8  = Carrots             p18 = Cooking Oil
p9  = Bananas             p19 = Sugar
p10 = Avocados            p20 = Salt
```

### **Market IDs:**
```
m1 = Kimironko Market
m2 = Nyabugogo Market
m3 = Kimisagara Market
m4 = Remera Market
m5 = Kicukiro Market
```

### **Advantages:**
- ✅ Precise control over prices
- ✅ Can import real data from spreadsheets
- ✅ Bulk operation (hundreds of rows at once)
- ✅ Auto-approved by admin

---

## 💻 Method 3: Edit Mock Data File (For Developers)

### **What is it?**
Directly edit the `/lib/mockData.ts` file to add permanent price data.

### **How to Use:**

1. Open `/lib/mockData.ts`

2. Find the `priceData` array (around line 217)

3. Add new price entries:

```typescript
export const priceData: PriceData[] = [
  // Existing prices...
  
  // Add new ones:
  {
    productId: 'p9', // Bananas
    marketId: 'm1', // Kimironko Market
    current: 3500,
    average: 3400,
    highest: 3800,
    lowest: 3200,
    lastUpdated: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    trend: 'stable',
    history: generatePriceHistory(3500),
    rating: 4.3,
    totalRatings: 12
  },
  {
    productId: 'p13', // Chicken
    marketId: 'm2', // Nyabugogo Market
    current: 5500,
    average: 5400,
    highest: 5800,
    lowest: 5100,
    lastUpdated: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    trend: 'up',
    history: generatePriceHistory(5500),
    rating: 4.7,
    totalRatings: 28,
    reviews: [
      {
        id: 'r10',
        userId: 'u10',
        userName: 'Marie T.',
        rating: 5,
        comment: 'Fresh chicken, good price!',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        helpful: 8
      }
    ]
  }
];
```

4. Save the file - prices appear immediately!

### **Advantages:**
- ✅ Permanent (survives page refresh)
- ✅ Can add reviews and detailed data
- ✅ Full control over every field
- ✅ Best for realistic demo data

### **Disadvantages:**
- ❌ Requires code editing
- ❌ More manual work
- ❌ Need to know product/market IDs

---

## 🤖 Method 4: Use Auto Price Generator Utility

### **What is it?**
A programmatic way to generate prices using the utility functions.

### **How to Use:**

1. Open browser console (F12)

2. Import and use the generator:

```javascript
// Import the generator (already available)
import { generateAllPrices, generateMissingPrices } from './lib/autoPriceGenerator';
import { priceData } from './lib/mockData';

// Generate prices for all products
const allPrices = generateAllPrices();
console.log(`Generated ${allPrices.length} prices`);

// Or generate only for missing products
const missingPrices = generateMissingPrices(priceData);
console.log(`Generated ${missingPrices.length} missing prices`);

// Or generate for specific products
const fruitPrices = generatePricesForProducts(['p9', 'p10', 'p11', 'p12']);
console.log(`Generated ${fruitPrices.length} fruit prices`);
```

### **Available Functions:**

#### `generateAllPrices(productIds?, marketIds?)`
- Generates prices for all (or specified) products
- Each product appears in 1-3 random markets
- Returns array of PriceData objects

#### `generateMissingPrices(existingPriceData)`
- Only generates for products without any prices
- Smart detection of missing products
- Perfect for gradual population

#### `generatePricesForProducts(productIds)`
- Generates prices for specific product IDs
- Example: `['p9', 'p10', 'p11']` for fruits

#### `printGeneratedPrices(priceData)`
- Prints generated data in copy-paste format
- For adding to mockData.ts

### **Advantages:**
- ✅ Flexible and programmable
- ✅ Can customize parameters
- ✅ Great for testing different scenarios

### **Disadvantages:**
- ❌ Requires developer console
- ❌ Temporary (unless copied to mockData.ts)

---

## 📋 Comparison Table

| Method | Ease of Use | Permanent | Realistic Data | Speed | Best For |
|--------|-------------|-----------|----------------|-------|----------|
| **Admin Bulk Import** | ⭐⭐⭐⭐⭐ | ✅ | ⭐⭐⭐⭐ | ⚡ Instant | Testing, demos |
| **CSV Import** | ⭐⭐⭐⭐ | ✅ | ⭐⭐⭐⭐⭐ | ⚡ Fast | Real data import |
| **Edit Mock Data** | ⭐⭐⭐ | ✅✅ | ⭐⭐⭐⭐⭐ | ⏱️ Manual | Production setup |
| **Generator Utility** | ⭐⭐ | ❌ | ⭐⭐⭐⭐ | ⚡ Fast | Development |

---

## 🎯 Recommended Workflow

### **For Quick Testing:**
1. Login as Admin
2. Go to "Bulk Import" tab
3. Click **"Fill Missing Products"**
4. Done! ✅

### **For Demo/Presentation:**
1. Login as Admin
2. Go to "Bulk Import" tab
3. Click **"Generate All Products"**
4. Now ALL products have prices across multiple markets! ✅

### **For Production:**
1. Use CSV Import with real data, OR
2. Edit `/lib/mockData.ts` with carefully curated prices
3. Add reviews and realistic variations

---

## ✅ Testing the Results

After setting prices automatically:

1. **Logout from Admin**

2. **Login as Consumer:**
   - Email: `consumer@test.com`
   - Select: **🛒 Consumer**

3. **Go to "Compare Prices" tab**

4. **Select any product** from the dropdown:
   - Bananas
   - Chicken
   - Cooking Oil
   - Avocados
   - etc.

5. **You'll now see prices!** 🎉
   - Multiple markets
   - Price cards with all details
   - Ratings and trends
   - No more empty state!

---

## 🔄 Resetting Prices

To clear all auto-generated prices and start fresh:

1. Refresh the page (prices in `globalPriceSubmissions` will reset)
2. OR manually clear in browser console:
```javascript
globalPriceSubmissions.length = 0;
```

Note: Prices in `/lib/mockData.ts` are permanent until you edit the file.

---

## 💡 Pro Tips

1. **Start Small:** Use "Fill Missing Products" first, then check results
2. **Mix Methods:** Use auto-generation for bulk, then add specific prices via CSV for important products
3. **Add Reviews:** Edit mockData.ts to add reviews to the most popular products
4. **Test Different States:** Try products with no prices, 1 market, 3 markets, etc.
5. **Price Aging:** Auto-generated prices have random ages (0-48h) to test the freshness indicators

---

## 🐛 Troubleshooting

**Q: I clicked "Fill Missing Products" but still see empty states**
- A: Refresh the page after generating prices
- OR switch to a different tab and back

**Q: Can I generate prices multiple times?**
- A: Yes! Each click generates new prices (they accumulate)

**Q: How do I make prices permanent?**
- A: Copy them to `/lib/mockData.ts` or they'll reset on page refresh

**Q: CSV import failed**
- A: Check the format: `productId,marketId,price` (no spaces, use correct IDs)

---

## 🎉 Success!

You now have **4 powerful ways** to automatically set prices! The Admin Bulk Import feature (Method 1) is the fastest and easiest for most use cases.

**Need help?** Check the reference IDs in the "Bulk Import" tab or see `/lib/mockData.ts` for product and market IDs.
