# ⚡ QUICK REFERENCE - Common Scenarios

## 🔥 "User already registered" Error

### **What happened:**
You tried to sign up with an email that already exists in the database.

### **What to do:**
1. ✅ **WAIT** - The page will automatically switch to Sign In mode in 1.5 seconds
2. ✅ **ENTER PASSWORD** - Type your password for this email
3. ✅ **CLICK SIGN IN** - You'll be logged in!

### **OR - Manual way:**
1. Click "Already have an account? Sign In"
2. Enter your email and password
3. Click "Sign In"

### **OR - Use different email:**
1. Stay on Sign Up page
2. Change email to something else (e.g., user2@test.com)
3. Create new account

---

## 🆕 First Time Using the App?

### **Step 1: Create Account**
```
1. You're on the login page
2. Click "Sign Up" (bottom of form)
3. Fill in:
   - Name: Your Name
   - Email: yourname@example.com
   - Password: yourpass123 (min 6 chars)
   - Role: Choose your role
4. Click "Create Account"
5. Wait 2 seconds - you'll be auto-logged in!
```

### **Step 2: Explore Dashboard**
```
✓ You're now in your role-specific dashboard
✓ Check out the different tabs
✓ Try the features!
```

---

## 🔄 Already Have an Account?

### **Quick Login:**
```
1. On login page
2. Enter your email
3. Enter your password
4. Select your role (optional)
5. Click "Sign In"
6. Done!
```

### **Super Quick (Test Accounts):**
```
1. Click "👨‍💼 Admin" button (auto-fills credentials)
2. Click "Sign In"
3. Logged in instantly!
```

---

## 🚫 Common Mistakes & Fixes

### **Mistake #1: Trying to login without creating account**
❌ Error: "Invalid login credentials"  
✅ Fix: Click "Sign Up" first, create account, then login

### **Mistake #2: Typing email wrong during signup**
❌ Error: "User already registered" (but you can't remember making account)  
✅ Fix: Double-check spelling, or use completely different email

### **Mistake #3: Forgetting password**
❌ Error: "Invalid login credentials"  
✅ Fix: Create new account with different email (password reset coming soon)

### **Mistake #4: Not waiting after signup**
❌ Error: "No session returned"  
✅ Fix: Wait 1-2 seconds, auto-login will happen

### **Mistake #5: Wrong role selected**
❌ Problem: Can't access expected features  
✅ Fix: Logout, login again with correct role selected

---

## 📋 Account Status Checklist

### **If you see "User already registered":**
- ✅ Yes, this email exists
- ✅ You (or someone) created account before
- ✅ Solution: Sign in instead of sign up

### **If you see "Invalid login credentials":**
- ❌ Account doesn't exist OR password is wrong
- ✅ Solution: Create account first, or check password

### **If page auto-switches to Sign In:**
- ✅ Good! This means email is registered
- ✅ Just enter password and sign in

---

## 🎯 Quick Decision Tree

```
Are you NEW to the app?
├─ YES → Click "Sign Up"
│         └─ Fill form → Create Account → Auto-login ✓
│
└─ NO (have account) → Use "Sign In"
           └─ Enter credentials → Sign In ✓

Got "User already registered"?
├─ Want to use this email? → Click "Sign In"
│                            └─ Enter password ✓
│
└─ Want different email? → Stay on Sign Up
                           └─ Change email → Create Account ✓

Got "Invalid credentials"?
├─ New user? → Need to Sign Up first
│             └─ Click "Sign Up" ✓
│
└─ Existing user? → Check password
                    └─ Type carefully ✓
```

---

## ⏱️ What Happens After "User already registered"

```
Second 0: Error toast appears "This email is already registered"
Second 1: Message says "Switching to Sign In..."
Second 1.5: Page switches to Sign In mode automatically
Second 2: New toast: "Please sign in with [your-email]"
Second 3: Form is now in Sign In mode
         ↓
NOW: Type password → Click "Sign In" → Done! ✓
```

---

## 💡 Pro Tips

### **Tip 1: Email Memory**
The app REMEMBERS your email when it auto-switches. Just add password!

### **Tip 2: No Need to Panic**
"User already registered" is GOOD - means your email is saved!

### **Tip 3: Quick Test**
Create test accounts like: test1@mail.com, test2@mail.com, etc.

### **Tip 4: Use Auto-Fill Buttons**
On Sign In mode, use the Admin/Vendor buttons for instant login!

### **Tip 5: One Email = One Account**
Each email can only have one account. Want another? Use different email.

---

## 🔑 Test Account Quick Start

### **Method 1: Create Fresh**
```
Email: mytest@example.com
Password: test123456
Role: Consumer
→ Create Account → Auto-login ✓
```

### **Method 2: Use Test Buttons** (if accounts exist)
```
1. Go to Sign In
2. Click "👨‍💼 Admin" button
3. Email: admin@test.com (auto-filled)
4. Password: admin123 (auto-filled)
5. Click "Sign In"
→ Instant login ✓
```

---

## 📊 Account States Explained

| State | What it means | What you see | What to do |
|-------|--------------|--------------|------------|
| **New** | Email never used | Sign Up form works | Create account |
| **Exists** | Email in database | "User already registered" | Sign in instead |
| **Logged In** | Active session | Dashboard visible | Use the app! |
| **Logged Out** | Session ended | Login page | Sign in again |

---

## 🎬 Real Example Walkthrough

### **Scenario: You forgot you already signed up**

```
YOU: Go to app
APP: Shows login page

YOU: Click "Sign Up"
APP: Shows signup form

YOU: Enter email: john@email.com
YOU: Enter password: pass123
YOU: Click "Create Account"

APP: ❌ Error: "User already registered"
APP: "Switching to Sign In..."
APP: [waits 1.5 seconds]
APP: Switches to Sign In mode
APP: ℹ️ "Please sign in with john@email.com"

YOU: See email is already filled
YOU: Type password: pass123
YOU: Click "Sign In"

APP: ✅ "Welcome back, John!"
APP: Shows dashboard

YOU: Successfully logged in! 🎉
```

---

## 🛠️ Recovery Options

### **Lost Password? (Temporary solution)**
```
Option 1: Create new account with different email
   → use john2@email.com instead of john@email.com

Option 2: Try common passwords you use
   → Maybe you used a different password

Option 3: Check password manager
   → Browser might have saved it
```

### **Can't Remember Email?**
```
Try:
- Personal email
- Work email
- Other emails you use
- Check confirmation emails in inbox
```

### **Account Locked/Issues?**
```
1. Clear browser cookies
2. Try incognito mode
3. Create fresh account with new email
4. Contact support (if available)
```

---

## ✅ Success Indicators

### **You're doing it RIGHT when:**
✅ Account created successfully  
✅ Auto-login works  
✅ Dashboard appears  
✅ Can see your name in profile  
✅ Features are accessible  

### **You need to FIX when:**
❌ Keep seeing login page after signin  
❌ Dashboard doesn't load  
❌ Features show errors  
❌ Session expires immediately  

---

## 🎯 Today's Goal: Get Logged In!

### **Path to Success:**
```
1. ✅ Understand error messages
2. ✅ Know when to Sign Up vs Sign In
3. ✅ Wait for auto-login after signup
4. ✅ Use quick buttons for testing
5. ✅ See your dashboard

Time needed: 30 seconds ⏱️
Difficulty: Easy! 😊
```

---

## 📞 Still Stuck?

### **If "User already registered":**
→ READ: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) - Section "User already registered"

### **If "Invalid credentials":**
→ READ: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) - Section "Invalid login credentials"

### **For full testing guide:**
→ READ: [TESTING_GUIDE.md](./TESTING_GUIDE.md)

### **For complete features:**
→ READ: [README.md](./README.md)

---

## 🎉 Remember:

**"User already registered" = Good news!**  
It means your email is already in the system.  
Just switch to Sign In and you're good to go! 🚀

**The app is trying to HELP you by:**
1. Detecting duplicate emails ✓
2. Auto-switching to Sign In ✓
3. Keeping your email filled ✓
4. Showing helpful messages ✓

**You're one password away from success!** 🎯
