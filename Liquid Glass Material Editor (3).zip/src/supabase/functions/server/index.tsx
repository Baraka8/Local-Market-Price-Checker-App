import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";
import { sendVerificationEmail, sendWelcomeEmail } from "./email_service.tsx";
import { sendVerificationSMS, send2FASMS, sendPasswordResetSMS } from "./sms_service.tsx";

const app = new Hono();

// Supabase client with service role for admin operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// ============= AUTHENTICATION ROUTES =============

// Send verification email
app.post("/make-server-b7f3babf/send-verification-email", async (c) => {
  try {
    const { email, userName, verificationCode } = await c.req.json();

    if (!email || !userName || !verificationCode) {
      return c.json({ error: "Email, userName, and verificationCode are required" }, 400);
    }

    console.log(`📧 Sending verification email to ${email} with code: ${verificationCode}`);

    const result = await sendVerificationEmail(email, userName, verificationCode);

    if (result.success) {
      return c.json({ 
        success: true, 
        message: "Verification email sent successfully" 
      });
    } else {
      // Email service not configured or failed - this is OK for demo mode
      console.log(`⚠️ Email not sent: ${result.error}`);
      return c.json({ 
        success: false, 
        message: result.error,
        demoMode: true 
      });
    }
  } catch (error: any) {
    console.error("Error sending verification email:", error);
    return c.json({ 
      success: false,
      error: error.message || "Failed to send verification email",
      demoMode: true
    }, 200); // Return 200 so frontend doesn't fail
  }
});

// Send verification SMS
app.post("/make-server-b7f3babf/send-verification-sms", async (c) => {
  try {
    const { phone, userName, verificationCode } = await c.req.json();

    if (!phone || !userName || !verificationCode) {
      return c.json({ error: "Phone, userName, and verificationCode are required" }, 400);
    }

    console.log(`📱 Sending verification SMS to ${phone} with code: ${verificationCode}`);

    const result = await sendVerificationSMS(phone, userName, verificationCode);

    if (result.success) {
      return c.json({ 
        success: true, 
        message: "Verification SMS sent successfully" 
      });
    } else {
      // SMS service not configured or failed - this is OK for demo mode
      console.log(`⚠️ SMS not sent: ${result.error}`);
      return c.json({ 
        success: false, 
        message: result.error,
        demoMode: true 
      });
    }
  } catch (error: any) {
    console.error("Error sending verification SMS:", error);
    return c.json({ 
      success: false,
      error: error.message || "Failed to send verification SMS",
      demoMode: true
    }, 200); // Return 200 so frontend doesn't fail
  }
});

// Send 2FA SMS
app.post("/make-server-b7f3babf/send-2fa-sms", async (c) => {
  try {
    const { phone, userName, verificationCode } = await c.req.json();

    if (!phone || !userName || !verificationCode) {
      return c.json({ error: "Phone, userName, and verificationCode are required" }, 400);
    }

    console.log(`📱 Sending 2FA SMS to ${phone} with code: ${verificationCode}`);

    const result = await send2FASMS(phone, userName, verificationCode);

    if (result.success) {
      return c.json({ 
        success: true, 
        message: "2FA SMS sent successfully" 
      });
    } else {
      // SMS service not configured or failed - this is OK for demo mode
      console.log(`⚠️ SMS not sent: ${result.error}`);
      return c.json({ 
        success: false, 
        message: result.error,
        demoMode: true 
      });
    }
  } catch (error: any) {
    console.error("Error sending 2FA SMS:", error);
    return c.json({ 
      success: false,
      error: error.message || "Failed to send 2FA SMS",
      demoMode: true
    }, 200); // Return 200 so frontend doesn't fail
  }
});

// Send password reset SMS
app.post("/make-server-b7f3babf/send-password-reset-sms", async (c) => {
  try {
    const { phone, userName, verificationCode } = await c.req.json();

    if (!phone || !userName || !verificationCode) {
      return c.json({ error: "Phone, userName, and verificationCode are required" }, 400);
    }

    console.log(`📱 Sending password reset SMS to ${phone} with code: ${verificationCode}`);

    const result = await sendPasswordResetSMS(phone, userName, verificationCode);

    if (result.success) {
      return c.json({ 
        success: true, 
        message: "Password reset SMS sent successfully" 
      });
    } else {
      // SMS service not configured or failed - this is OK for demo mode
      console.log(`⚠️ SMS not sent: ${result.error}`);
      return c.json({ 
        success: false, 
        message: result.error,
        demoMode: true 
      });
    }
  } catch (error: any) {
    console.error("Error sending password reset SMS:", error);
    return c.json({ 
      success: false,
      error: error.message || "Failed to send password reset SMS",
      demoMode: true
    }, 200); // Return 200 so frontend doesn't fail
  }
});

// Sign up - Create new user
app.post("/make-server-b7f3babf/signup", async (c) => {
  try {
    const { email, password, name, role, marketId, province, district } = await c.req.json();

    // Validate required fields
    if (!email || !password || !name || !role) {
      return c.json({ error: "Email, password, name, and role are required" }, 400);
    }

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm since we don't have email server configured
      user_metadata: {
        name,
        role,
        marketId: marketId || null,
        province: province || null,
        district: district || null,
      }
    });

    if (authError) {
      console.error("Auth error during signup:", authError);
      return c.json({ error: authError.message }, 400);
    }

    // Store additional user data in KV
    await kv.set(`user:${authData.user.id}`, {
      id: authData.user.id,
      email,
      name,
      role,
      marketId: marketId || null,
      province: province || null,
      district: district || null,
      createdAt: new Date().toISOString(),
    });

    // Send welcome email
    await sendWelcomeEmail(email, name);

    return c.json({
      success: true,
      user: {
        id: authData.user.id,
        email,
        name,
        role,
      }
    });
  } catch (error) {
    console.error("Signup error:", error);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// Get user profile
app.get("/make-server-b7f3babf/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get additional user data from KV
    const userData = await kv.get(`user:${user.id}`);

    return c.json({
      id: user.id,
      email: user.email,
      name: user.user_metadata.name,
      role: user.user_metadata.role,
      ...userData,
    });
  } catch (error) {
    console.error("Profile fetch error:", error);
    return c.json({ error: "Failed to fetch profile" }, 500);
  }
});

// Update user profile
app.post("/make-server-b7f3babf/profile/update", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { name, marketId, province, district } = await c.req.json();

    // Update in KV
    const userData = await kv.get(`user:${user.id}`);
    await kv.set(`user:${user.id}`, {
      ...userData,
      name,
      marketId,
      province,
      district,
    });

    return c.json({ success: true });
  } catch (error) {
    console.error("Profile update error:", error);
    return c.json({ error: "Failed to update profile" }, 500);
  }
});

// ============= ADMIN USER MANAGEMENT ROUTES =============

// Get all users (admin only)
app.get("/make-server-b7f3babf/admin/users", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can view all users" }, 403);
    }

    const users = await kv.getByPrefix("user:");
    
    return c.json({ users });
  } catch (error) {
    console.error("Error fetching users:", error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

// Update user role (admin only)
app.post("/make-server-b7f3babf/admin/users/:id/role", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can update user roles" }, 403);
    }

    const { id } = c.req.param();
    const { role } = await c.req.json();

    // Update in Supabase Auth
    const { error: updateError } = await supabase.auth.admin.updateUserById(id, {
      user_metadata: { role }
    });

    if (updateError) {
      throw updateError;
    }

    // Update in KV
    const userData = await kv.get(`user:${id}`);
    if (userData) {
      userData.role = role;
      await kv.set(`user:${id}`, userData);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating user role:", error);
    return c.json({ error: "Failed to update user role" }, 500);
  }
});

// Delete user (admin only)
app.delete("/make-server-b7f3babf/admin/users/:id", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can delete users" }, 403);
    }

    const { id } = c.req.param();

    // Delete from Supabase Auth
    const { error: deleteError } = await supabase.auth.admin.deleteUser(id);

    if (deleteError) {
      throw deleteError;
    }

    // Delete from KV
    await kv.del(`user:${id}`);

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting user:", error);
    return c.json({ error: "Failed to delete user" }, 500);
  }
});

// ============= PRICE MANAGEMENT ROUTES =============

// Get all prices (public, for consumers)
app.get("/make-server-b7f3babf/prices", async (c) => {
  try {
    const prices = await kv.getByPrefix("price:");
    return c.json({ prices });
  } catch (error) {
    console.error("Error fetching prices:", error);
    return c.json({ error: "Failed to fetch prices" }, 500);
  }
});

// Get prices by product and market
app.get("/make-server-b7f3babf/prices/:productId/:marketId", async (c) => {
  try {
    const { productId, marketId } = c.req.param();
    const price = await kv.get(`price:${productId}:${marketId}`);
    
    if (!price) {
      return c.json({ error: "Price not found" }, 404);
    }
    
    return c.json({ price });
  } catch (error) {
    console.error("Error fetching price:", error);
    return c.json({ error: "Failed to fetch price" }, 500);
  }
});

// Submit price (vendor only)
app.post("/make-server-b7f3babf/prices/submit", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is a vendor
    if (user.user_metadata.role !== 'vendor') {
      return c.json({ error: "Only vendors can submit prices" }, 403);
    }

    const { productId, marketId, price, quantity, unit, imageUrl } = await c.req.json();

    if (!productId || !marketId || !price) {
      return c.json({ error: "Product ID, market ID, and price are required" }, 400);
    }

    const submissionId = crypto.randomUUID();
    const submission = {
      id: submissionId,
      productId,
      marketId,
      vendorId: user.id,
      vendorName: user.user_metadata.name,
      price: parseFloat(price),
      quantity: quantity || 1,
      unit: unit || 'kg',
      imageUrl: imageUrl || null,
      status: 'pending',
      submittedAt: new Date().toISOString(),
      ageInHours: 0,
    };

    // Store submission
    await kv.set(`submission:${submissionId}`, submission);

    // Add to vendor's submissions list
    const vendorSubmissions = await kv.get(`vendor_submissions:${user.id}`) || [];
    vendorSubmissions.push(submissionId);
    await kv.set(`vendor_submissions:${user.id}`, vendorSubmissions);

    // Create notification for admin
    const notificationId = crypto.randomUUID();
    await kv.set(`notification:admin:${notificationId}`, {
      id: notificationId,
      title: 'New Price Submission',
      message: `${user.user_metadata.name} submitted a price for approval`,
      type: 'info',
      timestamp: new Date().toISOString(),
      read: false,
      relatedId: submissionId,
    });

    return c.json({ success: true, submission });
  } catch (error) {
    console.error("Error submitting price:", error);
    return c.json({ error: "Failed to submit price" }, 500);
  }
});

// Get all price submissions (admin only)
app.get("/make-server-b7f3babf/submissions", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can view all submissions" }, 403);
    }

    const submissions = await kv.getByPrefix("submission:");
    
    // Calculate age for each submission
    const now = new Date();
    const submissionsWithAge = submissions.map(sub => {
      const submittedDate = new Date(sub.submittedAt);
      const ageInHours = Math.floor((now.getTime() - submittedDate.getTime()) / (1000 * 60 * 60));
      return { ...sub, ageInHours };
    });

    return c.json({ submissions: submissionsWithAge });
  } catch (error) {
    console.error("Error fetching submissions:", error);
    return c.json({ error: "Failed to fetch submissions" }, 500);
  }
});

// Get vendor's submissions
app.get("/make-server-b7f3babf/submissions/my", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const submissionIds = await kv.get(`vendor_submissions:${user.id}`) || [];
    const submissions = await Promise.all(
      submissionIds.map(id => kv.get(`submission:${id}`))
    );

    // Calculate age for each submission
    const now = new Date();
    const submissionsWithAge = submissions
      .filter(sub => sub !== null)
      .map(sub => {
        const submittedDate = new Date(sub.submittedAt);
        const ageInHours = Math.floor((now.getTime() - submittedDate.getTime()) / (1000 * 60 * 60));
        return { ...sub, ageInHours };
      });

    return c.json({ submissions: submissionsWithAge });
  } catch (error) {
    console.error("Error fetching vendor submissions:", error);
    return c.json({ error: "Failed to fetch submissions" }, 500);
  }
});

// Approve price submission (admin only)
app.post("/make-server-b7f3babf/submissions/:id/approve", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can approve submissions" }, 403);
    }

    const { id } = c.req.param();
    const submission = await kv.get(`submission:${id}`);

    if (!submission) {
      return c.json({ error: "Submission not found" }, 404);
    }

    // Update submission status
    submission.status = 'approved';
    submission.approvedAt = new Date().toISOString();
    submission.approvedBy = user.id;
    await kv.set(`submission:${id}`, submission);

    // Update the actual price in the system
    const priceKey = `price:${submission.productId}:${submission.marketId}`;
    const existingPrice = await kv.get(priceKey);
    
    const newPrice = {
      productId: submission.productId,
      marketId: submission.marketId,
      current: submission.price,
      unit: submission.unit,
      lastUpdated: new Date().toISOString(),
      vendorId: submission.vendorId,
      vendorName: submission.vendorName,
      history: existingPrice?.history || [],
    };

    // Add to history if there was a previous price
    if (existingPrice) {
      newPrice.history.push({
        price: existingPrice.current,
        date: existingPrice.lastUpdated,
      });
      // Keep only last 30 days of history
      newPrice.history = newPrice.history.slice(-30);
    }

    await kv.set(priceKey, newPrice);

    // Send notification to vendor
    const notificationId = crypto.randomUUID();
    await kv.set(`notification:${submission.vendorId}:${notificationId}`, {
      id: notificationId,
      title: 'Price Approved',
      message: `Your price submission has been approved and is now live!`,
      type: 'success',
      timestamp: new Date().toISOString(),
      read: false,
      relatedId: id,
    });

    return c.json({ success: true, message: "Price approved and updated" });
  } catch (error) {
    console.error("Error approving submission:", error);
    return c.json({ error: "Failed to approve submission" }, 500);
  }
});

// Reject price submission (admin only)
app.post("/make-server-b7f3babf/submissions/:id/reject", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Verify user is admin
    if (user.user_metadata.role !== 'admin') {
      return c.json({ error: "Only admins can reject submissions" }, 403);
    }

    const { id } = c.req.param();
    const { reason } = await c.req.json();

    if (!reason) {
      return c.json({ error: "Rejection reason is required" }, 400);
    }

    const submission = await kv.get(`submission:${id}`);

    if (!submission) {
      return c.json({ error: "Submission not found" }, 404);
    }

    // Update submission status
    submission.status = 'rejected';
    submission.rejectedAt = new Date().toISOString();
    submission.rejectedBy = user.id;
    submission.rejectionReason = reason;
    await kv.set(`submission:${id}`, submission);

    // Send notification to vendor
    const notificationId = crypto.randomUUID();
    await kv.set(`notification:${submission.vendorId}:${notificationId}`, {
      id: notificationId,
      title: 'Price Rejected',
      message: `Your price submission was rejected. Reason: ${reason}`,
      type: 'error',
      timestamp: new Date().toISOString(),
      read: false,
      relatedId: id,
    });

    return c.json({ success: true, message: "Price rejected" });
  } catch (error) {
    console.error("Error rejecting submission:", error);
    return c.json({ error: "Failed to reject submission" }, 500);
  }
});

// Get notifications for user
app.get("/make-server-b7f3babf/notifications", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const prefix = user.user_metadata.role === 'admin' 
      ? 'notification:admin:' 
      : `notification:${user.id}:`;
    
    const notifications = await kv.getByPrefix(prefix);
    
    // Sort by timestamp, newest first
    notifications.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    return c.json({ notifications });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    return c.json({ error: "Failed to fetch notifications" }, 500);
  }
});

// Mark notification as read
app.post("/make-server-b7f3babf/notifications/:id/read", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { id } = c.req.param();
    const prefix = user.user_metadata.role === 'admin' 
      ? `notification:admin:${id}` 
      : `notification:${user.id}:${id}`;
    
    const notification = await kv.get(prefix);
    
    if (notification) {
      notification.read = true;
      await kv.set(prefix, notification);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    return c.json({ error: "Failed to mark notification as read" }, 500);
  }
});

// Health check endpoint
app.get("/make-server-b7f3babf/health", (c) => {
  return c.json({ status: "ok" });
});

Deno.serve(app.fetch);