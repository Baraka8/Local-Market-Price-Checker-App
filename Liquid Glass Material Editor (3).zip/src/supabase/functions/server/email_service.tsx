// Email Service using Resend API
// This file handles sending verification emails to users

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const FROM_EMAIL = 'onboarding@resend.dev'; // Default Resend test email

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

/**
 * Send an email using Resend API
 */
export async function sendEmail(options: EmailOptions): Promise<{ success: boolean; error?: string }> {
  try {
    // Check if API key is configured
    if (!RESEND_API_KEY) {
      console.log('⚠️ RESEND_API_KEY not configured - email not sent (demo mode)');
      return { 
        success: false, 
        error: 'Email service not configured. Running in demo mode.' 
      };
    }

    // Validate API key format
    if (!RESEND_API_KEY.startsWith('re_')) {
      console.error('❌ Invalid RESEND_API_KEY format. Key should start with "re_"');
      return {
        success: false,
        error: 'Invalid API key format. Please check your RESEND_API_KEY.'
      };
    }

    // Send email via Resend API
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text || options.html.replace(/<[^>]*>/g, ''), // Strip HTML for text version
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      // Handle specific error cases
      if (response.status === 401 || response.status === 403) {
        console.error('❌ Resend API authentication failed. Please verify your API key.');
        console.error('   Error details:', data);
        return {
          success: false,
          error: 'Invalid API key. Please add a valid RESEND_API_KEY from https://resend.com'
        };
      }
      
      console.error('❌ Resend API error:', data);
      return { 
        success: false, 
        error: data.message || 'Failed to send email' 
      };
    }

    console.log('✅ Email sent successfully:', data.id);
    return { success: true };

  } catch (error: any) {
    console.error('❌ Error sending email:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to send email' 
    };
  }
}

/**
 * Generate HTML template for verification email
 */
export function generateVerificationEmailHTML(
  userName: string,
  verificationCode: string,
  expiryMinutes: number = 1
): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Email Verification - Rwanda Market Price Checker</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      background-color: #f7f7f7;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 40px auto;
      background: #ffffff;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .header {
      background: linear-gradient(135deg, #1E88E5 0%, #1565C0 100%);
      padding: 40px 30px;
      text-align: center;
      color: white;
    }
    .header h1 {
      margin: 0;
      font-size: 28px;
      font-weight: 700;
    }
    .header p {
      margin: 10px 0 0;
      font-size: 16px;
      opacity: 0.9;
    }
    .content {
      padding: 40px 30px;
    }
    .greeting {
      font-size: 18px;
      color: #333;
      margin-bottom: 20px;
    }
    .message {
      font-size: 16px;
      color: #666;
      margin-bottom: 30px;
      line-height: 1.8;
    }
    .code-container {
      background: linear-gradient(135deg, #2ECC71 0%, #27AE60 100%);
      border-radius: 12px;
      padding: 30px;
      text-align: center;
      margin: 30px 0;
      box-shadow: 0 4px 12px rgba(46, 204, 113, 0.3);
    }
    .code-label {
      font-size: 14px;
      color: white;
      opacity: 0.9;
      margin-bottom: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .code {
      font-size: 48px;
      font-weight: 800;
      color: white;
      letter-spacing: 12px;
      font-family: 'Courier New', monospace;
      margin: 10px 0;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    .expiry {
      background: #FFF3CD;
      border-left: 4px solid #FFC107;
      padding: 15px;
      margin: 25px 0;
      border-radius: 4px;
    }
    .expiry strong {
      color: #856404;
      font-size: 16px;
    }
    .instructions {
      background: #E8F5E9;
      border-radius: 8px;
      padding: 20px;
      margin: 25px 0;
    }
    .instructions h3 {
      margin: 0 0 15px;
      color: #2ECC71;
      font-size: 18px;
    }
    .instructions ol {
      margin: 0;
      padding-left: 20px;
      color: #666;
    }
    .instructions li {
      margin: 8px 0;
      font-size: 15px;
    }
    .footer {
      background: #f7f7f7;
      padding: 25px 30px;
      text-align: center;
      font-size: 14px;
      color: #999;
      border-top: 1px solid #e0e0e0;
    }
    .footer a {
      color: #1E88E5;
      text-decoration: none;
    }
    .security-note {
      background: #E3F2FD;
      border-left: 4px solid #1E88E5;
      padding: 15px;
      margin: 25px 0;
      border-radius: 4px;
      font-size: 14px;
      color: #1565C0;
    }
    .button {
      display: inline-block;
      padding: 14px 32px;
      background: #1E88E5;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-weight: 600;
      margin: 20px 0;
      transition: background 0.3s;
    }
    .divider {
      height: 1px;
      background: #e0e0e0;
      margin: 30px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🛒 Rwanda Market Price Checker</h1>
      <p>Email Verification Required</p>
    </div>
    
    <div class="content">
      <div class="greeting">
        Hello <strong>${userName}</strong>,
      </div>
      
      <div class="message">
        Welcome to Rwanda Market Price Checker! To complete your registration and start comparing prices across Rwanda's markets, please verify your email address.
      </div>
      
      <div class="code-container">
        <div class="code-label">Your Verification Code</div>
        <div class="code">${verificationCode}</div>
      </div>
      
      <div class="expiry">
        <strong>⏰ Important:</strong> This code will expire in <strong>${expiryMinutes} minute${expiryMinutes !== 1 ? 's' : ''}</strong>. Please use it immediately.
      </div>
      
      <div class="instructions">
        <h3>📋 How to Verify:</h3>
        <ol>
          <li>Return to the Rwanda Market Price Checker app</li>
          <li>Enter the 6-digit code shown above</li>
          <li>Click the "Verify Email" button</li>
          <li>Start exploring market prices!</li>
        </ol>
      </div>
      
      <div class="security-note">
        🔒 <strong>Security Notice:</strong> We will never ask for your password via email. If you didn't request this verification, please ignore this email or contact our support team.
      </div>
      
      <div class="divider"></div>
      
      <div style="text-align: center; color: #666; font-size: 14px;">
        <p>Having trouble? Contact our support team:</p>
        <p>📧 <a href="mailto:support@rwandaprices.com">support@rwandaprices.com</a></p>
        <p>📱 +250 788 000 000</p>
      </div>
    </div>
    
    <div class="footer">
      <p>
        © 2024 Rwanda Market Price Checker. All rights reserved.
      </p>
      <p>
        Kigali, Rwanda | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
      </p>
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Send verification email
 */
export async function sendVerificationEmail(
  email: string,
  userName: string,
  verificationCode: string
): Promise<{ success: boolean; error?: string }> {
  const html = generateVerificationEmailHTML(userName, verificationCode);
  
  return await sendEmail({
    to: email,
    subject: '🔐 Verify Your Email - Rwanda Market Price Checker',
    html,
  });
}

/**
 * Send welcome email after successful verification
 */
export async function sendWelcomeEmail(
  email: string,
  userName: string
): Promise<{ success: boolean; error?: string }> {
  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #1E88E5, #1565C0); color: white; padding: 30px; text-align: center; border-radius: 8px; }
    .content { padding: 30px; background: white; }
    .footer { text-align: center; color: #999; font-size: 14px; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🎉 Welcome to Rwanda Market Price Checker!</h1>
    </div>
    <div class="content">
      <h2>Hello ${userName},</h2>
      <p>Your email has been successfully verified! You now have full access to all features:</p>
      <ul>
        <li>✅ Compare prices across Rwanda's markets</li>
        <li>✅ Track price trends and history</li>
        <li>✅ Set up price alerts</li>
        <li>✅ Save favorite products</li>
        <li>✅ Access market insights</li>
      </ul>
      <p>Start exploring and find the best prices in your area!</p>
    </div>
    <div class="footer">
      <p>© 2024 Rwanda Market Price Checker</p>
    </div>
  </div>
</body>
</html>
  `;
  
  return await sendEmail({
    to: email,
    subject: '🎉 Welcome to Rwanda Market Price Checker!',
    html,
  });
}