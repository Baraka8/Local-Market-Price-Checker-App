// SMS Service using Africa's Talking API
// Africa's Talking is the best SMS provider for Rwanda

const AFRICASTALKING_API_KEY = Deno.env.get('AFRICASTALKING_API_KEY');
const AFRICASTALKING_USERNAME = Deno.env.get('AFRICASTALKING_USERNAME') || 'sandbox';
const SENDER_ID = 'RwandaPrice'; // Your sender ID

export interface SMSOptions {
  to: string; // Phone number in international format: +250788123456
  message: string;
}

/**
 * Send SMS using Africa's Talking API
 */
export async function sendSMS(options: SMSOptions): Promise<{ success: boolean; error?: string; messageId?: string }> {
  try {
    // Check if API key is configured
    if (!AFRICASTALKING_API_KEY) {
      console.log('⚠️ AFRICASTALKING_API_KEY not configured - SMS not sent (demo mode)');
      return { 
        success: false, 
        error: 'SMS service not configured. Please add AFRICASTALKING_API_KEY to environment variables.' 
      };
    }

    // Validate phone number format
    if (!options.to.startsWith('+')) {
      return {
        success: false,
        error: 'Phone number must be in international format (e.g., +250788123456)'
      };
    }

    // Send SMS via Africa's Talking API
    const response = await fetch('https://api.africastalking.com/version1/messaging', {
      method: 'POST',
      headers: {
        'apiKey': AFRICASTALKING_API_KEY,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: new URLSearchParams({
        username: AFRICASTALKING_USERNAME,
        to: options.to,
        message: options.message,
        from: SENDER_ID,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('❌ Africa\'s Talking API error:', data);
      return { 
        success: false, 
        error: data.message || 'Failed to send SMS' 
      };
    }

    // Check if message was sent successfully
    if (data.SMSMessageData && data.SMSMessageData.Recipients) {
      const recipient = data.SMSMessageData.Recipients[0];
      
      if (recipient.status === 'Success') {
        console.log('✅ SMS sent successfully:', recipient.messageId);
        return { 
          success: true,
          messageId: recipient.messageId 
        };
      } else {
        console.error('❌ SMS delivery failed:', recipient.status);
        return { 
          success: false, 
          error: `SMS delivery failed: ${recipient.status}` 
        };
      }
    }

    return { 
      success: false, 
      error: 'Unexpected response from SMS service' 
    };

  } catch (error: any) {
    console.error('❌ Error sending SMS:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to send SMS' 
    };
  }
}

/**
 * Generate SMS message for verification code
 */
export function generateVerificationSMS(
  userName: string,
  verificationCode: string,
  expiryMinutes: number = 1
): string {
  return `Hello ${userName}! Your Rwanda Market Price Checker verification code is: ${verificationCode}. This code expires in ${expiryMinutes} minute${expiryMinutes !== 1 ? 's' : ''}. Do not share this code with anyone.`;
}

/**
 * Send verification SMS
 */
export async function sendVerificationSMS(
  phone: string,
  userName: string,
  verificationCode: string
): Promise<{ success: boolean; error?: string; messageId?: string }> {
  const message = generateVerificationSMS(userName, verificationCode);
  
  console.log(`📱 Sending SMS verification to ${phone} with code: ${verificationCode}`);
  
  return await sendSMS({
    to: phone,
    message,
  });
}

/**
 * Send 2FA SMS
 */
export async function send2FASMS(
  phone: string,
  userName: string,
  code: string
): Promise<{ success: boolean; error?: string; messageId?: string }> {
  const message = `${userName}, your Rwanda Market Price Checker 2FA code is: ${code}. This code expires in 1 minute. Do not share this code.`;
  
  return await sendSMS({
    to: phone,
    message,
  });
}

/**
 * Send password reset SMS
 */
export async function sendPasswordResetSMS(
  phone: string,
  userName: string,
  code: string
): Promise<{ success: boolean; error?: string; messageId?: string }> {
  const message = `${userName}, your password reset code is: ${code}. This code expires in 1 minute. If you didn't request this, ignore this message.`;
  
  return await sendSMS({
    to: phone,
    message,
  });
}