# ⚡ Quick API Setup - 5 Minutes

**Goal:** Enable real email sending in 5 minutes!

---

## 🚀 EMAIL SETUP (5 Minutes - FREE!)

### Step 1: Get Resend API Key (2 minutes)

1. Go to **https://resend.com**
2. Click "Get Started"  
3. Sign up with your email
4. Verify your email
5. Go to **API Keys** page
6. Click "Create API Key"
7. Copy the key (starts with `re_`)

### Step 2: Add to Supabase (2 minutes)

1. Open **https://supabase.com**
2. Select your project: **dqwmpwonmadaxevjghkk**
3. Go to **Settings** → **Edge Functions** → **Secrets**
4. Click "+ New Secret"
5. Enter:
   - **Name:** `RESEND_API_KEY`
   - **Value:** Paste your key (re_...)
6. Click "Create Secret"
7. Click "Restart Edge Functions"
8. Wait 30 seconds

### Step 3: Test (1 minute)

1. Open your app
2. Click "Sign Up"
3. Enter your real email
4. Check your inbox
5. ✅ You should receive a real email!

---

## 📱 SMS SETUP (Optional - 10 Minutes)

### Step 1: Get Africa's Talking Credentials (5 minutes)

1. Go to **https://africastalking.com**
2. Sign up for an account
3. Verify your account
4. Go to **Settings** → **API Key**
5. Generate an API Key
6. Copy:
   - API Key
   - Username (usually your app name)

### Step 2: Add to Supabase (3 minutes)

1. Go to Supabase **Settings** → **Edge Functions** → **Secrets**
2. Add first secret:
   - **Name:** `AFRICASTALKING_API_KEY`
   - **Value:** Your API key
3. Add second secret:
   - **Name:** `AFRICASTALKING_USERNAME`
   - **Value:** Your username
4. Click "Restart Edge Functions"
5. Wait 30 seconds

### Step 3: Test (2 minutes)

1. Open your app
2. Click "Sign Up"
3. Enter phone number
4. Check "Verify via SMS"
5. Check your phone
6. ✅ You should receive a real SMS!

---

## 🎯 That's It!

Your verification system is now sending real codes!

### What's Next?

- Email: **Working** ✅
- SMS: **Working** ✅ (if you added keys)
- Demo displays: **Removed** ✅
- Production ready: **YES** ✅

---

## 🔍 Quick Check

### Is Email Working?

```bash
# Check Supabase Secrets:
✅ RESEND_API_KEY = re_...
```

### Is SMS Working?

```bash
# Check Supabase Secrets:
✅ AFRICASTALKING_API_KEY = your_key
✅ AFRICASTALKING_USERNAME = your_username
```

---

## 💡 Cost

### Email (Resend):
- **Free:** 3,000 emails/month
- **Cost:** $0 to start!
- **Perfect for:** Testing & small apps

### SMS (Africa's Talking):
- **Cost:** ~$0.03 per SMS
- **Example:** 100 SMS/day = ~$90/month
- **Perfect for:** Production apps in Rwanda

---

## 🐛 Not Working?

### Email Issues:
1. Check key starts with `re_`
2. Check Supabase logs
3. Check spam folder
4. Restart edge functions

### SMS Issues:
1. Check both keys are set
2. Check phone format: +250788123456
3. Check Africa's Talking dashboard
4. Ensure credits/sandbox access

---

## 📞 Support

### Resend:
- Docs: https://resend.com/docs
- Support: support@resend.com

### Africa's Talking:
- Docs: https://developers.africastalking.com
- Support: https://help.africastalking.com

---

**Time to Setup:** 5 minutes (email) + 10 minutes (SMS)  
**Cost:** $0 (email free tier)  
**Status:** 🟢 Ready!
