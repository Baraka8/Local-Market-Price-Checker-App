# ⚡ Quick Start Card

## 🚀 Get Started in 2 Minutes!

---

## 🔐 FIRST TIME? CREATE ACCOUNT

### **Step 1: Click "Sign Up"**
Look at the bottom of the login form

### **Step 2: Fill in Details**
```
Full Name:    Admin User
Email:        admin@test.com
Password:     admin123
I am a:       Admin ⚙️
```

### **Step 3: Click "Create Account"**
✅ Done! You're automatically logged in!

---

## 🔄 ALREADY HAVE ACCOUNT? SIGN IN

### **Option 1: Quick Fill**
1. Click **👨‍💼 Admin** button
2. Auto-fills credentials
3. Click "Sign In"

### **Option 2: Manual**
1. Enter: `admin@test.com`
2. Password: `admin123`
3. Select: Admin
4. Click "Sign In"

---

## 🎨 DASHBOARD COLORS

| Color | Role | Emoji |
|-------|------|-------|
| 🟣 **Indigo/Purple** | Admin | 👨‍💼 |
| 🌸 **Purple/Pink** | Vendor | 🏪 |
| 🟢 **Emerald/Teal** | Business | 💼 |
| 🔵 **Blue/Sky** | Consumer | 👤 |

**Look at the header color = Know your role instantly!**

---

## 👁️ ADMIN: VIEW OTHER ROLES

1. Login as admin
2. Click **"View Interface As"** dropdown (top right)
3. Select: Vendor / Business / Consumer
4. Explore that dashboard
5. Click **"Return to Admin"** when done

---

## ❌ GOT AN ERROR?

### **"Invalid login credentials"**
➡️ Account doesn't exist yet  
➡️ Click "Sign Up" to create it first

### **"Account already registered"**
➡️ Account exists!  
➡️ Page will auto-switch to Sign In  
➡️ Enter password and sign in

### **Can't find a feature?**
➡️ Check the tabs in your dashboard  
➡️ Each role has different features

---

## 📚 NEED MORE HELP?

| Quick Help | Full Guide |
|------------|------------|
| [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md) | [`LOGIN_GUIDE.md`](./LOGIN_GUIDE.md) |
| [`README.md`](./README.md) | [`TESTING_GUIDE.md`](./TESTING_GUIDE.md) |

---

## ✅ YOU'RE READY!

**That's literally all you need to know to get started!**

1. Sign up (first time)
2. Sign in (returning)
3. Explore your dashboard
4. Have fun! 🎉

---

**Time to first success: 2 minutes** ⚡
