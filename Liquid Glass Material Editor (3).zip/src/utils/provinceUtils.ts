// Province color schemes for visual differentiation
export const provinceColors = {
  'Kigali City': {
    bg: 'bg-blue-100',
    text: 'text-blue-700',
    border: 'border-blue-300',
    badge: 'bg-blue-500',
    badgeText: 'text-white',
    gradient: 'from-blue-500 to-blue-600',
    icon: '🏙️',
    emoji: '🏙️'
  },
  'Northern Province': {
    bg: 'bg-green-100',
    text: 'text-green-700',
    border: 'border-green-300',
    badge: 'bg-green-500',
    badgeText: 'text-white',
    gradient: 'from-green-500 to-green-600',
    icon: '🌄',
    emoji: '🌄'
  },
  'Eastern Province': {
    bg: 'bg-orange-100',
    text: 'text-orange-700',
    border: 'border-orange-300',
    badge: 'bg-orange-500',
    badgeText: 'text-white',
    gradient: 'from-orange-500 to-orange-600',
    icon: '🌅',
    emoji: '🌅'
  },
  'Southern Province': {
    bg: 'bg-purple-100',
    text: 'text-purple-700',
    border: 'border-purple-300',
    badge: 'bg-purple-500',
    badgeText: 'text-white',
    gradient: 'from-purple-500 to-purple-600',
    icon: '🏞️',
    emoji: '🏞️'
  },
  'Western Province': {
    bg: 'bg-cyan-100',
    text: 'text-cyan-700',
    border: 'border-cyan-300',
    badge: 'bg-cyan-500',
    badgeText: 'text-white',
    gradient: 'from-cyan-500 to-cyan-600',
    icon: '🌊',
    emoji: '🌊'
  }
};

export function getProvinceColor(province?: string) {
  if (!province) return provinceColors['Kigali City'];
  return provinceColors[province as keyof typeof provinceColors] || provinceColors['Kigali City'];
}

export function getProvinceIcon(province?: string): string {
  const color = getProvinceColor(province);
  return color.emoji;
}

// Helper to get all provinces for filters
export const allProvinces = [
  'Kigali City',
  'Northern Province',
  'Eastern Province',
  'Southern Province',
  'Western Province'
] as const;

export type Province = typeof allProvinces[number];
