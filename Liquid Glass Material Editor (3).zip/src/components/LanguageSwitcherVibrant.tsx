import { Languages, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { useLanguage } from '../contexts/LanguageContext';
import { Language } from '../utils/translations';

export default function LanguageSwitcherVibrant() {
  const { language, setLanguage } = useLanguage();

  const languages: { 
    code: Language; 
    name: string; 
    flag: string;
    gradient: string;
    textColor: string;
    hoverGradient: string;
    badgeColor: string;
  }[] = [
    { 
      code: 'en', 
      name: 'English', 
      flag: '🇬🇧',
      gradient: 'bg-gradient-to-r from-blue-500 to-blue-600',
      textColor: 'text-white',
      hoverGradient: 'hover:from-blue-600 hover:to-blue-700',
      badgeColor: 'bg-blue-600'
    },
    { 
      code: 'rw', 
      name: 'Kinyarwanda', 
      flag: '🇷🇼',
      gradient: 'bg-gradient-to-r from-green-500 to-emerald-600',
      textColor: 'text-white',
      hoverGradient: 'hover:from-green-600 hover:to-emerald-700',
      badgeColor: 'bg-green-600'
    },
    { 
      code: 'fr', 
      name: 'Français', 
      flag: '🇫🇷',
      gradient: 'bg-gradient-to-r from-red-500 to-rose-600',
      textColor: 'text-white',
      hoverGradient: 'hover:from-red-600 hover:to-rose-700',
      badgeColor: 'bg-red-600'
    },
  ];

  const currentLanguage = languages.find((l) => l.code === language);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          size="sm" 
          className={`
            ${currentLanguage?.gradient}
            ${currentLanguage?.textColor}
            ${currentLanguage?.hoverGradient}
            border-0
            shadow-lg
            hover:shadow-xl
            transition-all
            duration-300
            hover:scale-105
            font-medium
          `}
        >
          <Languages className="h-4 w-4 mr-2 animate-pulse" />
          <span className="text-xl mr-2">{currentLanguage?.flag}</span>
          <span>{currentLanguage?.name}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 p-2">
        <div className="text-xs font-medium text-muted-foreground px-2 py-1 mb-1">
          Select Language
        </div>
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className={`
              cursor-pointer
              rounded-lg
              my-1
              py-3
              px-3
              transition-all
              duration-200
              ${language === lang.code 
                ? `${lang.gradient} ${lang.textColor} shadow-md scale-105` 
                : 'hover:bg-gray-100'
              }
            `}
          >
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{lang.flag}</span>
                <span className="font-medium">{lang.name}</span>
              </div>
              {language === lang.code && (
                <Check className="h-5 w-5 animate-in fade-in zoom-in duration-200" />
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
