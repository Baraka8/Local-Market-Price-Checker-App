import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Mail, Smartphone, Key, ArrowLeft, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import {
  createPasswordResetRequest,
  validatePasswordResetToken,
  markPasswordResetTokenUsed,
  sendSMSVerification,
  verifySMSCode,
  getClientIPAddress
} from '../lib/securityEnhancements';
import { isValidEmail, sanitizeEmail, validatePassword } from '../lib/emailValidation';

interface AccountRecoveryProps {
  onBack: () => void;
  onResetComplete: () => void;
}

type RecoveryMethod = 'email' | 'phone' | null;
type RecoveryStep = 'choose' | 'verify' | 'reset';

export function AccountRecovery({ onBack, onResetComplete }: AccountRecoveryProps) {
  const [step, setStep] = useState<RecoveryStep>('choose');
  const [method, setMethod] = useState<RecoveryMethod>(null);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [smsCode, setSmsCode] = useState('');

  // Step 1: Choose recovery method
  const handleMethodSelect = async (selectedMethod: RecoveryMethod) => {
    setMethod(selectedMethod);
    setStep('verify');
  };

  // Step 2: Send verification code
  const handleSendCode = async () => {
    if (method === 'email') {
      const cleanEmail = sanitizeEmail(email);
      if (!isValidEmail(cleanEmail)) {
        toast.error('Please enter a valid email address');
        return;
      }

      setLoading(true);
      try {
        const ipAddress = await getClientIPAddress();
        const { token, expiresIn } = createPasswordResetRequest(cleanEmail, ipAddress);
        setResetToken(token);

        // Simulate email sending
        console.log(`
╔════════════════════════════════════════════╗
║   📧 PASSWORD RESET EMAIL (DEMO)           ║
╠════════════════════════════════════════════╣
║  To: ${cleanEmail.padEnd(38)} ║
║  Subject: Reset Your Password              ║
╠════════════════════════════════════════════╣
║  Reset Code: ${token.substring(0, 16)}...   ║
║  Expires: ${expiresIn} minutes                        ║
╠════════════════════════════════════════════╣
║  Click the link below to reset:            ║
║  https://app.example.com/reset?token=...   ║
╚════════════════════════════════════════════╝
        `);

        toast.success(`Password reset link sent to ${cleanEmail}`);
        setVerificationCode(token.substring(0, 16)); // Show partial token for demo
      } catch (error: any) {
        toast.error(error.message || 'Failed to send reset email');
      } finally {
        setLoading(false);
      }
    } else if (method === 'phone') {
      if (!phone) {
        toast.error('Please enter your phone number');
        return;
      }

      setLoading(true);
      try {
        const { success, code } = await sendSMSVerification(phone, 'User');
        if (success) {
          setSmsCode(code);
          toast.success(`Verification code sent to ${phone}`);
        } else {
          toast.error('Failed to send SMS code');
        }
      } catch (error: any) {
        toast.error(error.message || 'Failed to send SMS');
      } finally {
        setLoading(false);
      }
    }
  };

  // Step 3: Verify code
  const handleVerifyCode = async () => {
    if (method === 'email') {
      const validation = validatePasswordResetToken(resetToken);
      if (!validation.valid) {
        toast.error(validation.error || 'Invalid reset token');
        return;
      }
      setStep('reset');
      toast.success('Verification successful! Set your new password.');
    } else if (method === 'phone') {
      const result = verifySMSCode(phone, verificationCode);
      if (!result.success) {
        toast.error(result.error || 'Invalid verification code');
        return;
      }
      setStep('reset');
      toast.success('Phone verified! Set your new password.');
    }
  };

  // Step 4: Reset password
  const handleResetPassword = async () => {
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    const passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.isValid) {
      toast.error(passwordValidation.errors[0] || 'Password is too weak');
      return;
    }

    setLoading(true);
    try {
      // Mark token as used
      if (resetToken) {
        markPasswordResetTokenUsed(resetToken);
      }

      // Simulate password reset
      await new Promise(resolve => setTimeout(resolve, 1000));

      toast.success('Password reset successful! You can now sign in.');
      onResetComplete();
    } catch (error: any) {
      toast.error(error.message || 'Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  // Render choose method step
  if (step === 'choose') {
    return (
      <Card className="w-full max-w-md p-8 shadow-2xl">
        <Button
          onClick={onBack}
          variant="ghost"
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Login
        </Button>

        <div className="text-center mb-6">
          <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-4 rounded-2xl shadow-lg inline-block mb-4">
            <Key className="h-10 w-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">
            Account Recovery
          </h2>
          <p className="text-muted-foreground text-sm">
            Choose how you'd like to recover your account
          </p>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => handleMethodSelect('email')}
            variant="outline"
            className="w-full h-auto py-4 flex items-start gap-3 hover:bg-blue-50 hover:border-blue-500"
          >
            <Mail className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
            <div className="text-left">
              <div className="font-semibold">Email Recovery</div>
              <div className="text-xs text-muted-foreground">
                Get a password reset link via email
              </div>
            </div>
          </Button>

          <Button
            onClick={() => handleMethodSelect('phone')}
            variant="outline"
            className="w-full h-auto py-4 flex items-start gap-3 hover:bg-green-50 hover:border-green-500"
          >
            <Smartphone className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
            <div className="text-left">
              <div className="font-semibold">Phone Recovery</div>
              <div className="text-xs text-muted-foreground">
                Verify your identity via SMS code
              </div>
            </div>
          </Button>
        </div>

        <div className="mt-6 pt-6 border-t text-center">
          <p className="text-xs text-muted-foreground">
            Need help? Contact support at{' '}
            <a href="mailto:support@rwandamarket.com" className="text-blue-600 hover:underline">
              support@rwandamarket.com
            </a>
          </p>
        </div>
      </Card>
    );
  }

  // Render verify step
  if (step === 'verify') {
    return (
      <Card className="w-full max-w-md p-8 shadow-2xl">
        <Button
          onClick={() => setStep('choose')}
          variant="ghost"
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        <div className="text-center mb-6">
          <div className={`bg-gradient-to-br p-4 rounded-2xl shadow-lg inline-block mb-4 ${
            method === 'email' 
              ? 'from-blue-500 to-indigo-600' 
              : 'from-green-500 to-emerald-600'
          }`}>
            {method === 'email' ? (
              <Mail className="h-10 w-10 text-white" />
            ) : (
              <Smartphone className="h-10 w-10 text-white" />
            )}
          </div>
          <h2 className="text-2xl font-bold mb-2">
            {method === 'email' ? 'Email Verification' : 'Phone Verification'}
          </h2>
          <p className="text-muted-foreground text-sm">
            {method === 'email' 
              ? 'Enter your email to receive a reset link' 
              : 'Enter your phone number to receive a code'}
          </p>
        </div>

        {method === 'email' ? (
          <div className="space-y-4">
            <div>
              <Label htmlFor="recovery-email">Email Address</Label>
              <Input
                id="recovery-email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1.5"
              />
            </div>

            {verificationCode && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-xs font-semibold text-blue-900 mb-2">
                  📧 Demo Mode - Reset Link Generated
                </p>
                <p className="text-xs text-blue-800 mb-2">
                  Token: <code className="bg-blue-100 px-1 py-0.5 rounded font-mono">
                    {verificationCode}...
                  </code>
                </p>
                <Button
                  onClick={handleVerifyCode}
                  size="sm"
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Continue to Reset Password
                </Button>
              </div>
            )}

            <Button
              onClick={handleSendCode}
              disabled={loading || !email}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                'Send Reset Link'
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label htmlFor="recovery-phone">Phone Number</Label>
              <Input
                id="recovery-phone"
                type="tel"
                placeholder="+250788123456"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1.5"
              />
            </div>

            {smsCode && (
              <>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="text-xs font-semibold text-amber-900 mb-1">
                    📱 Demo Mode - SMS Code
                  </p>
                  <p className="text-xs text-amber-800">
                    Code: <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">
                      {smsCode}
                    </code>
                  </p>
                </div>

                <div>
                  <Label htmlFor="sms-verification">Enter 6-digit code</Label>
                  <Input
                    id="sms-verification"
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="000000"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                    className="mt-1.5 text-center text-2xl font-mono tracking-widest"
                  />
                </div>

                <Button
                  onClick={handleVerifyCode}
                  disabled={verificationCode.length !== 6}
                  className="w-full"
                >
                  Verify Code
                </Button>
              </>
            )}

            {!smsCode && (
              <Button
                onClick={handleSendCode}
                disabled={loading || !phone}
                className="w-full"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  'Send Verification Code'
                )}
              </Button>
            )}
          </div>
        )}
      </Card>
    );
  }

  // Render reset password step
  return (
    <Card className="w-full max-w-md p-8 shadow-2xl">
      <div className="text-center mb-6">
        <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-4 rounded-2xl shadow-lg inline-block mb-4">
          <Key className="h-10 w-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold mb-2">
          Reset Password
        </h2>
        <p className="text-muted-foreground text-sm">
          Create a strong new password
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="new-password">New Password</Label>
          <Input
            id="new-password"
            type="password"
            placeholder="Enter new password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-1.5"
          />
          {newPassword && (
            <div className="mt-2">
              {(() => {
                const validation = validatePassword(newPassword);
                return (
                  <div className="text-xs space-y-1">
                    {validation.errors.map((error, index) => (
                      <p key={index} className="text-red-500 flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {error}
                      </p>
                    ))}
                    {validation.isValid && (
                      <p className="text-green-600 flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Strong password!
                      </p>
                    )}
                  </div>
                );
              })()}
            </div>
          )}
        </div>

        <div>
          <Label htmlFor="confirm-password">Confirm Password</Label>
          <Input
            id="confirm-password"
            type="password"
            placeholder="Confirm new password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="mt-1.5"
          />
          {confirmPassword && (
            <p className={`text-xs mt-1 flex items-center gap-1 ${
              newPassword === confirmPassword ? 'text-green-600' : 'text-red-500'
            }`}>
              {newPassword === confirmPassword ? (
                <>
                  <CheckCircle2 className="h-3 w-3" />
                  Passwords match
                </>
              ) : (
                <>
                  <AlertCircle className="h-3 w-3" />
                  Passwords do not match
                </>
              )}
            </p>
          )}
        </div>

        <Button
          onClick={handleResetPassword}
          disabled={loading || !newPassword || !confirmPassword || newPassword !== confirmPassword}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Resetting...
            </>
          ) : (
            <>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Reset Password
            </>
          )}
        </Button>
      </div>
    </Card>
  );
}