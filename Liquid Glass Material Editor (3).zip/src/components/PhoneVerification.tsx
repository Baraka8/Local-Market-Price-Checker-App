import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Smartphone, Loader2, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { sendVerificationSMSAPI } from '../lib/verificationAPI';

interface PhoneVerificationProps {
  phone: string;
  email: string;
  userName: string;
  verificationCode: string; // For demo mode
  onVerify: (code: string) => Promise<void>;
  onCancel: () => void;
  onResend?: () => Promise<void>;
}

export function PhoneVerification({
  phone,
  email,
  userName,
  verificationCode,
  onVerify,
  onCancel,
  onResend
}: PhoneVerificationProps) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [timer, setTimer] = useState(60); // 1 minute
  const [canResend, setCanResend] = useState(false);
  const [resendTimer, setResendTimer] = useState(30); // 30 seconds cooldown

  // Countdown timer
  useEffect(() => {
    if (timer <= 0) return;
    
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  // Resend cooldown timer
  useEffect(() => {
    if (resendTimer <= 0) {
      setCanResend(true);
      return;
    }
    
    const interval = setInterval(() => {
      setResendTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setCanResend(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [resendTimer]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVerify = async () => {
    if (code.length !== 6) {
      setError('Please enter a 6-digit code');
      return;
    }

    if (attempts >= 3) {
      setError('Too many attempts. Please request a new code.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await onVerify(code);
      // Success handled by parent
    } catch (err: any) {
      setAttempts(prev => prev + 1);
      setError(err.message || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!canResend) return;
    
    setResending(true);
    setError('');
    
    try {
      if (onResend) {
        await onResend();
      }
      setTimer(60); // Reset to 1 minute
      setResendTimer(30); // Reset cooldown
      setCanResend(false);
      setAttempts(0); // Reset attempts
      setCode(''); // Clear input
    } catch (err: any) {
      setError(err.message || 'Failed to resend code');
    } finally {
      setResending(false);
    }
  };

  const handleCodeChange = (value: string) => {
    // Only allow digits
    const digitsOnly = value.replace(/\D/g, '').slice(0, 6);
    setCode(digitsOnly);
    setError('');
  };

  return (
    <Card className="w-full max-w-md p-8 shadow-2xl bg-white">
      <div className="flex flex-col items-center mb-6">
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-4 rounded-2xl shadow-lg mb-4">
          <Smartphone className="h-10 w-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-2">
          Phone Verification
        </h2>
        <p className="text-center text-muted-foreground text-sm">
          We sent a 6-digit code to
        </p>
        <p className="text-center font-semibold text-lg">
          {phone}
        </p>
      </div>

      {/* Timer Display */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-blue-600" />
          <span className="text-sm text-blue-900">Code expires in:</span>
        </div>
        <span className={`font-mono font-bold ${
          timer < 60 ? 'text-red-600' : 'text-blue-600'
        }`}>
          {formatTime(timer)}
        </span>
      </div>

      {/* Code Input */}
      <div className="mb-4">
        <Label htmlFor="sms-code" className="mb-2">
          Enter 6-digit code
        </Label>
        <Input
          id="sms-code"
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          maxLength={6}
          value={code}
          onChange={(e) => handleCodeChange(e.target.value)}
          placeholder="000000"
          className="text-center text-2xl font-mono tracking-widest"
          disabled={timer === 0 || attempts >= 3}
          autoFocus
        />
        {error && (
          <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
            <AlertCircle className="h-3 w-3" />
            {error}
          </p>
        )}
      </div>

      {/* Attempts Remaining */}
      {attempts > 0 && attempts < 3 && (
        <div className="mb-4 p-2 bg-orange-50 border border-orange-200 rounded text-xs text-orange-700 text-center">
          ⚠️ {3 - attempts} attempt{3 - attempts !== 1 ? 's' : ''} remaining
        </div>
      )}

      {/* Expired Warning */}
      {timer === 0 && (
        <div className="mb-4 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700 text-center flex items-center justify-center gap-1">
          <AlertCircle className="h-3 w-3" />
          Code expired. Please request a new one.
        </div>
      )}

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          onClick={handleVerify}
          disabled={loading || code.length !== 6 || timer === 0 || attempts >= 3}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Verify Phone Number
            </>
          )}
        </Button>

        <Button
          onClick={handleResend}
          disabled={!canResend || resending}
          variant="outline"
          className="w-full"
        >
          {resending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Sending...
            </>
          ) : !canResend ? (
            <>
              Resend Code ({resendTimer}s)
            </>
          ) : (
            <>
              Resend Code
            </>
          )}
        </Button>

        <Button
          onClick={onCancel}
          variant="ghost"
          className="w-full"
        >
          Cancel
        </Button>
      </div>

      {/* Help Text */}
      <div className="mt-6 pt-4 border-t">
        <p className="text-xs text-center text-muted-foreground mb-2">
          Didn't receive the code?
        </p>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
          <li>Check your phone messages</li>
          <li>Make sure the phone number is correct</li>
          <li>Wait {resendTimer > 0 ? resendTimer : 0}s before requesting a new code</li>
          <li>Contact support if issues persist</li>
        </ul>
      </div>
    </Card>
  );
}