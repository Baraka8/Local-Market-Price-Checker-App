import { Card } from "../ui/card";
import { Button } from "../ui/button";
import {
  Download,
  TrendingUp,
  TrendingDown,
  Users,
  ShoppingCart,
  MapPin,
  Activity,
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { analyticsData } from "../../lib/mockData";

const COLORS = [
  "#3b82f6",
  "#8b5cf6",
  "#ec4899",
  "#f59e0b",
  "#10b981",
];

const weeklyData = [
  { day: "Mon", submissions: 45, searches: 230 },
  { day: "Tue", submissions: 52, searches: 280 },
  { day: "Wed", submissions: 48, searches: 310 },
  { day: "Thu", submissions: 61, searches: 290 },
  { day: "Fri", submissions: 55, searches: 340 },
  { day: "Sat", submissions: 67, searches: 420 },
  { day: "Sun", submissions: 43, searches: 380 },
];

const categoryData = [
  { name: "Groceries", value: 35 },
  { name: "Vegetables", value: 28 },
  { name: "Fruits", value: 18 },
  { name: "Meat & Fish", value: 12 },
  { name: "Other", value: 7 },
];

export default function Analytics() {
  const handleExport = (format: "csv" | "pdf") => {
    alert(`Exporting data as ${format.toUpperCase()}...`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Analytics Dashboard</h2>
          <p className="text-muted-foreground">
            Overview of system activity and trends
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport("csv")}
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport("pdf")}
          >
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">
                Total Users
              </p>
              <p className="text-2xl font-semibold">
                {analyticsData.totalUsers.toLocaleString()}
              </p>
              <p className="text-xs text-green-600 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +12% from last month
              </p>
            </div>
            <Users className="h-8 w-8 text-blue-500" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">
                Active Vendors
              </p>
              <p className="text-2xl font-semibold">
                {analyticsData.activeVendors}
              </p>
              <p className="text-xs text-green-600 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +8% from last month
              </p>
            </div>
            <ShoppingCart className="h-8 w-8 text-purple-500" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">
                Total Markets
              </p>
              <p className="text-2xl font-semibold">
                {analyticsData.totalMarkets}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Across 3 districts
              </p>
            </div>
            <MapPin className="h-8 w-8 text-pink-500" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">
                Updates Today
              </p>
              <p className="text-2xl font-semibold">
                {analyticsData.priceUpdatesToday}
              </p>
              <p className="text-xs text-green-600 flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                Above average
              </p>
            </div>
            <Activity className="h-8 w-8 text-orange-500" />
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Activity */}
        <Card className="p-6">
          <h3 className="text-lg mb-4">Weekly Activity</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weeklyData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#e5e7eb"
              />
              <XAxis dataKey="day" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="submissions"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Submissions"
              />
              <Line
                type="monotone"
                dataKey="searches"
                stroke="#8b5cf6"
                strokeWidth={2}
                name="Searches"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Category Distribution */}
        <Card className="p-6">
          <h3 className="text-lg mb-4">
            Price Submissions by Category
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) =>
                  `${name} ${(percent * 100).toFixed(0)}%`
                }
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Popular Products */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Most Searched Products</h3>
        <div className="space-y-3">
          {analyticsData.popularProducts.map(
            (product, index) => (
              <div
                key={index}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-primary/10 text-primary w-8 h-8 rounded-full flex items-center justify-center text-sm">
                    {index + 1}
                  </div>
                  <span>{product.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-muted-foreground">
                    {product.searches} searches
                  </span>
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full"
                      style={{
                        width: `${(product.searches / 342) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            ),
          )}
        </div>
      </Card>

      {/* Active Markets */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Most Active Markets</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={analyticsData.activeMarkets}>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="#e5e7eb"
            />
            <XAxis dataKey="name" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip />
            <Bar
              dataKey="submissions"
              fill="#3b82f6"
              name="Price Submissions"
            />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Price Alerts */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Recent Price Changes</h3>
        <div className="space-y-3">
          {analyticsData.priceChangeAlerts.map(
            (alert, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  {alert.type === "increase" ? (
                    <TrendingUp className="h-5 w-5 text-red-500" />
                  ) : (
                    <TrendingDown className="h-5 w-5 text-green-500" />
                  )}
                  <div>
                    <p className="font-medium">
                      {alert.product}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {alert.market}
                    </p>
                  </div>
                </div>
                <span
                  className={`font-semibold ${alert.type === "increase" ? "text-red-600" : "text-green-600"}`}
                >
                  {alert.change}
                </span>
              </div>
            ),
          )}
        </div>
      </Card>
    </div>
  );
}