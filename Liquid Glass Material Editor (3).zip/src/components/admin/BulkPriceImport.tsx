import { useState } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Upload, Download, Sparkles, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { generateAllPrices, generateMissingPrices } from '../../lib/autoPriceGenerator';
import { priceData } from '../../lib/mockData';
import { globalPriceSubmissions } from '../../App';

export default function BulkPriceImport() {
  const [importText, setImportText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleAutoGenerate = () => {
    setIsGenerating(true);
    
    // Simulate generation delay
    setTimeout(() => {
      // Generate prices for all products without prices
      const newPrices = generateMissingPrices(priceData);
      
      // Add to global submissions as pre-approved
      newPrices.forEach(price => {
        const submission = {
          id: Math.random().toString(36).substr(2, 9),
          productId: price.productId,
          marketId: price.marketId,
          vendorId: 'system',
          vendorName: 'System Generated',
          price: price.current,
          quantity: 1,
          unit: 'kg',
          submittedAt: new Date(),
          status: 'approved' as const,
          ageInHours: 0
        };
        
        globalPriceSubmissions.push(submission);
      });
      
      setIsGenerating(false);
      toast.success(`Successfully generated ${newPrices.length} prices for products without data!`);
    }, 1500);
  };

  const handleGenerateAll = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      // Generate prices for ALL products in ALL markets
      const allPrices = generateAllPrices();
      
      // Add to global submissions as pre-approved
      allPrices.forEach(price => {
        const submission = {
          id: Math.random().toString(36).substr(2, 9),
          productId: price.productId,
          marketId: price.marketId,
          vendorId: 'system',
          vendorName: 'System Generated',
          price: price.current,
          quantity: 1,
          unit: 'kg',
          submittedAt: new Date(),
          status: 'approved' as const,
          ageInHours: 0
        };
        
        globalPriceSubmissions.push(submission);
      });
      
      setIsGenerating(false);
      toast.success(`Successfully generated ${allPrices.length} prices across all products and markets!`);
    }, 2000);
  };

  const handleBulkImport = () => {
    if (!importText.trim()) {
      toast.error('Please paste CSV data to import');
      return;
    }

    try {
      // Parse CSV format: productId, marketId, price
      const lines = importText.trim().split('\n');
      let successCount = 0;
      let errorCount = 0;

      lines.forEach((line, index) => {
        if (index === 0 && line.toLowerCase().includes('product')) {
          return; // Skip header
        }

        const [productId, marketId, price] = line.split(',').map(s => s.trim());

        if (productId && marketId && price) {
          const submission = {
            id: Math.random().toString(36).substr(2, 9),
            productId,
            marketId,
            vendorId: 'bulk-import',
            vendorName: 'Bulk Import',
            price: parseFloat(price),
            quantity: 1,
            unit: 'kg',
            submittedAt: new Date(),
            status: 'approved' as const,
            ageInHours: 0
          };

          globalPriceSubmissions.push(submission);
          successCount++;
        } else {
          errorCount++;
        }
      });

      if (successCount > 0) {
        toast.success(`Imported ${successCount} prices successfully!`);
        setImportText('');
      }
      if (errorCount > 0) {
        toast.warning(`${errorCount} rows had errors and were skipped`);
      }
    } catch (error) {
      toast.error('Error parsing CSV data. Please check the format.');
    }
  };

  const downloadTemplate = () => {
    const template = `productId,marketId,price
p1,m1,1200
p4,m2,850
p9,m1,3500
p13,m3,5200`;

    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'price_import_template.csv';
    a.click();
    window.URL.revokeObjectURL(url);

    toast.success('Template downloaded!');
  };

  return (
    <div className="space-y-6">
      {/* Auto-Generate Section */}
      <Card className="p-6 bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200">
        <div className="flex items-start gap-4">
          <div className="bg-purple-600 p-3 rounded-lg">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2">🪄 Auto-Generate Prices</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Automatically generate realistic prices for products based on category ranges and market data.
              Perfect for testing or populating the database quickly!
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                onClick={handleAutoGenerate}
                disabled={isGenerating}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Fill Missing Products
                  </>
                )}
              </Button>

              <Button
                onClick={handleGenerateAll}
                disabled={isGenerating}
                variant="outline"
                className="border-purple-300"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin mr-2 h-4 w-4 border-2 border-purple-600 border-t-transparent rounded-full"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate All Products
                  </>
                )}
              </Button>
            </div>

            <div className="mt-4 p-3 bg-purple-100 rounded-lg border border-purple-200">
              <div className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-purple-900">
                  <strong>Fill Missing Products:</strong> Generates prices only for products without any price data
                </div>
              </div>
              <div className="flex items-start gap-2 mt-2">
                <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-purple-900">
                  <strong>Generate All Products:</strong> Creates comprehensive price data across all products and markets
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* CSV Import Section */}
      <Card className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="bg-blue-600 p-3 rounded-lg">
            <Upload className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-2">📊 Bulk CSV Import</h3>
            <p className="text-sm text-muted-foreground">
              Import multiple prices at once using CSV format. Download the template to see the required format.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium">CSV Data</label>
              <Button
                variant="outline"
                size="sm"
                onClick={downloadTemplate}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </Button>
            </div>
            <Textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="productId,marketId,price&#10;p1,m1,1200&#10;p4,m2,850&#10;p9,m1,3500"
              rows={8}
              className="font-mono text-sm"
            />
          </div>

          <Button onClick={handleBulkImport} className="w-full">
            <Upload className="h-4 w-4 mr-2" />
            Import Prices
          </Button>
        </div>

        <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="font-medium text-sm mb-2">CSV Format Guide:</h4>
          <div className="space-y-1 text-xs text-muted-foreground">
            <p>• <strong>Column 1:</strong> Product ID (e.g., p1, p2, p9)</p>
            <p>• <strong>Column 2:</strong> Market ID (e.g., m1, m2, m3)</p>
            <p>• <strong>Column 3:</strong> Price in RWF (e.g., 1200, 850)</p>
            <p>• First row can be a header (will be skipped)</p>
            <p>• All prices are auto-approved when imported by admin</p>
          </div>
        </div>
      </Card>

      {/* Reference IDs */}
      <Card className="p-6 bg-gray-50">
        <h3 className="font-semibold mb-4">Reference IDs</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-medium mb-2">Product IDs:</h4>
            <div className="space-y-1 text-xs font-mono">
              <p><Badge variant="outline">p1</Badge> Rice (Local)</p>
              <p><Badge variant="outline">p2</Badge> Rice (Imported)</p>
              <p><Badge variant="outline">p3</Badge> Beans (Red)</p>
              <p><Badge variant="outline">p4</Badge> Tomatoes</p>
              <p><Badge variant="outline">p5</Badge> Onions</p>
              <p><Badge variant="outline">p9</Badge> Bananas</p>
              <p><Badge variant="outline">p13</Badge> Chicken</p>
              <p className="text-muted-foreground">... and 13 more</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-2">Market IDs:</h4>
            <div className="space-y-1 text-xs font-mono">
              <p><Badge variant="outline" className="bg-blue-50">m1-m5</Badge> 🏙️ Kigali City (5 markets)</p>
              <p><Badge variant="outline" className="bg-green-50">m6-m11</Badge> 🌄 Northern Province (6 markets)</p>
              <p><Badge variant="outline" className="bg-orange-50">m12-m14</Badge> 🌅 Eastern Province (3 markets)</p>
              <p><Badge variant="outline" className="bg-purple-50">m15-m17</Badge> 🏞️ Southern Province (3 markets)</p>
              <p><Badge variant="outline" className="bg-cyan-50">m18-m20</Badge> 🌊 Western Province (3 markets)</p>
              <p className="text-muted-foreground mt-2"><strong>Total: 20 markets across all Rwanda!</strong></p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}