import { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { LogOut, BarChart3, CheckSquare, Users, Settings, Bell, Download, Upload, UserCog } from 'lucide-react';
import type { User, UserRole } from '../../App';
import PriceApprovals from './PriceApprovals';
import Analytics from './Analytics';
import CategoryManagement from './CategoryManagement';
import UserManagement from './UserManagement';
import NotificationManagement from './NotificationManagement';
import BulkPriceImport from './BulkPriceImport';
import UserProfile from '../shared/UserProfile';
import LanguageSwitcher from '../LanguageSwitcherVibrant';
import RoleViewSwitcher from '../RoleViewSwitcher';
import { useLanguage } from '../../contexts/LanguageContext';
import { globalNotifications } from '../../App';
import { Badge } from '../ui/badge';

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
  onViewAsRole: (role: UserRole) => void;
}

export default function AdminDashboard({ user, onLogout, onViewAsRole }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('approvals');
  const { t } = useLanguage();
  const [notificationCount, setNotificationCount] = useState(0);

  useEffect(() => {
    // Update notification count
    const interval = setInterval(() => {
      const unreadCount = globalNotifications.filter(
        n => n.userRole === 'admin' && !n.read
      ).length;
      setNotificationCount(unreadCount);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-600 border-b sticky top-0 z-10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div>
              <h1 className="text-lg text-white">👨‍💼 {t('adminDashboard')}</h1>
              <p className="text-sm text-indigo-100">{t('welcome')}, {user.name}</p>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <RoleViewSwitcher onViewAsRole={onViewAsRole} />
              <Button variant="outline" size="sm" onClick={onLogout} className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <LogOut className="h-4 w-4 mr-2" />
                {t('logout')}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="approvals" className="relative">
              <CheckSquare className="h-4 w-4 mr-2" />
              {t('priceApprovals')}
              {notificationCount > 0 && (
                <Badge className="ml-2 bg-red-500 text-white px-1.5 py-0.5 text-xs">
                  {notificationCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="h-4 w-4 mr-2" />
              {t('analytics')}
            </TabsTrigger>
            <TabsTrigger value="categories">
              <Settings className="h-4 w-4 mr-2" />
              {t('categories')}
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="h-4 w-4 mr-2" />
              {t('users')}
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="h-4 w-4 mr-2" />
              {t('notifications')}
              {notificationCount > 0 && (
                <Badge className="ml-2 bg-red-500 text-white px-1.5 py-0.5 text-xs">
                  {notificationCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="import">
              <Upload className="h-4 w-4 mr-2" />
              {t('bulkPriceImport')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="approvals">
            <PriceApprovals />
          </TabsContent>

          <TabsContent value="analytics">
            <Analytics />
          </TabsContent>

          <TabsContent value="categories">
            <CategoryManagement />
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          <TabsContent value="notifications">
            <NotificationManagement />
          </TabsContent>

          <TabsContent value="import">
            <BulkPriceImport />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}