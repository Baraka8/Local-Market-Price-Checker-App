import { useState } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Plus, Edit, Trash2, MapPin, Tag } from 'lucide-react';
import { categories, markets, products } from '../../lib/mockData';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';

export default function CategoryManagement() {
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);
  const [isAddMarketOpen, setIsAddMarketOpen] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [newMarket, setNewMarket] = useState({ name: '', location: '', district: '' });

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      alert(`Category "${newCategory}" added successfully`);
      setNewCategory('');
      setIsAddCategoryOpen(false);
    }
  };

  const handleAddMarket = () => {
    if (newMarket.name && newMarket.location && newMarket.district) {
      alert(`Market "${newMarket.name}" added successfully`);
      setNewMarket({ name: '', location: '', district: '' });
      setIsAddMarketOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Categories */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Tag className="h-5 w-5 text-primary" />
              <h3 className="text-lg">Product Categories</h3>
            </div>
            <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Category</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="category-name">Category Name</Label>
                    <Input
                      id="category-name"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      placeholder="e.g., Electronics"
                      className="mt-1.5"
                    />
                  </div>
                  <Button onClick={handleAddCategory} className="w-full">
                    Add Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-2">
            {categories.map((category, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Tag className="h-4 w-4 text-muted-foreground" />
                  <span>{category}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">
                    {products.filter(p => p.category === category).length} products
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Markets */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <h3 className="text-lg">Markets</h3>
            </div>
            <Dialog open={isAddMarketOpen} onOpenChange={setIsAddMarketOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Market
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Market</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="market-name">Market Name</Label>
                    <Input
                      id="market-name"
                      value={newMarket.name}
                      onChange={(e) => setNewMarket({ ...newMarket, name: e.target.value })}
                      placeholder="e.g., Kimironko Market"
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="market-location">Location</Label>
                    <Input
                      id="market-location"
                      value={newMarket.location}
                      onChange={(e) => setNewMarket({ ...newMarket, location: e.target.value })}
                      placeholder="e.g., Kimironko"
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="market-district">District</Label>
                    <Input
                      id="market-district"
                      value={newMarket.district}
                      onChange={(e) => setNewMarket({ ...newMarket, district: e.target.value })}
                      placeholder="e.g., Gasabo"
                      className="mt-1.5"
                    />
                  </div>
                  <Button onClick={handleAddMarket} className="w-full">
                    Add Market
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-2">
            {markets.map((market) => (
              <div key={market.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="font-medium">{market.name}</p>
                    <p className="text-sm text-muted-foreground">{market.location}, {market.district}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Products List */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg">All Products ({products.length})</h3>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Product
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {products.slice(0, 12).map((product) => (
            <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">{product.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="secondary" className="text-xs">
                    {product.category}
                  </Badge>
                  <span className="text-xs text-muted-foreground">per {product.unit}</span>
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm">
                  <Edit className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm" className="text-red-600">
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
