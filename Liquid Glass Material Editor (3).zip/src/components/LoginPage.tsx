import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { ShoppingCart, Loader2, CheckCircle2, Smartphone } from 'lucide-react';
import type { UserType, UserRole } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { Language } from '../utils/translations';
import { signIn, signUp, getProfile, supabase } from '../lib/api';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';
import { 
  isValidEmail, 
  validatePassword, 
  sanitizeEmail,
  isDisposableEmail,
  generateVerificationCode
} from '../lib/emailValidation';
import { sendVerificationEmailAPI, sendVerificationSMSAPI } from '../lib/verificationAPI';
import { EmailVerification } from './EmailVerification';
import { PhoneVerification } from './PhoneVerification';
import { AccountRecovery } from './AccountRecovery';
import { TwoFactorAuth } from './TwoFactorAuth';
import {
  validatePhoneNumber,
  verifySMSCode,
  checkRateLimit,
  logActivity,
  detectSuspiciousActivity,
  generateDeviceFingerprint,
  getClientIPAddress,
  resetRateLimit
} from '../lib/securityEnhancements';
import marketBg from 'figma:asset/60f1155b2a59245fd4c0674a279af692c92103ff.png';

interface LoginPageProps {
  onLogin: (user: UserType) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('consumer');
  const [marketId, setMarketId] = useState('');
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const [showPhoneVerification, setShowPhoneVerification] = useState(false);
  const [showAccountRecovery, setShowAccountRecovery] = useState(false);
  const [show2FA, setShow2FA] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [smsVerificationCode, setSmsVerificationCode] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [verifyViaPhone, setVerifyViaPhone] = useState(false);
  const [enable2FA, setEnable2FA] = useState(false);
  const [rateLimitInfo, setRateLimitInfo] = useState<{ remaining: number; blocked: boolean }>({ 
    remaining: 5, 
    blocked: false 
  });
  const { t, language, setLanguage } = useLanguage();

  // Validate email in real-time
  const handleEmailChange = (value: string) => {
    setEmail(value);
    
    if (value && !isValidEmail(value)) {
      setEmailError('Please enter a valid email address');
    } else if (value && isDisposableEmail(value)) {
      setEmailError('Disposable email addresses are not allowed');
    } else {
      setEmailError('');
    }
  };

  // Validate password in real-time
  const handlePasswordChange = (value: string) => {
    setPassword(value);
    
    if (isSignUp && value) {
      const validation = validatePassword(value);
      if (!validation.isValid && value.length >= 6) {
        setPasswordError(validation.errors[0] || 'Password is weak');
      } else {
        setPasswordError('');
      }
    }
  };

  // Validate phone number in real-time
  const handlePhoneChange = (value: string) => {
    setPhone(value);
    
    if (isSignUp && value) {
      const validation = validatePhoneNumber(value);
      if (!validation.isValid) {
        setPhoneError('Invalid phone number format. Use +250788123456');
      } else {
        setPhoneError('');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email
    const cleanEmail = sanitizeEmail(email);
    if (!isValidEmail(cleanEmail)) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    if (isDisposableEmail(cleanEmail)) {
      toast.error('Disposable email addresses are not allowed');
      return;
    }
    
    // Validate password for signup
    if (isSignUp) {
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        toast.error(passwordValidation.errors[0] || 'Password does not meet requirements');
        return;
      }
      
      if (!name.trim()) {
        toast.error('Please enter your full name');
        return;
      }
    }
    
    setLoading(true);

    try {
      if (isSignUp) {
        // Generate verification code
        const code = generateVerificationCode();
        setVerificationCode(code);
        
        // Send verification email or SMS via backend API
        if (verifyViaPhone && phone) {
          const smsCode = generateVerificationCode();
          setSmsVerificationCode(smsCode);
          
          try {
            const result = await sendVerificationSMSAPI(phone, name, smsCode);
            
            if (result.success) {
              toast.success('📱 Verification SMS sent! Check your phone.');
            } else if (result.demoMode) {
              toast.warning('⚠️ SMS service not configured. Running in demo mode.');
              console.log('📱 DEMO MODE - SMS code:', smsCode);
            } else {
              toast.error(result.message || 'Failed to send SMS');
            }
          } catch (error) {
            console.error('Error calling SMS API:', error);
            toast.warning('⚠️ SMS service unavailable. Running in demo mode.');
            console.log('📱 DEMO MODE - SMS code:', smsCode);
          }
          
          setShowPhoneVerification(true);
        } else {
          try {
            const result = await sendVerificationEmailAPI(email, name, code);
            
            if (result.success) {
              toast.success('📧 Verification email sent! Check your inbox.');
            } else if (result.demoMode) {
              toast.warning('⚠️ Email service not configured. Running in demo mode.');
              console.log('📧 DEMO MODE - Verification code:', code);
            } else {
              toast.error(result.message || 'Failed to send email');
            }
          } catch (error) {
            console.error('Error calling email API:', error);
            toast.warning('⚠️ Email service unavailable. Running in demo mode.');
            console.log('📧 DEMO MODE - Verification code:', code);
          }
          
          setShowEmailVerification(true);
        }
        setLoading(false);
      } else {
        // Sign in
        const { session } = await signIn(cleanEmail, password);
        
        if (!session) {
          throw new Error('No session returned');
        }

        // Get user profile
        const profile = await getProfile();
        
        const userData: UserType = {
          id: profile.id,
          name: profile.name,
          email: profile.email,
          role: profile.role,
        };

        onLogin(userData);
        toast.success(`Welcome back, ${userData.name}!`);
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      
      // Better error messages
      let errorMessage = 'Authentication failed';
      if (error.message.includes('Invalid login credentials')) {
        if (isSignUp) {
          errorMessage = 'Invalid email or password. Please check your credentials.';
          toast.error(errorMessage);
        } else {
          // For sign in, check if it's a test account that doesn't exist
          const isTestAccount = email.endsWith('@test.com');
          
          if (isTestAccount) {
            // Show helpful message for test accounts
            errorMessage = `Account "${email}" doesn't exist yet!`;
            toast.error(errorMessage);
            
            setTimeout(() => {
              toast.info(
                '💡 Create this test account first by clicking "Sign Up" below!',
                { duration: 6000 }
              );
            }, 1500);
          } else {
            // For regular accounts
            errorMessage = "Account not found or incorrect password.";
            toast.error(errorMessage);
            
            setTimeout(() => {
              toast.info(
                'New user? Click "Sign Up" below to create an account!',
                { duration: 5000 }
              );
            }, 2000);
          }
          
          setLoading(false);
          return; // Exit early
        }
      } else if (error.message.includes('Email not confirmed')) {
        errorMessage = 'Please confirm your email before signing in.';
      } else if (error.message.includes('User already registered') || error.message.includes('already been registered')) {
        errorMessage = 'This email is already registered. Switching to Sign In...';
        toast.error(errorMessage);
        // Auto-switch to sign in mode
        setTimeout(() => {
          setIsSignUp(false);
          setPassword('');
          toast.info(`Please sign in with ${email}`);
        }, 1500);
        return; // Exit early to prevent showing error twice
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 relative"
      style={{
        backgroundImage: `url(${marketBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Dark overlay for better contrast */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      
      {/* Content */}
      <Card className="w-full max-w-md p-8 shadow-2xl relative z-10 bg-white/95 backdrop-blur-md border-2 border-white/20">
        <div className="flex justify-end mb-4">
          <Select value={language} onValueChange={(value: Language) => setLanguage(value)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">🇬🇧 English</SelectItem>
              <SelectItem value="rw">🇷🇼 Kinyarwanda</SelectItem>
              <SelectItem value="fr">🇫🇷 Français</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-br from-[#1E88E5] to-[#2ECC71] p-4 rounded-2xl shadow-lg">
            <ShoppingCart className="h-10 w-10 text-white" />
          </div>
        </div>
        
        <h1 className="text-center mb-2 bg-gradient-to-r from-[#1E88E5] to-[#2ECC71] bg-clip-text text-transparent">
          {isSignUp ? 'Create Account' : t('loginTitle')}
        </h1>
        <p className="text-center text-muted-foreground mb-6">
          {isSignUp ? 'Join Rwanda Market Price Checker' : t('loginSubtitle')}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="mt-1.5"
              />
            </div>
          )}

          <div>
            <Label htmlFor="email">{t('email')}</Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => handleEmailChange(e.target.value)}
              required
              className="mt-1.5"
            />
            {emailError && <p className="text-xs text-red-500 mt-1">{emailError}</p>}
          </div>

          <div>
            <Label htmlFor="password">{t('password')}</Label>
            <Input
              id="password"
              type="password"
              placeholder={isSignUp ? "Minimum 6 characters" : "Enter your password"}
              value={password}
              onChange={(e) => handlePasswordChange(e.target.value)}
              required
              minLength={6}
              className="mt-1.5"
            />
            {passwordError && <p className="text-xs text-red-500 mt-1">{passwordError}</p>}
          </div>

          {isSignUp && (
            <div>
              <Label htmlFor="phone">
                Phone Number (Optional)
                <span className="text-xs text-muted-foreground ml-2">
                  - For SMS verification & account recovery
                </span>
              </Label>
              <Input
                id="phone"
                type="tel"
                placeholder="e.g., +250788123456 or 0788123456"
                value={phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                className="mt-1.5"
              />
              {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
              {phone && !phoneError && (
                <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Valid Rwanda phone number
                </p>
              )}
              <div className="flex items-center gap-2 mt-2">
                <Checkbox
                  id="verifyViaPhone"
                  checked={verifyViaPhone}
                  onCheckedChange={(checked) => setVerifyViaPhone(checked as boolean)}
                />
                <Label htmlFor="verifyViaPhone" className="text-sm cursor-pointer flex items-center gap-1">
                  <Smartphone className="h-3 w-3" />
                  Verify via SMS instead of email
                </Label>
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="role">{isSignUp ? 'I am a:' : t('loginAs')}</Label>
            <Select value={role} onValueChange={(value: UserRole) => setRole(value)}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="consumer">👤 {t('consumer')}</SelectItem>
                <SelectItem value="vendor">🏪 {t('vendor')}</SelectItem>
                <SelectItem value="business">💼 {t('business')}</SelectItem>
                <SelectItem value="admin">⚙️ {t('admin')}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isSignUp && role === 'vendor' && (
            <div>
              <Label htmlFor="marketId">Market ID (Optional)</Label>
              <Input
                id="marketId"
                type="text"
                placeholder="e.g., kimironko-market"
                value={marketId}
                onChange={(e) => setMarketId(e.target.value)}
                className="mt-1.5"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Your primary market location
              </p>
            </div>
          )}

          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-[#1E88E5] to-[#2ECC71] hover:from-[#1565C0] hover:to-[#27AE60]"
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {isSignUp ? 'Creating Account...' : 'Signing In..'}
              </>
            ) : (
              isSignUp ? 'Create Account' : t('signIn')
            )}
          </Button>
        </form>

        <div className="mt-6 pt-6 border-t">
          <button
            type="button"
            onClick={() => {
              setIsSignUp(!isSignUp);
              setPassword('');
            }}
            className="text-sm text-center w-full text-blue-600 hover:text-blue-700 font-medium"
          >
            {isSignUp 
              ? 'Already have an account? Sign In' 
              : "Don't have an account? Sign Up"}
          </button>
        </div>

        {!isSignUp && (
          <>
            <div className="mt-4 pt-4 border-t">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                <h3 className="text-sm font-semibold text-amber-900 mb-2 flex items-center gap-2">
                  <span className="text-lg">⚠️</span> First Time Here?
                </h3>
                <p className="text-xs text-amber-800 mb-3">
                  Test accounts need to be <strong>created first</strong>. Here's how:
                </p>
                <ol className="text-xs text-amber-800 space-y-1.5 ml-4 list-decimal">
                  <li>Click <strong>\"Sign Up\"</strong> below</li>
                  <li>Enter: <code className="bg-amber-100 px-1 py-0.5 rounded">admin@test.com</code></li>
                  <li>Password: <code className="bg-amber-100 px-1 py-0.5 rounded">admin123</code></li>
                  <li>Name: <code className="bg-amber-100 px-1 py-0.5 rounded">Admin User</code></li>
                  <li>Select role: <strong>Admin</strong></li>
                  <li>Click \"Create Account\"</li>
                  <li>Done! You're logged in automatically!</li>
                </ol>
              </div>
              
              <p className="text-xs text-center text-muted-foreground mb-3">
                Quick Fill Test Credentials:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setEmail('admin@test.com');
                    setPassword('admin123');
                    setRole('admin');
                  }}
                  className="text-xs"
                >
                  👨‍💼 Admin
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setEmail('vendor@test.com');
                    setPassword('vendor123');
                    setRole('vendor');
                  }}
                  className="text-xs"
                >
                  🏪 Vendor
                </Button>
              </div>
              <p className="text-xs text-center text-muted-foreground mt-2">
                Click to auto-fill credentials
              </p>
            </div>
            
            <div className="mt-4 pt-4 border-t">
              <p className="text-xs text-center text-muted-foreground">
                🔒 Secure authentication powered by Supabase
              </p>
            </div>
          </>
        )}
        
        {isSignUp && (
          <div className="mt-4 pt-4 border-t">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="text-sm font-semibold text-blue-900 mb-2 flex items-center gap-2">
                <span className="text-lg">💡</span> Creating Test Accounts
              </h3>
              <div className="space-y-3">
                <div className="bg-white rounded p-2 border border-blue-100">
                  <p className="text-xs font-semibold text-blue-900 mb-1">👨‍💼 Admin Account:</p>
                  <ul className="text-xs text-blue-800 space-y-0.5 ml-2">
                    <li>Email: <code className="bg-blue-100 px-1 py-0.5 rounded">admin@test.com</code></li>
                    <li>Password: <code className="bg-blue-100 px-1 py-0.5 rounded">admin123</code></li>
                    <li>Name: Admin User</li>
                    <li>Role: Admin</li>
                  </ul>
                </div>
                <div className="bg-white rounded p-2 border border-blue-100">
                  <p className="text-xs font-semibold text-blue-900 mb-1">🏪 Vendor Account:</p>
                  <ul className="text-xs text-blue-800 space-y-0.5 ml-2">
                    <li>Email: <code className="bg-blue-100 px-1 py-0.5 rounded">vendor@test.com</code></li>
                    <li>Password: <code className="bg-blue-100 px-1 py-0.5 rounded">vendor123</code></li>
                    <li>Name: Vendor User</li>
                    <li>Role: Vendor</li>
                  </ul>
                </div>
                <p className="text-xs text-blue-700 italic mt-2">
                  ✨ Tip: Fill these in above and click \"Create Account\"!
                </p>
              </div>
            </div>
          </div>
        )}
        
        {showEmailVerification && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <EmailVerification
              email={email}
              userName={name}
              verificationCode={verificationCode}
              onVerify={async (code: string) => {
                if (code === verificationCode) {
                  // Sign up
                  await signUp({
                    email,
                    password,
                    name,
                    role,
                    marketId: role === 'vendor' ? marketId : undefined,
                  });

                  toast.success('Account created successfully! Signing you in...');
                  
                  // Wait a moment for account to be ready
                  await new Promise(resolve => setTimeout(resolve, 1000));
                  
                  // Auto sign in after signup
                  try {
                    const { session } = await signIn(email, password);
                    
                    if (!session) {
                      throw new Error('No session returned');
                    }

                    // Get user profile
                    const profile = await getProfile();
                    
                    const userData: UserType = {
                      id: profile.id,
                      name: profile.name,
                      email: profile.email,
                      role: profile.role,
                    };

                    onLogin(userData);
                    toast.success(`Welcome, ${userData.name}!`);
                  } catch (error) {
                    // If auto-login fails, just show success and let them login manually
                    console.error('Auto-login error:', error);
                    toast.info('Please sign in with your new account');
                    setIsSignUp(false);
                    setPassword('');
                    setShowEmailVerification(false);
                  }
                } else {
                  toast.error('Incorrect verification code');
                }
              }}
              onCancel={() => {
                setShowEmailVerification(false);
                setLoading(false);
              }}
            />
          </div>
        )}
        
        {showPhoneVerification && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <PhoneVerification
              phone={phone}
              email={email}
              userName={name}
              verificationCode={smsVerificationCode}
              onVerify={async (code: string) => {
                if (code === smsVerificationCode) {
                  // Sign up
                  await signUp({
                    email,
                    password,
                    name,
                    role,
                    marketId: role === 'vendor' ? marketId : undefined,
                  });

                  toast.success('Account created successfully! Signing you in...');
                  
                  // Wait a moment for account to be ready
                  await new Promise(resolve => setTimeout(resolve, 1000));
                  
                  // Auto sign in after signup
                  try {
                    const { session } = await signIn(email, password);
                    
                    if (!session) {
                      throw new Error('No session returned');
                    }

                    // Get user profile
                    const profile = await getProfile();
                    
                    const userData: UserType = {
                      id: profile.id,
                      name: profile.name,
                      email: profile.email,
                      role: profile.role,
                    };

                    onLogin(userData);
                    toast.success(`Welcome, ${userData.name}!`);
                  } catch (error) {
                    // If auto-login fails, just show success and let them login manually
                    console.error('Auto-login error:', error);
                    toast.info('Please sign in with your new account');
                    setIsSignUp(false);
                    setPassword('');
                    setShowPhoneVerification(false);
                  }
                } else {
                  toast.error('Incorrect verification code');
                }
              }}
              onCancel={() => {
                setShowPhoneVerification(false);
                setLoading(false);
              }}
            />
          </div>
        )}
        
        {showAccountRecovery && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <AccountRecovery
              onBack={() => setShowAccountRecovery(false)}
              onResetComplete={() => {
                setShowAccountRecovery(false);
                toast.success('Password reset successfully! Please sign in with your new password.');
              }}
            />
          </div>
        )}
        
        {show2FA && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <TwoFactorAuth
              email={email}
              phone={phone}
              onVerify={async (code: string, method) => {
                // Verify 2FA code
                toast.success('2FA verified successfully!');
                setShow2FA(false);
                
                // Complete sign in
                try {
                  const { session } = await signIn(email, password);
                  
                  if (!session) {
                    throw new Error('No session returned');
                  }

                  const profile = await getProfile();
                  
                  const userData: UserType = {
                    id: profile.id,
                    name: profile.name,
                    email: profile.email,
                    role: profile.role,
                  };

                  onLogin(userData);
                  toast.success(`Welcome back, ${userData.name}!`);
                } catch (error: any) {
                  toast.error(error.message || 'Sign in failed');
                }
              }}
              onCancel={() => {
                setShow2FA(false);
              }}
            />
          </div>
        )}
      </Card>
    </div>
  );
}