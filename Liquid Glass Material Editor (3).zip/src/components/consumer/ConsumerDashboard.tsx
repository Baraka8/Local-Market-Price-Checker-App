import { useState } from 'react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { LogOut, Search, TrendingUp, Heart, Bell, AlertCircle, User as UserIcon, ArrowLeft } from 'lucide-react';
import type { User } from '../../App';
import ProductSearch from './ProductSearch';
import PriceComparison from './PriceComparison';
import PriceTrends from './PriceTrends';
import Favorites from './Favorites';
import Notifications from './Notifications';
import PriceAlerts from './PriceAlerts';
import UserProfile from '../shared/UserProfile';
import LanguageSwitcher from '../LanguageSwitcherVibrant';
import { useLanguage } from '../../contexts/LanguageContext';

interface ConsumerDashboardProps {
  user: User;
  onLogout: () => void;
  isAdminViewing?: boolean;
  onReturnToAdmin?: () => void;
}

export default function ConsumerDashboard({ user, onLogout, isAdminViewing, onReturnToAdmin }: ConsumerDashboardProps) {
  const [activeTab, setActiveTab] = useState('search');
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-indigo-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-600 border-b sticky top-0 z-10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div>
              <h1 className="text-lg text-white">👤 {t('consumerDashboard')}</h1>
              <p className="text-sm text-blue-100">{t('welcome')}, {user.name}</p>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <Button variant="outline" size="sm" onClick={onLogout} className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <LogOut className="h-4 w-4 mr-2" />
                {t('logout')}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Admin Viewing Banner */}
        {isAdminViewing && onReturnToAdmin && (
          <div className="mb-6 bg-indigo-50 border border-indigo-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-indigo-700">👨‍💼 You are viewing the Consumer Dashboard as Admin</span>
              </div>
              <Button 
                onClick={onReturnToAdmin}
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Return to Admin Dashboard
              </Button>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="search">
              <Search className="h-4 w-4 mr-2" />
              {t('searchProducts')}
            </TabsTrigger>
            <TabsTrigger value="compare">
              <TrendingUp className="h-4 w-4 mr-2" />
              {t('comparePrices')}
            </TabsTrigger>
            <TabsTrigger value="trends">
              <TrendingUp className="h-4 w-4 mr-2" />
              {t('priceTrends')}
            </TabsTrigger>
            <TabsTrigger value="favorites">
              <Heart className="h-4 w-4 mr-2" />
              {t('favorites')}
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="h-4 w-4 mr-2" />
              {t('notifications')}
            </TabsTrigger>
            <TabsTrigger value="alerts">
              <AlertCircle className="h-4 w-4 mr-2" />
              {t('priceAlerts')}
            </TabsTrigger>
            <TabsTrigger value="profile">
              <UserIcon className="h-4 w-4 mr-2" />
              {t('profile')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="search">
            <ProductSearch />
          </TabsContent>

          <TabsContent value="compare">
            <PriceComparison />
          </TabsContent>

          <TabsContent value="trends">
            <PriceTrends />
          </TabsContent>

          <TabsContent value="favorites">
            <Favorites userId={user.id} />
          </TabsContent>

          <TabsContent value="notifications">
            <Notifications />
          </TabsContent>

          <TabsContent value="alerts">
            <PriceAlerts userId={user.id} />
          </TabsContent>

          <TabsContent value="profile">
            <UserProfile user={user} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}