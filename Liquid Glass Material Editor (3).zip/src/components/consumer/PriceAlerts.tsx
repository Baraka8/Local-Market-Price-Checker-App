import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Bell, BellOff, Trash2, Plus, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Input } from '../ui/input';
import { products, markets } from '../../lib/mockData';
import { getPriceAlerts, addPriceAlert, removePriceAlert, togglePriceAlert, type StoredPriceAlert } from '../../lib/localStorage';
import { toast } from 'sonner@2.0.3';
import { useLanguage } from '../../contexts/LanguageContext';

interface PriceAlertsProps {
  userId: string;
}

export default function PriceAlerts({ userId }: PriceAlertsProps) {
  const [alerts, setAlerts] = useState<StoredPriceAlert[]>([]);
  const [isAddAlertOpen, setIsAddAlertOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [selectedMarket, setSelectedMarket] = useState('');
  const [alertType, setAlertType] = useState<'increase' | 'decrease' | 'any'>('any');
  const [threshold, setThreshold] = useState('10');
  const { t } = useLanguage();

  useEffect(() => {
    loadAlerts();
  }, [userId]);

  const loadAlerts = () => {
    const storedAlerts = getPriceAlerts(userId);
    setAlerts(storedAlerts);
  };

  const handleAddAlert = () => {
    if (!selectedProduct || !selectedMarket || !threshold) {
      toast.error('Please fill all fields');
      return;
    }

    const newAlert: StoredPriceAlert = {
      id: Math.random().toString(36).substr(2, 9),
      productId: selectedProduct,
      marketId: selectedMarket,
      threshold: parseFloat(threshold),
      type: alertType,
      createdAt: new Date().toISOString(),
      userId,
      enabled: true,
    };

    addPriceAlert(newAlert);
    loadAlerts();
    
    toast.success('Price alert created successfully!');
    setIsAddAlertOpen(false);
    setSelectedProduct('');
    setSelectedMarket('');
    setThreshold('10');
    setAlertType('any');
  };

  const handleToggleAlert = (alertId: string) => {
    togglePriceAlert(userId, alertId);
    loadAlerts();
    
    const alert = alerts.find(a => a.id === alertId);
    if (alert) {
      toast.success(alert.enabled ? 'Alert disabled' : 'Alert enabled');
    }
  };

  const handleDeleteAlert = (alertId: string) => {
    removePriceAlert(userId, alertId);
    loadAlerts();
    toast.success('Alert deleted');
  };

  const getProductName = (productId: string) => {
    const product = products.find(p => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  const getMarketName = (marketId: string) => {
    const market = markets.find(m => m.id === marketId);
    return market?.name || 'Unknown Market';
  };

  const getAlertTypeIcon = (type: string) => {
    switch (type) {
      case 'increase':
        return <TrendingUp className="h-4 w-4" />;
      case 'decrease':
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getAlertTypeColor = (type: string) => {
    switch (type) {
      case 'increase':
        return 'bg-red-100 text-red-700';
      case 'decrease':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-blue-100 text-blue-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Price Alerts</h2>
          <p className="text-muted-foreground">
            Get notified when prices change
          </p>
        </div>
        
        <Dialog open={isAddAlertOpen} onOpenChange={setIsAddAlertOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Alert
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Price Alert</DialogTitle>
              <DialogDescription>
                Set up an alert to be notified when a product's price changes
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 mt-4">
              <div>
                <Label htmlFor="alert-product">Product</Label>
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger id="alert-product" className="mt-1.5">
                    <SelectValue placeholder="Select product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map(product => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="alert-market">Market</Label>
                <Select value={selectedMarket} onValueChange={setSelectedMarket}>
                  <SelectTrigger id="alert-market" className="mt-1.5">
                    <SelectValue placeholder="Select market" />
                  </SelectTrigger>
                  <SelectContent>
                    {markets.map(market => (
                      <SelectItem key={market.id} value={market.id}>
                        {market.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="alert-type">Alert Type</Label>
                <Select value={alertType} onValueChange={(value: any) => setAlertType(value)}>
                  <SelectTrigger id="alert-type" className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any price change</SelectItem>
                    <SelectItem value="increase">Price increase only</SelectItem>
                    <SelectItem value="decrease">Price decrease only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="alert-threshold">Threshold (%)</Label>
                <Input
                  id="alert-threshold"
                  type="number"
                  value={threshold}
                  onChange={(e) => setThreshold(e.target.value)}
                  placeholder="10"
                  min="1"
                  max="100"
                  className="mt-1.5"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Notify me when price changes by at least {threshold}%
                </p>
              </div>

              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsAddAlertOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleAddAlert} className="flex-1">
                  Create Alert
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Alerts List */}
      {alerts.length === 0 ? (
        <Card className="p-12 text-center">
          <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg mb-2">No Price Alerts</h3>
          <p className="text-muted-foreground mb-4">
            Create your first alert to get notified about price changes
          </p>
          <Button onClick={() => setIsAddAlertOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Create Alert
          </Button>
        </Card>
      ) : (
        <div className="grid gap-4">
          {alerts.map(alert => (
            <Card key={alert.id} className={`p-4 ${!alert.enabled && 'opacity-50'}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium">{getProductName(alert.productId)}</h3>
                    <Badge variant="outline" className={getAlertTypeColor(alert.type)}>
                      <span className="flex items-center gap-1">
                        {getAlertTypeIcon(alert.type)}
                        {alert.type === 'increase' && 'Price Increase'}
                        {alert.type === 'decrease' && 'Price Decrease'}
                        {alert.type === 'any' && 'Any Change'}
                      </span>
                    </Badge>
                    {!alert.enabled && (
                      <Badge variant="secondary">Disabled</Badge>
                    )}
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-1">
                    {getMarketName(alert.marketId)}
                  </p>
                  
                  <p className="text-sm text-muted-foreground">
                    Threshold: {alert.threshold}% change
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleToggleAlert(alert.id)}
                  >
                    {alert.enabled ? (
                      <>
                        <BellOff className="h-4 w-4 mr-2" />
                        Disable
                      </>
                    ) : (
                      <>
                        <Bell className="h-4 w-4 mr-2" />
                        Enable
                      </>
                    )}
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteAlert(alert.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Info Box */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-900 mb-1">How Price Alerts Work</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Alerts check prices when new submissions are approved</li>
              <li>• You'll receive a notification when the threshold is reached</li>
              <li>• Disable alerts temporarily without deleting them</li>
              <li>• Set different alerts for the same product across markets</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
