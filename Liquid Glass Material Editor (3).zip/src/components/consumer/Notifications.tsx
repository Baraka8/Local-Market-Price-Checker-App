import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Bell, TrendingUp, TrendingDown, Info, AlertTriangle } from 'lucide-react';

const notifications = [
  {
    id: '1',
    type: 'price_decrease',
    title: 'Price Drop Alert',
    message: 'Tomatoes price decreased by 12% in Nyabugogo Market',
    time: '2 hours ago',
    read: false,
    icon: <TrendingDown className="h-5 w-5 text-green-500" />
  },
  {
    id: '2',
    type: 'price_increase',
    title: 'Price Increase',
    message: 'Rice (Local) price increased by 8% in Kimironko Market',
    time: '5 hours ago',
    read: false,
    icon: <TrendingUp className="h-5 w-5 text-red-500" />
  },
  {
    id: '3',
    type: 'favorite_update',
    title: 'Favorite Product Update',
    message: 'Onions prices updated in your favorite markets',
    time: '1 day ago',
    read: true,
    icon: <Info className="h-5 w-5 text-blue-500" />
  },
  {
    id: '4',
    type: 'system',
    title: 'New Feature',
    message: 'You can now compare prices across multiple markets',
    time: '2 days ago',
    read: true,
    icon: <Bell className="h-5 w-5 text-purple-500" />
  }
];

export default function Notifications() {
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h2 className="text-xl">Notifications</h2>
            {unreadCount > 0 && (
              <Badge className="bg-red-500">{unreadCount} new</Badge>
            )}
          </div>
        </div>

        <div className="space-y-3">
          {notifications.map(notification => (
            <div
              key={notification.id}
              className={`p-4 rounded-lg border ${
                notification.read
                  ? 'bg-gray-50 border-gray-200'
                  : 'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex gap-3">
                <div className="flex-shrink-0 mt-0.5">
                  {notification.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <p className={`font-medium ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                        {notification.title}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {notification.message}
                      </p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {notification.time}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Notification Settings */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Notification Settings</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <TrendingUp className="h-5 w-5 text-red-500" />
              <span>Price increase alerts</span>
            </div>
            <Badge>Enabled</Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <TrendingDown className="h-5 w-5 text-green-500" />
              <span>Price drop alerts</span>
            </div>
            <Badge>Enabled</Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Info className="h-5 w-5 text-blue-500" />
              <span>Favorite product updates</span>
            </div>
            <Badge>Enabled</Badge>
          </div>
        </div>
      </Card>
    </div>
  );
}
