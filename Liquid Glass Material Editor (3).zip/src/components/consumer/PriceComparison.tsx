import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { MapPin, TrendingUp, TrendingDown, Star, Clock, AlertTriangle, ThumbsUp, Plus, Bell } from 'lucide-react';
import { products, markets, priceData } from '../../lib/mockData';
import PriceCardSkeleton from '../utils/PriceCardSkeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Textarea } from '../ui/textarea';
import { toast } from 'sonner@2.0.3';
import { getProvinceColor, getProvinceIcon, allProvinces } from '../../utils/provinceUtils';

export default function PriceComparison() {
  const [selectedProduct, setSelectedProduct] = useState('p1');
  const [selectedProvince, setSelectedProvince] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [selectedPriceForReview, setSelectedPriceForReview] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewComment, setReviewComment] = useState('');

  // Simulate loading when changing products
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, [selectedProduct]);

  // Filter by product and province
  const productPrices = priceData.filter(p => {
    const matchesProduct = p.productId === selectedProduct;
    if (!matchesProduct) return false;
    
    if (selectedProvince === 'all') return true;
    
    const market = markets.find(m => m.id === p.marketId);
    return market?.province === selectedProvince;
  });
  
  const product = products.find(p => p.id === selectedProduct);

  const getAgeInHours = (lastUpdated: Date) => {
    return Math.floor((Date.now() - lastUpdated.getTime()) / (1000 * 60 * 60));
  };

  const getAgeWarning = (hours: number) => {
    if (hours > 48) return { level: 'high', text: 'Outdated', color: 'text-red-600 bg-red-50' };
    if (hours > 24) return { level: 'medium', text: 'Check freshness', color: 'text-orange-600 bg-orange-50' };
    return { level: 'low', text: 'Fresh', color: 'text-green-600 bg-green-50' };
  };

  const handleSubmitReview = () => {
    if (reviewRating === 0) {
      toast.error('Please select a rating');
      return;
    }
    
    toast.success('Thank you for your review!');
    setShowReviewDialog(false);
    setReviewRating(0);
    setReviewComment('');
    setSelectedPriceForReview(null);
  };

  const handleRequestPrice = () => {
    toast.success(`Price request sent for ${product?.name}. You'll be notified when vendors add prices!`);
  };

  const handleSetPriceAlert = () => {
    toast.success(`Price alert set for ${product?.name}. You'll be notified when new prices are added!`);
  };

  return (
    <div className="space-y-6">
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <Select value={selectedProduct} onValueChange={setSelectedProduct}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {products.map(product => (
                  <SelectItem key={product.id} value={product.id}>
                    {product.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Select value={selectedProvince} onValueChange={setSelectedProvince}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Provinces</SelectItem>
                {allProvinces.map(province => (
                  <SelectItem key={province} value={province}>
                    {province}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h2 className="text-xl mb-4">{product?.name} - Market Comparison</h2>
        
        {isLoading ? (
          <div className="space-y-3">
            <PriceCardSkeleton />
            <PriceCardSkeleton />
            <PriceCardSkeleton />
          </div>
        ) : (
          <div className="space-y-3">
            {productPrices.length > 0 ? (
              productPrices.map(price => {
                const market = markets.find(m => m.id === price.marketId);
                const lowestPrice = Math.min(...productPrices.map(p => p.current));
                const isLowest = price.current === lowestPrice;
                const ageInHours = getAgeInHours(price.lastUpdated);
                const ageWarning = getAgeWarning(ageInHours);
                const priceKey = `${price.productId}-${price.marketId}`;

                return (
                  <div key={price.marketId} className={`p-4 rounded-lg border-2 ${
                    isLowest ? 'border-green-500 bg-green-50' : 'border-gray-200 bg-gray-50'
                  }`}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <h3 className="font-medium">{market?.name}</h3>
                          {market?.province && (() => {
                            const provinceColors = getProvinceColor(market.province);
                            return (
                              <Badge className={`${provinceColors.badge} ${provinceColors.badgeText} text-xs`}>
                                {provinceColors.emoji} {market.province.replace(' Province', '')}
                              </Badge>
                            );
                          })()}
                          {isLowest && <Badge className="bg-green-600">Lowest Price</Badge>}
                          <Badge className={`${ageWarning.color} border-0`}>
                            <Clock className="h-3 w-3 mr-1" />
                            {ageWarning.text}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{market?.location}, {market?.district}</p>
                        
                        {/* Rating Display */}
                        {price.rating && (
                          <div className="flex items-center gap-2 mt-2">
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`h-4 w-4 ${
                                    star <= Math.round(price.rating!) 
                                      ? 'fill-yellow-400 text-yellow-400' 
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {price.rating.toFixed(1)} ({price.totalRatings} reviews)
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-semibold text-primary">
                          {price.current.toLocaleString()} RWF
                        </p>
                        <div className="flex items-center justify-end gap-1 mt-1">
                          {price.trend === 'up' ? (
                            <TrendingUp className="h-4 w-4 text-red-500" />
                          ) : price.trend === 'down' ? (
                            <TrendingDown className="h-4 w-4 text-green-500" />
                          ) : null}
                          <span className={`text-sm ${
                            price.trend === 'up' ? 'text-red-600' :
                            price.trend === 'down' ? 'text-green-600' :
                            'text-gray-600'
                          }`}>
                            {price.trend === 'up' ? 'Rising' :
                             price.trend === 'down' ? 'Falling' :
                             'Stable'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-3 pt-3 border-t">
                      <div>
                        <p className="text-xs text-muted-foreground">Average</p>
                        <p className="font-medium">{price.average.toLocaleString()} RWF</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Highest</p>
                        <p className="font-medium">{price.highest.toLocaleString()} RWF</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Last Updated</p>
                        <p className="font-medium text-xs">
                          {ageInHours < 1 ? 'Just now' : `${ageInHours}h ago`}
                        </p>
                      </div>
                    </div>

                    {/* Reviews Section */}
                    {price.reviews && price.reviews.length > 0 && (
                      <div className="mt-3 pt-3 border-t space-y-2">
                        <h4 className="text-sm font-medium">Recent Reviews</h4>
                        {price.reviews.slice(0, 2).map(review => (
                          <div key={review.id} className="bg-white p-3 rounded-md border">
                            <div className="flex items-start justify-between mb-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">{review.userName}</span>
                                <div className="flex">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-3 w-3 ${
                                        star <= review.rating 
                                          ? 'fill-yellow-400 text-yellow-400' 
                                          : 'text-gray-300'
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {Math.floor((Date.now() - review.createdAt.getTime()) / (1000 * 60 * 60 * 24))}d ago
                              </span>
                            </div>
                            {review.comment && (
                              <p className="text-sm text-muted-foreground">{review.comment}</p>
                            )}
                            <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                              <ThumbsUp className="h-3 w-3" />
                              <span>{review.helpful} found helpful</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add Review Button */}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-3"
                      onClick={() => {
                        setSelectedPriceForReview(priceKey);
                        setShowReviewDialog(true);
                      }}
                    >
                      <Star className="h-4 w-4 mr-2" />
                      Rate this price
                    </Button>
                  </div>
                );
              })
            ) : (
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-dashed border-blue-200 rounded-lg p-8">
                <div className="text-center max-w-md mx-auto">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No Price Data Available</h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    We don't have price information for <span className="font-semibold">{product?.name}</span> yet. 
                    Help us build our database!
                  </p>
                  
                  <div className="space-y-3">
                    {/* Submit Your Own Price */}
                    <Card className="p-4 bg-white hover:shadow-md transition-shadow cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                      <a href="#submit-price" className="block">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-600 p-2 rounded-lg">
                            <Plus className="h-5 w-5 text-white" />
                          </div>
                          <div className="text-left flex-1">
                            <p className="font-semibold">Submit a Price</p>
                            <p className="text-xs text-muted-foreground">
                              Know the current price? Share it with the community
                            </p>
                          </div>
                        </div>
                      </a>
                    </Card>

                    {/* Request Price from Vendors */}
                    <Card className="p-4 bg-white hover:shadow-md transition-shadow cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                      <div className="block" onClick={handleRequestPrice}>
                        <div className="flex items-center gap-3">
                          <div className="bg-purple-600 p-2 rounded-lg">
                            <MapPin className="h-5 w-5 text-white" />
                          </div>
                          <div className="text-left flex-1">
                            <p className="font-semibold">Request from Vendors</p>
                            <p className="text-xs text-muted-foreground">
                              Notify vendors to add prices for this product
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>

                    {/* Set Price Alert */}
                    <Card className="p-4 bg-white hover:shadow-md transition-shadow cursor-pointer border-2 border-green-200 hover:border-green-400">
                      <div className="block" onClick={handleSetPriceAlert}>
                        <div className="flex items-center gap-3">
                          <div className="bg-green-600 p-2 rounded-lg">
                            <Bell className="h-5 w-5 text-white" />
                          </div>
                          <div className="text-left flex-1">
                            <p className="font-semibold">Set Price Alert</p>
                            <p className="text-xs text-muted-foreground">
                              Get notified when prices become available
                            </p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-xs text-blue-800">
                      <strong>💡 Tip:</strong> You can also browse other products that have price data available, 
                      or check back later as vendors continuously update prices.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rate this price</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Your Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewRating(star)}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`h-8 w-8 cursor-pointer transition-colors ${
                        star <= reviewRating 
                          ? 'fill-yellow-400 text-yellow-400' 
                          : 'text-gray-300 hover:text-yellow-200'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Comment (Optional)</label>
              <Textarea
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="Share your experience with this price..."
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSubmitReview} className="flex-1">
                Submit Review
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowReviewDialog(false);
                  setReviewRating(0);
                  setReviewComment('');
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}