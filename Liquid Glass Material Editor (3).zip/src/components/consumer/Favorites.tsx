import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Heart, MapPin, TrendingUp, TrendingDown, Trash2 } from 'lucide-react';
import { products, markets, priceData } from '../../lib/mockData';
import { useState, useEffect } from 'react';
import { getFavorites, removeFavorite, type StoredFavorite } from '../../lib/localStorage';
import { toast } from 'sonner@2.0.3';

interface FavoritesProps {
  userId: string;
}

export default function Favorites({ userId }: FavoritesProps) {
  const [favorites, setFavorites] = useState<StoredFavorite[]>([]);

  useEffect(() => {
    loadFavorites();
  }, [userId]);

  const loadFavorites = () => {
    const storedFavorites = getFavorites(userId);
    setFavorites(storedFavorites);
  };

  const handleRemoveFavorite = (productId: string, marketId: string) => {
    removeFavorite(userId, productId, marketId);
    loadFavorites();
    toast.success('Removed from favorites');
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-red-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-green-500" />;
    return null;
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Heart className="h-5 w-5 text-red-500 fill-red-500" />
          <h2 className="text-xl">My Favorite Products</h2>
          {favorites.length > 0 && (
            <Badge>{favorites.length}</Badge>
          )}
        </div>

        {favorites.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {favorites.map(favorite => {
              const product = products.find(p => p.id === favorite.productId);
              const market = markets.find(m => m.id === favorite.marketId);
              const priceInfo = priceData.find(
                p => p.productId === favorite.productId && p.marketId === favorite.marketId
              );

              return (
                <Card key={`${favorite.productId}-${favorite.marketId}`} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-lg">{product?.name}</h3>
                      <Badge variant="secondary" className="mt-1">
                        {product?.category}
                      </Badge>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-500"
                      onClick={() => handleRemoveFavorite(favorite.productId, favorite.marketId)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{market?.name}</span>
                    </div>

                    {priceInfo ? (
                      <>
                        <div className="flex items-baseline justify-between">
                          <span className="text-sm text-muted-foreground">Current Price</span>
                          <span className="text-xl font-semibold text-primary">
                            {priceInfo.current.toLocaleString()} RWF
                          </span>
                        </div>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">Average</p>
                              <p className="font-medium">{priceInfo.average.toLocaleString()} RWF</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Range</p>
                              <p className="font-medium">
                                {priceInfo.lowest.toLocaleString()} - {priceInfo.highest.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground">Trend</p>
                            <div className="flex items-center gap-1">
                              {getTrendIcon(priceInfo.trend)}
                              <span className="font-medium">
                                {priceInfo.trend === 'up' ? 'Rising' :
                                 priceInfo.trend === 'down' ? 'Falling' :
                                 'Stable'}
                              </span>
                            </div>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Last Updated</p>
                            <p className="font-medium">
                              {Math.round((Date.now() - priceInfo.lastUpdated.getTime()) / (1000 * 60 * 60))}h ago
                            </p>
                          </div>
                        </div>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground">No price data available</p>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Heart className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No favorite products yet</p>
            <p className="text-sm mt-2">Add products to favorites to track their prices easily</p>
          </div>
        )}
      </Card>
    </div>
  );
}
