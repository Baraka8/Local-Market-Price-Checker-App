import { useState } from 'react';
import { Card } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Button } from '../ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { products, priceData, markets } from '../../lib/mockData';

export default function PriceTrends() {
  const [selectedProduct, setSelectedProduct] = useState('p1');
  const [selectedMarket, setSelectedMarket] = useState('m1');
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  const productPrice = priceData.find(
    p => p.productId === selectedProduct && p.marketId === selectedMarket
  );
  const product = products.find(p => p.id === selectedProduct);
  const market = markets.find(m => m.id === selectedMarket);

  const getDaysFromRange = () => {
    if (timeRange === '7d') return 7;
    if (timeRange === '90d') return 90;
    return 30;
  };

  const chartData = productPrice?.history.slice(-getDaysFromRange()).map(item => ({
    date: new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    price: item.price
  })) || [];

  return (
    <div className="space-y-6">
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={selectedProduct} onValueChange={setSelectedProduct}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {products.map(product => (
                <SelectItem key={product.id} value={product.id}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedMarket} onValueChange={setSelectedMarket}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {markets.map(market => (
                <SelectItem key={market.id} value={market.id}>
                  {market.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex gap-2">
            <Button
              variant={timeRange === '7d' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeRange('7d')}
              className="flex-1"
            >
              7 Days
            </Button>
            <Button
              variant={timeRange === '30d' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeRange('30d')}
              className="flex-1"
            >
              30 Days
            </Button>
            <Button
              variant={timeRange === '90d' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeRange('90d')}
              className="flex-1"
            >
              90 Days
            </Button>
          </div>
        </div>
      </Card>

      {productPrice ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Current Price</p>
              <p className="text-2xl font-semibold text-primary">{productPrice.current.toLocaleString()} RWF</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Average Price</p>
              <p className="text-2xl font-semibold">{productPrice.average.toLocaleString()} RWF</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Highest</p>
              <p className="text-2xl font-semibold text-red-600">{productPrice.highest.toLocaleString()} RWF</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Lowest</p>
              <p className="text-2xl font-semibold text-green-600">{productPrice.lowest.toLocaleString()} RWF</p>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="text-lg mb-4">
              {product?.name} - {market?.name} ({timeRange} trend)
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </>
      ) : (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            No price trend data available for this selection
          </div>
        </Card>
      )}
    </div>
  );
}
