import { useState } from 'react';
import { Card } from '../ui/card';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Search, MapPin, Heart, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { products, markets, priceData, categories } from '../../lib/mockData';
import { getProvinceColor, getProvinceIcon, allProvinces } from '../../utils/provinceUtils';
import { useLanguage } from '../../contexts/LanguageContext';

export default function ProductSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedMarket, setSelectedMarket] = useState('all');
  const [selectedProvince, setSelectedProvince] = useState('all');
  const [favorites, setFavorites] = useState<string[]>([]);
  const { t } = useLanguage();

  const toggleFavorite = (productId: string) => {
    setFavorites(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getProductPrice = (productId: string, marketId: string) => {
    return priceData.find(p => p.productId === productId && p.marketId === marketId);
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-red-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-green-500" />;
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  // Filter markets by province
  const filteredMarkets = markets.filter(m => 
    selectedProvince === 'all' || m.province === selectedProvince
  );

  // Get province statistics
  const provinceStats = allProvinces.map(province => {
    const provinceMarkets = markets.filter(m => m.province === province);
    return {
      province,
      marketCount: provinceMarkets.length,
      vendorCount: provinceMarkets.reduce((sum, m) => sum + (m.vendorCount || 0), 0),
      colors: getProvinceColor(province)
    };
  });

  return (
    <div className="space-y-6">
      {/* Province Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {provinceStats.map(stat => (
          <Card 
            key={stat.province}
            className={`p-3 cursor-pointer transition-all ${
              selectedProvince === stat.province 
                ? `${stat.colors.bg} ${stat.colors.border} border-2 scale-105` 
                : 'hover:shadow-md'
            }`}
            onClick={() => setSelectedProvince(selectedProvince === stat.province ? 'all' : stat.province)}
          >
            <div className="text-center">
              <div className="text-2xl mb-1">{stat.colors.emoji}</div>
              <div className="text-xs font-medium mb-1 line-clamp-1">{stat.province.replace(' Province', '')}</div>
              <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <span>{stat.marketCount} markets</span>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Search and Filters */}
      <Card className="p-4">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search for products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Province</label>
              <Select value={selectedProvince} onValueChange={setSelectedProvince}>
                <SelectTrigger>
                  <SelectValue placeholder="All Provinces" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    <span className="flex items-center gap-2">
                      🗺️ All Provinces
                    </span>
                  </SelectItem>
                  {allProvinces.map(province => {
                    const colors = getProvinceColor(province);
                    return (
                      <SelectItem key={province} value={province}>
                        <span className="flex items-center gap-2">
                          {colors.emoji} {province}
                        </span>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Market</label>
              <Select value={selectedMarket} onValueChange={setSelectedMarket}>
                <SelectTrigger>
                  <SelectValue placeholder="All Markets" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Markets</SelectItem>
                  {markets
                    .filter(m => selectedProvince === 'all' || m.province === selectedProvince)
                    .map(market => {
                      const colors = getProvinceColor(market.province);
                      return (
                        <SelectItem key={market.id} value={market.id}>
                          <div className="flex items-center gap-2">
                            <span>{market.name}</span>
                            <Badge className={`${colors.badge} ${colors.badgeText} text-[10px] px-1.5 py-0`}>
                              {colors.emoji}
                            </Badge>
                          </div>
                        </SelectItem>
                      );
                    })}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </Card>

      {/* Results */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-muted-foreground">
            {filteredProducts.length} products found
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map(product => {
            const productPrices = priceData.filter(p => p.productId === product.id);
            const avgPrice = productPrices.length > 0
              ? productPrices.reduce((sum, p) => sum + p.current, 0) / productPrices.length
              : 0;
            const lowestPrice = productPrices.length > 0
              ? Math.min(...productPrices.map(p => p.current))
              : 0;

            return (
              <Card key={product.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-medium">{product.name}</h3>
                    <Badge variant="secondary" className="mt-1">
                      {product.category}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleFavorite(product.id)}
                    className="p-1"
                  >
                    <Heart
                      className={`h-5 w-5 ${
                        favorites.includes(product.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-gray-400'
                      }`}
                    />
                  </Button>
                </div>

                {productPrices.length > 0 ? (
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Average Price</p>
                      <p className="text-2xl font-semibold text-primary">
                        {Math.round(avgPrice).toLocaleString()} RWF
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <div>
                        <p className="text-muted-foreground">Lowest</p>
                        <p className="font-medium text-green-600">
                          {lowestPrice.toLocaleString()} RWF
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-muted-foreground">Markets</p>
                        <p className="font-medium">{productPrices.length}</p>
                      </div>
                    </div>

                    <div className="pt-2 border-t">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Price per {product.unit}</span>
                        <div className="flex items-center gap-1">
                          {getTrendIcon(productPrices[0].trend)}
                          <span className={`font-medium ${
                            productPrices[0].trend === 'up' ? 'text-red-600' :
                            productPrices[0].trend === 'down' ? 'text-green-600' :
                            'text-gray-600'
                          }`}>
                            {productPrices[0].trend === 'up' ? 'Rising' :
                             productPrices[0].trend === 'down' ? 'Falling' :
                             'Stable'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <Button variant="outline" size="sm" className="w-full mt-2">
                      <MapPin className="h-4 w-4 mr-2" />
                      Compare Markets
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-muted-foreground">No price data available</p>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <Card className="p-12">
            <div className="text-center text-muted-foreground">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No products found</p>
              <p className="text-sm mt-2">Try adjusting your search or filters</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}