import { useState } from 'react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { LogOut, TrendingUp, BarChart3, ShoppingCart, Download, User as UserIcon, ArrowLeft } from 'lucide-react';
import type { User } from '../../App';
import PriceAnalysis from './PriceAnalysis';
import ComparisonTools from './ComparisonTools';
import PurchasePlanning from './PurchasePlanning';
import BusinessAnalytics from './BusinessAnalytics';
import DataExport from './DataExport';
import UserProfile from '../shared/UserProfile';
import LanguageSwitcher from '../LanguageSwitcherVibrant';
import { useLanguage } from '../../contexts/LanguageContext';

interface BusinessDashboardProps {
  user: User;
  onLogout: () => void;
  isAdminViewing?: boolean;
  onReturnToAdmin?: () => void;
}

export default function BusinessDashboard({ user, onLogout, isAdminViewing, onReturnToAdmin }: BusinessDashboardProps) {
  const [activeTab, setActiveTab] = useState('analysis');
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 border-b sticky top-0 z-10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div>
              <h1 className="text-lg text-white">💼 {t('businessPortal')}</h1>
              <p className="text-sm text-emerald-100">{t('welcome')}, {user.name}</p>
            </div>
            <div className="flex items-center gap-2">
              <LanguageSwitcher />
              <Button variant="outline" size="sm" onClick={onLogout} className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <LogOut className="h-4 w-4 mr-2" />
                {t('logout')}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Admin Viewing Banner */}
        {isAdminViewing && onReturnToAdmin && (
          <div className="mb-6 bg-indigo-50 border border-indigo-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-indigo-700">👨‍💼 You are viewing the Business Dashboard as Admin</span>
              </div>
              <Button 
                onClick={onReturnToAdmin}
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Return to Admin Dashboard
              </Button>
            </div>
          </div>
        )}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="analysis">
              <TrendingUp className="h-4 w-4 mr-2" />
              {t('priceAnalysis')}
            </TabsTrigger>
            <TabsTrigger value="compare">
              <TrendingUp className="h-4 w-4 mr-2" />
              {t('comparePrices')}
            </TabsTrigger>
            <TabsTrigger value="purchase">
              <ShoppingCart className="h-4 w-4 mr-2" />
              {t('purchasePlanning')}
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="h-4 w-4 mr-2" />
              {t('businessAnalytics')}
            </TabsTrigger>
            <TabsTrigger value="export">
              <Download className="h-4 w-4 mr-2" />
              {t('dataExport')}
            </TabsTrigger>
            <TabsTrigger value="profile">
              <UserIcon className="h-4 w-4 mr-2" />
              {t('userProfile')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analysis">
            <PriceAnalysis />
          </TabsContent>

          <TabsContent value="compare">
            <ComparisonTools />
          </TabsContent>

          <TabsContent value="purchase">
            <PurchasePlanning />
          </TabsContent>

          <TabsContent value="analytics">
            <BusinessAnalytics />
          </TabsContent>

          <TabsContent value="export">
            <DataExport />
          </TabsContent>

          <TabsContent value="profile">
            <UserProfile user={user} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}