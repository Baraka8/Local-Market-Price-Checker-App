import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Mail, CheckCircle, RefreshCw, Loader2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { generateVerificationCode } from '../lib/emailValidation';
import { useLanguage } from '../contexts/LanguageContext';
import { sendVerificationEmailAPI } from '../lib/verificationAPI';

interface EmailVerificationProps {
  email: string;
  userName: string;
  verificationCode: string;
  onVerify: (code: string) => Promise<void>;
  onCancel: () => void;
}

export function EmailVerification({ 
  email, 
  userName, 
  verificationCode,
  onVerify,
  onCancel 
}: EmailVerificationProps) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(60); // 1 minute
  const { t } = useLanguage();

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVerify = async () => {
    if (!code || code.length !== 6) {
      toast.error('Please enter a valid 6-digit code');
      return;
    }

    setLoading(true);
    
    try {
      await onVerify(code);
    } catch (error) {
      toast.error('Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResending(true);
    
    try {
      const newCode = generateVerificationCode();
      const result = await sendVerificationEmailAPI(email, userName, newCode);
      
      if (result.success) {
        toast.success('Verification code resent! Check your email.');
        setTimeRemaining(60); // Reset to 1 minute
        setCode(''); // Clear input
      } else {
        if (result.demoMode) {
          toast.warning(result.message || 'Email service not configured. Running in demo mode.');
        } else {
          toast.error(result.message || 'Failed to resend code. Please try again.');
        }
      }
    } catch (error) {
      toast.error('Failed to resend code.');
    } finally {
      setResending(false);
    }
  };

  return (
    <Card className="p-8 max-w-md mx-auto">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Mail className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="mb-2">Verify Your Email</h2>
        <p className="text-sm text-muted-foreground">
          We've sent a verification code to
        </p>
        <p className="font-semibold text-blue-600 mt-1">{email}</p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="verificationCode">Verification Code</Label>
          <Input
            id="verificationCode"
            type="text"
            maxLength={6}
            placeholder="000000"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
            onKeyPress={(e) => e.key === 'Enter' && handleVerify()}
            className="text-center text-2xl tracking-widest mt-1.5"
            disabled={loading}
          />
          <p className="text-xs text-muted-foreground mt-1">
            Enter the 6-digit code from your email
          </p>
        </div>

        {/* Timer */}
        <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <span className="text-sm text-yellow-800">Code expires in:</span>
          <span className="font-semibold text-yellow-900">
            {formatTime(timeRemaining)}
          </span>
        </div>

        {/* Verify Button */}
        <Button 
          onClick={handleVerify} 
          disabled={loading || code.length !== 6}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              <CheckCircle className="h-4 w-4 mr-2" />
              Verify Email
            </>
          )}
        </Button>

        {/* Resend Button */}
        <Button
          variant="outline"
          onClick={handleResend}
          disabled={resending || timeRemaining > 30}
          className="w-full"
        >
          {resending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Resending...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Resend Code
            </>
          )}
        </Button>

        {timeRemaining > 30 && (
          <p className="text-xs text-muted-foreground text-center">
            You can resend the code after 30 seconds
          </p>
        )}

        {/* Cancel Button */}
        <Button
          variant="ghost"
          onClick={onCancel}
          className="w-full"
        >
          Cancel
        </Button>
      </div>

      {/* Help Text */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-blue-900 mb-2">
          <strong>Didn't receive the email?</strong>
        </p>
        <ul className="text-xs text-blue-800 space-y-1 ml-4">
          <li>• Check your spam/junk folder</li>
          <li>• Make sure the email address is correct</li>
          <li>• Wait a few minutes for delivery</li>
          <li>• Click "Resend Code" to try again</li>
        </ul>
      </div>
    </Card>
  );
}