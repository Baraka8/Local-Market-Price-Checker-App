import { Languages } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { useLanguage } from '../contexts/LanguageContext';
import { Language } from '../utils/translations';

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const languages: { 
    code: Language; 
    name: string; 
    flag: string;
    buttonClass: string;
    dropdownClass: string;
    badgeClass: string;
  }[] = [
    { 
      code: 'en', 
      name: 'English', 
      flag: '🇬🇧',
      buttonClass: 'bg-blue-500 text-white border-blue-600 hover:bg-blue-600',
      dropdownClass: 'bg-blue-100 text-blue-900 border-l-blue-500',
      badgeClass: 'bg-blue-600 text-white'
    },
    { 
      code: 'rw', 
      name: 'Kinyarwanda', 
      flag: '🇷🇼',
      buttonClass: 'bg-green-500 text-white border-green-600 hover:bg-green-600',
      dropdownClass: 'bg-green-100 text-green-900 border-l-green-500',
      badgeClass: 'bg-green-600 text-white'
    },
    { 
      code: 'fr', 
      name: 'Français', 
      flag: '🇫🇷',
      buttonClass: 'bg-red-500 text-white border-red-600 hover:bg-red-600',
      dropdownClass: 'bg-red-100 text-red-900 border-l-red-500',
      badgeClass: 'bg-red-600 text-white'
    },
  ];

  const currentLanguage = languages.find((l) => l.code === language);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          size="sm" 
          className={`
            ${currentLanguage?.buttonClass}
            border-2
            transition-all
            shadow-lg
            hover:shadow-xl
            hover:scale-105
            font-semibold
          `}
        >
          <Languages className="h-4 w-4 mr-2" />
          <span className="text-xl mr-2">{currentLanguage?.flag}</span>
          <span>{currentLanguage?.name}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 p-2">
        <div className="text-xs font-semibold text-gray-500 px-3 py-2 mb-1">
          Select Language
        </div>
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className={`
              cursor-pointer
              rounded-md
              mb-1
              transition-all
              py-3
              px-3
              ${language === lang.code 
                ? `${lang.dropdownClass} border-l-4 font-semibold` 
                : 'hover:bg-gray-100'
              }
            `}
          >
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{lang.flag}</span>
                <span className="font-medium">{lang.name}</span>
              </div>
              {language === lang.code && (
                <Badge className={`${lang.badgeClass} text-xs px-2 py-0.5`}>
                  Active
                </Badge>
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
