export interface Product {
  id: string;
  name: string;
  category: string;
  unit: string;
  image?: string;
}

export interface Market {
  id: string;
  name: string;
  location: string;
  district: string;
  province?: string;
  type?: 'public' | 'modern' | 'neighborhood';
  description?: string;
  operatingHours?: string;
  daysOpen?: string;
  phone?: string;
  popularProducts?: string[];
  rating?: number;
  vendorCount?: number;
}

export interface PriceSubmission {
  id: string;
  productId: string;
  marketId: string;
  vendorId: string;
  vendorName: string;
  price: number;
  quantity: number;
  unit: string;
  submittedAt: Date;
  status: 'pending' | 'approved' | 'rejected';
  ageInHours: number;
}

export interface PriceData {
  productId: string;
  marketId: string;
  current: number;
  average: number;
  highest: number;
  lowest: number;
  lastUpdated: Date;
  trend: 'up' | 'down' | 'stable';
  history: { date: Date; price: number }[];
  rating?: number; // Average rating
  totalRatings?: number;
  reviews?: PriceReview[];
}

export interface PriceReview {
  id: string;
  userId: string;
  userName: string;
  rating: number; // 1-5 stars
  comment?: string;
  createdAt: Date;
  helpful: number;
}

// Mock Categories
export const categories = [
  'Groceries',
  'Vegetables',
  'Fruits',
  'Meat & Fish',
  'Dairy',
  'Grains & Cereals',
  'Clothing',
  'Electronics',
  'Household Items',
  'Construction Materials',
  'Transportation Services',
  'Agricultural Supplies',
  'Hardware & Tools',
  'Personal Care',
  'Services'
];

// Mock Markets Data
export const markets: Market[] = [
  // KIGALI CITY - 3 Markets
  { 
    id: 'm1', 
    name: 'Kimironko Market', 
    location: 'Kimironko', 
    district: 'Gasabo', 
    province: 'Kigali City', 
    type: 'public', 
    description: 'Largest public market in Kigali with wide variety of fresh produce and goods', 
    operatingHours: '06:00 - 18:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788123456', 
    popularProducts: ['Rice (Local)', 'Tomatoes', 'Onions', 'Bananas'], 
    rating: 4.7, 
    vendorCount: 250 
  },
  { 
    id: 'm2', 
    name: 'Nyabugogo Market', 
    location: 'Nyabugogo', 
    district: 'Nyarugenge', 
    province: 'Kigali City', 
    type: 'modern', 
    description: 'Modern commercial market near taxi park with competitive prices', 
    operatingHours: '07:00 - 17:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788654321', 
    popularProducts: ['Rice (Imported)', 'Potatoes', 'Cooking Oil', 'Sugar'], 
    rating: 4.5, 
    vendorCount: 180 
  },
  { 
    id: 'm3', 
    name: 'Kimisagara Market', 
    location: 'Kimisagara', 
    district: 'Nyarugenge', 
    province: 'Kigali City', 
    type: 'neighborhood', 
    description: 'Neighborhood market serving local community with fresh daily produce', 
    operatingHours: '06:30 - 17:30', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788987654', 
    popularProducts: ['Beans', 'Carrots', 'Eggs', 'Cabbage'], 
    rating: 4.3, 
    vendorCount: 95 
  },
  
  // NORTHERN PROVINCE - 2 Markets
  { 
    id: 'm4', 
    name: 'Musanze Market', 
    location: 'Musanze Town', 
    district: 'Musanze', 
    province: 'Northern Province', 
    type: 'public', 
    description: 'Main market in Musanze serving the gateway to Volcanoes National Park', 
    operatingHours: '06:00 - 18:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788555666', 
    popularProducts: ['Potatoes', 'Beans', 'Carrots', 'Cabbage'], 
    rating: 4.6, 
    vendorCount: 140 
  },
  { 
    id: 'm5', 
    name: 'Gicumbi Market', 
    location: 'Byumba Town', 
    district: 'Gicumbi', 
    province: 'Northern Province', 
    type: 'public', 
    description: 'Main market in Byumba serving Gicumbi district communities', 
    operatingHours: '06:00 - 18:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788222444', 
    popularProducts: ['Rice (Local)', 'Beans', 'Cooking Oil', 'Salt'], 
    rating: 4.5, 
    vendorCount: 95 
  },
  
  // EASTERN PROVINCE - 2 Markets
  { 
    id: 'm6', 
    name: 'Kayonza Market', 
    location: 'Kayonza Town', 
    district: 'Kayonza', 
    province: 'Eastern Province', 
    type: 'public', 
    description: 'Strategic market on the Kigali-Uganda highway with cross-border trade',
    operatingHours: '06:00 - 19:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788555666', 
    popularProducts: ['Matooke (Plantains)', 'Rice (Imported)', 'Beans', 'Dried Fish'],
    rating: 4.3,
    vendorCount: 90
  },
  { 
    id: 'm7', 
    name: 'Rwamagana Market', 
    location: 'Rwamagana Town', 
    district: 'Rwamagana', 
    province: 'Eastern Province', 
    type: 'public', 
    description: 'Main market serving Eastern Province with diverse agricultural products',
    operatingHours: '06:00 - 18:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788444555', 
    popularProducts: ['Rice (Local)', 'Bananas', 'Sweet Potatoes', 'Cassava'],
    rating: 4.4,
    vendorCount: 105
  },
  
  // SOUTHERN PROVINCE - 2 Markets
  { 
    id: 'm8', 
    name: 'Muhanga Market', 
    location: 'Muhanga Town', 
    district: 'Muhanga', 
    province: 'Southern Province', 
    type: 'public', 
    description: 'Central market on the Kigali-Huye road with fresh produce',
    operatingHours: '06:00 - 17:30', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788888999', 
    popularProducts: ['Cassava', 'Beans', 'Matooke (Plantains)', 'Irish Potatoes'],
    rating: 4.3,
    vendorCount: 95
  },
  { 
    id: 'm9', 
    name: 'Huye Market', 
    location: 'Butare Town', 
    district: 'Huye', 
    province: 'Southern Province', 
    type: 'public', 
    description: 'Academic town market near University of Rwanda with quality products',
    operatingHours: '06:00 - 18:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788777888', 
    popularProducts: ['Sweet Potatoes', 'Beans', 'Bananas', 'Tea'],
    rating: 4.5,
    vendorCount: 120
  },
  
  // WESTERN PROVINCE - 2 Markets
  { 
    id: 'm10', 
    name: 'Rubavu Market', 
    location: 'Gisenyi', 
    district: 'Rubavu', 
    province: 'Western Province', 
    type: 'modern', 
    description: 'Border town market with cross-border trade and tourism',
    operatingHours: '06:00 - 19:00', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788333444', 
    popularProducts: ['Fish', 'Coffee', 'Tea', 'Imported Goods'],
    rating: 4.6,
    vendorCount: 150
  },
  { 
    id: 'm11', 
    name: 'Rusizi Market', 
    location: 'Kamembe', 
    district: 'Rusizi', 
    province: 'Western Province', 
    type: 'public', 
    description: 'Southern Lake Kivu market with tea, coffee, and agricultural products',
    operatingHours: '06:00 - 17:30', 
    daysOpen: 'Monday - Sunday', 
    phone: '+250788444555', 
    popularProducts: ['Tea', 'Coffee', 'Bananas', 'Cassava'],
    rating: 4.2,
    vendorCount: 75
  }
];

// Mock Products
export const products: Product[] = [
  { id: 'p1', name: 'Rice (Local)', category: 'Grains & Cereals', unit: 'kg' },
  { id: 'p2', name: 'Rice (Imported)', category: 'Grains & Cereals', unit: 'kg' },
  { id: 'p3', name: 'Beans', category: 'Grains & Cereals', unit: 'kg' },
  { id: 'p4', name: 'Tomatoes', category: 'Vegetables', unit: 'kg' },
  { id: 'p5', name: 'Onions', category: 'Vegetables', unit: 'kg' },
  { id: 'p6', name: 'Potatoes', category: 'Vegetables', unit: 'kg' },
  { id: 'p7', name: 'Cabbage', category: 'Vegetables', unit: 'piece' },
  { id: 'p8', name: 'Carrots', category: 'Vegetables', unit: 'kg' },
  { id: 'p9', name: 'Bananas', category: 'Fruits', unit: 'dozen' },
  { id: 'p10', name: 'Avocados', category: 'Fruits', unit: 'piece' },
  { id: 'p11', name: 'Oranges', category: 'Fruits', unit: 'kg' },
  { id: 'p12', name: 'Pineapple', category: 'Fruits', unit: 'piece' },
  { id: 'p13', name: 'Chicken (Whole)', category: 'Meat & Fish', unit: 'kg' },
  { id: 'p14', name: 'Beef', category: 'Meat & Fish', unit: 'kg' },
  { id: 'p15', name: 'Tilapia Fish', category: 'Meat & Fish', unit: 'kg' },
  { id: 'p16', name: 'Milk (Fresh)', category: 'Dairy', unit: 'liter' },
  { id: 'p17', name: 'Eggs', category: 'Dairy', unit: 'tray' },
  { id: 'p18', name: 'Cooking Oil', category: 'Groceries', unit: 'liter' },
  { id: 'p19', name: 'Sugar', category: 'Groceries', unit: 'kg' },
  { id: 'p20', name: 'Salt', category: 'Groceries', unit: 'kg' }
];

// Generate mock price submissions
export const priceSubmissions: PriceSubmission[] = [
  {
    id: 's1',
    productId: 'p1',
    marketId: 'm1',
    vendorId: 'v1',
    vendorName: 'Jean Claude',
    price: 1200,
    quantity: 1,
    unit: 'kg',
    submittedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 2
  },
  {
    id: 's2',
    productId: 'p4',
    marketId: 'm2',
    vendorId: 'v2',
    vendorName: 'Marie Claire',
    price: 800,
    quantity: 1,
    unit: 'kg',
    submittedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 5
  },
  {
    id: 's3',
    productId: 'p5',
    marketId: 'm1',
    vendorId: 'v3',
    vendorName: 'Patrick',
    price: 1500,
    quantity: 1,
    unit: 'kg',
    submittedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    status: 'approved',
    ageInHours: 1
  },
  {
    id: 's4',
    productId: 'p3',
    marketId: 'm3',
    vendorId: 'v4',
    vendorName: 'Diane Uwase',
    price: 1100,
    quantity: 1,
    unit: 'kg',
    submittedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 3
  },
  {
    id: 's5',
    productId: 'p9',
    marketId: 'm2',
    vendorId: 'v5',
    vendorName: 'Eric Niyonzima',
    price: 3000,
    quantity: 1,
    unit: 'dozen',
    submittedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 4
  },
  {
    id: 's6',
    productId: 'p13',
    marketId: 'm1',
    vendorId: 'v6',
    vendorName: 'Grace Mutesi',
    price: 5500,
    quantity: 1,
    unit: 'kg',
    submittedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 6
  },
  {
    id: 's7',
    productId: 'p18',
    marketId: 'm4',
    vendorId: 'v7',
    vendorName: 'Frank Habimana',
    price: 4200,
    quantity: 1,
    unit: 'liter',
    submittedAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
    status: 'pending',
    ageInHours: 8
  }
];

// Generate mock price data with history
export const generatePriceHistory = (basePrice: number, days: number = 30): { date: Date; price: number }[] => {
  const history: { date: Date; price: number }[] = [];
  const now = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Random variation ±15%
    const variation = (Math.random() - 0.5) * 0.3;
    const price = Math.round(basePrice * (1 + variation));
    
    history.push({ date, price });
  }
  
  return history;
};

// Mock price data
export const priceData: PriceData[] = [
  {
    productId: 'p1',
    marketId: 'm1',
    current: 1200,
    average: 1180,
    highest: 1300,
    lowest: 1100,
    lastUpdated: new Date(Date.now() - 2 * 60 * 60 * 1000),
    trend: 'up',
    history: generatePriceHistory(1200),
    rating: 4.5,
    totalRatings: 24,
    reviews: [
      {
        id: 'r1',
        userId: 'u1',
        userName: 'Alice K.',
        rating: 5,
        comment: 'Very accurate pricing, just bought from this market!',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        helpful: 12
      },
      {
        id: 'r2',
        userId: 'u2',
        userName: 'John M.',
        rating: 4,
        comment: 'Price was correct but quality varies.',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        helpful: 5
      }
    ]
  },
  {
    productId: 'p1',
    marketId: 'm2',
    current: 1150,
    average: 1160,
    highest: 1250,
    lowest: 1050,
    lastUpdated: new Date(Date.now() - 4 * 60 * 60 * 1000),
    trend: 'stable',
    history: generatePriceHistory(1150),
    rating: 4.2,
    totalRatings: 18
  },
  {
    productId: 'p4',
    marketId: 'm1',
    current: 850,
    average: 820,
    highest: 900,
    lowest: 750,
    lastUpdated: new Date(Date.now() - 6 * 60 * 60 * 1000),
    trend: 'up',
    history: generatePriceHistory(850),
    rating: 3.8,
    totalRatings: 15
  },
  {
    productId: 'p4',
    marketId: 'm2',
    current: 800,
    average: 810,
    highest: 880,
    lowest: 720,
    lastUpdated: new Date(Date.now() - 3 * 60 * 60 * 1000),
    trend: 'down',
    history: generatePriceHistory(800),
    rating: 4.7,
    totalRatings: 31
  },
  {
    productId: 'p5',
    marketId: 'm1',
    current: 1500,
    average: 1450,
    highest: 1600,
    lowest: 1350,
    lastUpdated: new Date(Date.now() - 1 * 60 * 60 * 1000),
    trend: 'up',
    history: generatePriceHistory(1500),
    rating: 4.9,
    totalRatings: 42
  }
];

// Analytics data
export const analyticsData = {
  totalProducts: products.length,
  totalMarkets: markets.length,
  totalUsers: 1247,
  activeVendors: 89,
  pendingApprovals: 12,
  priceUpdatesToday: 156,
  popularProducts: [
    { name: 'Rice (Local)', searches: 342 },
    { name: 'Tomatoes', searches: 298 },
    { name: 'Onions', searches: 267 },
    { name: 'Cooking Oil', searches: 234 },
    { name: 'Beans', searches: 201 }
  ],
  activeMarkets: [
    { name: 'Kimironko Market', submissions: 45 },
    { name: 'Nyabugogo Market', submissions: 38 },
    { name: 'Musanze Central Market', submissions: 34 },
    { name: 'Kimisagara Market', submissions: 32 },
    { name: 'Remera Market', submissions: 28 },
    { name: 'Ruhengeri Market', submissions: 25 }
  ],
  priceChangeAlerts: [
    { product: 'Rice (Local)', market: 'Kimironko', change: '+8%', type: 'increase' },
    { product: 'Tomatoes', market: 'Nyabugogo', change: '-12%', type: 'decrease' },
    { product: 'Potatoes', market: 'Musanze Central', change: '-5%', type: 'decrease' },
    { product: 'Cooking Oil', market: 'Remera', change: '+5%', type: 'increase' }
  ]
};