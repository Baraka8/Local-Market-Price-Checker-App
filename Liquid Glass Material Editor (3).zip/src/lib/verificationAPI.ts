// API functions for sending verification codes
const API_BASE_URL = 'https://dqwmpwonmadaxevjghkk.supabase.co/functions/v1/make-server-b7f3babf';

interface SendEmailResponse {
  success: boolean;
  message?: string;
  demoMode?: boolean;
  error?: string;
}

interface SendSMSResponse {
  success: boolean;
  message?: string;
  demoMode?: boolean;
  error?: string;
}

/**
 * Send verification email via API
 */
export async function sendVerificationEmailAPI(
  email: string,
  userName: string,
  verificationCode: string
): Promise<SendEmailResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/send-verification-email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        userName,
        verificationCode,
      }),
    });

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.error('Error calling verification email API:', error);
    return {
      success: false,
      error: error.message || 'Failed to send verification email',
      demoMode: true,
    };
  }
}

/**
 * Send verification SMS via API
 */
export async function sendVerificationSMSAPI(
  phone: string,
  userName: string,
  verificationCode: string
): Promise<SendSMSResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/send-verification-sms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone,
        userName,
        verificationCode,
      }),
    });

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.error('Error calling verification SMS API:', error);
    return {
      success: false,
      error: error.message || 'Failed to send verification SMS',
      demoMode: true,
    };
  }
}

/**
 * Send 2FA SMS via API
 */
export async function send2FASMSAPI(
  phone: string,
  userName: string,
  verificationCode: string
): Promise<SendSMSResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/send-2fa-sms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone,
        userName,
        verificationCode,
      }),
    });

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.error('Error calling 2FA SMS API:', error);
    return {
      success: false,
      error: error.message || 'Failed to send 2FA SMS',
      demoMode: true,
    };
  }
}

/**
 * Send password reset SMS via API
 */
export async function sendPasswordResetSMSAPI(
  phone: string,
  userName: string,
  verificationCode: string
): Promise<SendSMSResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/send-password-reset-sms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone,
        userName,
        verificationCode,
      }),
    });

    const data = await response.json();
    return data;
  } catch (error: any) {
    console.error('Error calling password reset SMS API:', error);
    return {
      success: false,
      error: error.message || 'Failed to send password reset SMS',
      demoMode: true,
    };
  }
}
