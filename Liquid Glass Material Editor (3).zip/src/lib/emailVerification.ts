// Email Verification System

export interface VerificationEmail {
  to: string;
  subject: string;
  code: string;
  userName: string;
  expiresAt: Date;
}

export interface VerificationRecord {
  email: string;
  code: string;
  createdAt: Date;
  expiresAt: Date;
  attempts: number;
  verified: boolean;
}

// In-memory storage for demo (in production, use database)
const verificationCodes = new Map<string, VerificationRecord>();

/**
 * Send verification email
 */
export async function sendVerificationEmail(
  email: string,
  userName: string,
  code: string
): Promise<boolean> {
  try {
    // In production, integrate with email service (SendGrid, AWS SES, etc.)
    console.log('📧 Sending verification email to:', email);
    console.log('Verification Code:', code);
    
    // Store verification record
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 1); // Expires in 1 minute
    
    verificationCodes.set(email, {
      email,
      code,
      createdAt: new Date(),
      expiresAt,
      attempts: 0,
      verified: false
    });
    
    // Simulate email sending
    // In production, call actual email service API
    await simulateEmailSending(email, userName, code);
    
    return true;
  } catch (error) {
    console.error('Failed to send verification email:', error);
    return false;
  }
}

/**
 * Simulate email sending (for demo)
 */
async function simulateEmailSending(
  email: string,
  userName: string,
  code: string
): Promise<void> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Log email content (in production, this would be actual email)
  const emailContent = `
    ═══════════════════════════════════════════════
    🇷🇼 Rwanda Market Price Checker
    ═══════════════════════════════════════════════
    
    Hello ${userName}!
    
    Welcome to Rwanda Market Price Checker! 
    
    Your verification code is:
    
    ╔═══════════════╗
    ║               ║
    ║     ${code}     ║
    ║               ║
    ╚═══════════════╝
    
    This code will expire in 1 minute.
    
    If you didn't create this account, please ignore this email.
    
    Best regards,
    Rwanda Market Price Checker Team
    
    ═══════════════════════════════════════════════
  `;
  
  console.log(emailContent);
  
  // In production, replace with actual email service:
  /*
  await emailService.send({
    to: email,
    subject: 'Verify Your Email - Rwanda Market Price Checker',
    html: getVerificationEmailTemplate(userName, code),
    text: emailContent
  });
  */
}

/**
 * Verify email code
 */
export function verifyEmailCode(email: string, code: string): {
  success: boolean;
  message: string;
} {
  const record = verificationCodes.get(email);
  
  if (!record) {
    return {
      success: false,
      message: 'No verification code found for this email'
    };
  }
  
  // Check if already verified
  if (record.verified) {
    return {
      success: false,
      message: 'Email already verified'
    };
  }
  
  // Check if expired
  if (new Date() > record.expiresAt) {
    return {
      success: false,
      message: 'Verification code has expired. Please request a new one.'
    };
  }
  
  // Check attempts
  if (record.attempts >= 3) {
    return {
      success: false,
      message: 'Too many failed attempts. Please request a new code.'
    };
  }
  
  // Increment attempts
  record.attempts++;
  
  // Verify code
  if (record.code === code) {
    record.verified = true;
    return {
      success: true,
      message: 'Email verified successfully!'
    };
  }
  
  return {
    success: false,
    message: `Invalid verification code. ${3 - record.attempts} attempts remaining.`
  };
}

/**
 * Resend verification code
 */
export async function resendVerificationCode(
  email: string,
  userName: string,
  newCode: string
): Promise<boolean> {
  // Delete old record
  verificationCodes.delete(email);
  
  // Send new code
  return await sendVerificationEmail(email, userName, newCode);
}

/**
 * Check if email is verified
 */
export function isEmailVerified(email: string): boolean {
  const record = verificationCodes.get(email);
  return record?.verified ?? false;
}

/**
 * Get verification status
 */
export function getVerificationStatus(email: string): {
  exists: boolean;
  verified: boolean;
  expiresAt?: Date;
  attemptsRemaining?: number;
} {
  const record = verificationCodes.get(email);
  
  if (!record) {
    return { exists: false, verified: false };
  }
  
  return {
    exists: true,
    verified: record.verified,
    expiresAt: record.expiresAt,
    attemptsRemaining: 3 - record.attempts
  };
}

/**
 * Clean up expired codes
 */
export function cleanupExpiredCodes(): void {
  const now = new Date();
  
  for (const [email, record] of verificationCodes.entries()) {
    if (now > record.expiresAt && !record.verified) {
      verificationCodes.delete(email);
    }
  }
}

// Run cleanup every 5 minutes
setInterval(cleanupExpiredCodes, 5 * 60 * 1000);

/**
 * HTML Email Template
 */
export function getVerificationEmailTemplate(userName: string, code: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verify Your Email</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background-color: #f3f4f6;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 40px auto;
      background-color: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
      text-align: center;
      color: white;
    }
    .header h1 {
      margin: 0;
      font-size: 28px;
    }
    .content {
      padding: 40px 30px;
    }
    .code-box {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      font-size: 32px;
      font-weight: bold;
      letter-spacing: 8px;
      text-align: center;
      padding: 30px;
      border-radius: 8px;
      margin: 30px 0;
    }
    .info {
      background-color: #fef3c7;
      border-left: 4px solid #f59e0b;
      padding: 15px;
      margin: 20px 0;
      border-radius: 4px;
    }
    .footer {
      background-color: #f9fafb;
      padding: 20px;
      text-align: center;
      color: #6b7280;
      font-size: 14px;
    }
    .button {
      display: inline-block;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 12px 30px;
      text-decoration: none;
      border-radius: 6px;
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🇷🇼 Rwanda Market Price Checker</h1>
      <p>Email Verification</p>
    </div>
    <div class="content">
      <h2>Hello ${userName}!</h2>
      <p>Welcome to Rwanda Market Price Checker! We're excited to have you on board.</p>
      <p>Please use the verification code below to complete your registration:</p>
      
      <div class="code-box">
        ${code}
      </div>
      
      <div class="info">
        <strong>⚠️ Important:</strong><br>
        • This code expires in 1 minute<br>
        • Don't share this code with anyone<br>
        • If you didn't create this account, please ignore this email
      </div>
      
      <p>Once verified, you'll be able to:</p>
      <ul>
        <li>✅ Compare prices across Rwanda's markets</li>
        <li>✅ Get real-time price updates</li>
        <li>✅ Set price alerts</li>
        <li>✅ Create shopping lists</li>
        <li>✅ Access market insights</li>
      </ul>
      
      <p>If you have any questions, feel free to reply to this email.</p>
      
      <p>Best regards,<br>
      <strong>Rwanda Market Price Checker Team</strong></p>
    </div>
    <div class="footer">
      <p>© 2024 Rwanda Market Price Checker. All rights reserved.</p>
      <p>Kigali, Rwanda</p>
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Send welcome email after verification
 */
export async function sendWelcomeEmail(email: string, userName: string): Promise<void> {
  console.log(`📧 Sending welcome email to ${userName} <${email}>`);
  
  const welcomeMessage = `
    ═══════════════════════════════════════════════
    🎉 Welcome to Rwanda Market Price Checker! 🎉
    ═══════════════════════════════════════════════
    
    Hello ${userName}!
    
    Your email has been verified successfully!
    
    You can now access all features:
    ✅ Real-time price comparison
    ✅ Market insights and analytics
    ✅ Price alerts and notifications
    ✅ Shopping list planning
    ✅ Offline functionality
    
    Get started: Log in to your account
    
    Need help? Contact our support team
    
    Happy shopping!
    
    Best regards,
    Rwanda Market Price Checker Team
    ═══════════════════════════════════════════════
  `;
  
  console.log(welcomeMessage);
}