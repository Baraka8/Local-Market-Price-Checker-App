# How to Fix Missing Product Prices

## Problem
Some products don't have price data available in the system yet. This guide explains all the ways users can help populate missing prices.

---

## Solutions for Different User Roles

### 🛍️ **For Consumers**

When you select a product with no prices, you'll see a helpful empty state screen with three options:

#### **Option 1: Submit a Price Yourself** ➕
- Click **"Submit a Price"** button
- You'll be redirected to the "Submit Price" tab
- Fill in:
  - Product you're submitting for
  - Market where you found it
  - Current price
  - Your contact info (optional)
- Submit for admin approval
- **This uses the consumer crowdsourcing feature!**

#### **Option 2: Request from Vendors** 📍
- Click **"Request from Vendors"**
- System notifies all vendors about this product request
- Vendors will be encouraged to add prices
- You'll get notified when prices become available

#### **Option 3: Set Price Alert** 🔔
- Click **"Set Price Alert"**
- You'll receive notifications when:
  - Vendors add new prices for this product
  - Prices are approved by admin
  - The product becomes available in new markets

---

### 🏪 **For Vendors**

You can add prices for any product in the system:

#### **How to Add Prices:**
1. Login as Vendor
2. Go to **"Submit Price"** tab
3. Fill in the form:
   - **Category**: Select product category (e.g., Vegetables)
   - **Product**: Choose the product (e.g., Carrots, Pineapple)
   - **Market Location**: Your market (e.g., Kimironko Market)
   - **Price**: Current selling price in RWF
   - **Quantity**: Amount (default is 1)
4. Click **"Submit Price"**
5. Wait for admin approval

#### **Best Practices:**
- ✅ Submit accurate, current prices only
- ✅ Update prices when they change
- ✅ Submit for all products you sell
- ✅ Keep submissions fresh (update every 24-48 hours)
- ❌ Don't submit outdated prices
- ❌ Don't inflate prices artificially

---

### ⚙️ **For Admins**

Admins can actively manage missing price issues:

#### **Encourage Vendors:**
1. Check **Analytics** tab to see which products have no data
2. Send notifications to vendors requesting specific products
3. Monitor **Price Approvals** for new submissions
4. Approve quality submissions quickly

#### **Add Products:**
1. Go to **Categories** tab
2. Ensure all relevant products are in the system
3. Add new products as needed

#### **Quality Control:**
- Approve accurate, fresh prices
- Reject outdated or suspicious submissions
- Monitor price trends and flag anomalies

---

## Current Mock Data Coverage

### ✅ **Products WITH Price Data:**
- Rice (Local) - 2 markets
- Tomatoes - 2 markets  
- Onions - 1 market

### ❌ **Products WITHOUT Price Data:**
All other products in the catalog (17 products) including:
- Rice (Imported)
- Beans
- Potatoes
- Cabbage
- Carrots
- Bananas
- Avocados
- Oranges
- Pineapple
- Chicken
- Beef
- Fish
- Milk
- Eggs
- Cooking Oil
- Sugar
- Salt

**These are perfect for testing the missing price flow!**

---

## How to Test Missing Prices

### **Test Scenario 1: Consumer Sees Missing Price**
1. Login as **Consumer**
2. Go to **"Price Comparison"** tab
3. Select a product without data (e.g., **"Bananas"**)
4. You'll see the new empty state with 3 options:
   - Submit a Price
   - Request from Vendors
   - Set Price Alert

### **Test Scenario 2: Consumer Submits Price**
1. From empty state, click **"Submit a Price"**
2. OR go to **"Submit Price"** tab directly
3. Fill in:
   - Product: Bananas
   - Market: Kimironko Market
   - Price: 3500
   - Unit: dozen
4. Submit → Admin receives notification

### **Test Scenario 3: Vendor Adds Missing Price**
1. Login as **Vendor**
2. Go to **"Submit Price"** tab
3. Select: Fruits → Bananas → Nyabugogo Market
4. Price: 3200, Quantity: 1
5. Submit → Notification sent to admin

### **Test Scenario 4: Admin Approves**
1. Login as **Admin**
2. Check **"Price Approvals"** tab
3. You'll see the Bananas submission
4. Review and click **"Approve"**
5. Now consumers can see the price!

### **Test Scenario 5: Full Flow**
1. **Consumer** requests prices for Avocados
2. **Vendor** receives notification
3. **Vendor** submits price for Avocados
4. **Admin** approves the submission
5. **Consumer** gets alert notification
6. **Consumer** can now compare Avocado prices!

---

## Adding More Mock Prices

If you want to add more initial price data for testing, edit `/lib/mockData.ts`:

```typescript
// In the priceData array, add new entries:
{
  productId: 'p9', // Bananas
  marketId: 'm1', // Kimironko Market
  current: 3500,
  average: 3400,
  highest: 3800,
  lowest: 3200,
  lastUpdated: new Date(Date.now() - 2 * 60 * 60 * 1000),
  trend: 'stable',
  history: generatePriceHistory(3500),
  rating: 4.3,
  totalRatings: 12
}
```

---

## Features of the New Empty State

### **Visual Design:**
- 🎨 Gradient background (blue to purple)
- ⚠️ Warning icon in colored circle
- 📝 Clear explanation of the issue
- 🎯 Three actionable cards with icons

### **User Actions:**
1. **Submit a Price** (Blue card)
   - Direct link to submission form
   - Encourages community participation

2. **Request from Vendors** (Purple card)
   - Notifies vendors about demand
   - Creates awareness of missing products

3. **Set Price Alert** (Green card)
   - Passive solution
   - User gets notified when data arrives

### **Helpful Tip:**
- Bottom section with suggestion to browse other products
- Explains that vendors continuously update prices

---

## Benefits

✅ **No Dead Ends**: Users always have options when prices are missing  
✅ **Crowdsourcing**: Consumers can contribute price data  
✅ **Vendor Engagement**: Vendors get notified about demand  
✅ **Data Growth**: System naturally accumulates more prices over time  
✅ **User Retention**: Users don't leave frustrated, they take action  
✅ **Quality Data**: Admin approval ensures accuracy  

---

## Future Enhancements

Consider adding:
- Price prediction based on similar products
- Historical averages from archived data
- Regional price estimates
- Seasonal price patterns
- Bulk import tools for admins/vendors
- API integration with external price sources
- Machine learning for anomaly detection
