import { useState, useEffect } from 'react';
import { Toaster } from './components/ui/sonner';
import { LanguageProvider } from './contexts/LanguageContext';
import LoginPage from './components/LoginPage';
import AdminDashboard from './components/admin/AdminDashboard';
import ConsumerDashboard from './components/consumer/ConsumerDashboard';
import VendorDashboard from './components/vendor/VendorDashboard';
import BusinessDashboard from './components/business/BusinessDashboard';
import { supabase, getProfile } from './lib/api';
import { Loader2 } from 'lucide-react';

export type UserRole = 'admin' | 'consumer' | 'vendor' | 'business';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  read: boolean;
  userId: string;
  userRole: UserRole;
  relatedId?: string;
}

// Global notifications state (in real app, this would be in a global state manager or backend)
export const globalNotifications: Notification[] = [];

// Global price submissions state (in real app, this would be in a database)
export const globalPriceSubmissions: any[] = [];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [viewAsRole, setViewAsRole] = useState<UserRole | null>(null); // For admin role switching

  useEffect(() => {
    // Check for existing session on mount
    checkSession();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        try {
          const profile = await getProfile();
          setUser({
            id: profile.id,
            name: profile.name,
            email: profile.email,
            role: profile.role,
          });
        } catch (error) {
          console.error('Error loading profile:', error);
          setUser(null);
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setViewAsRole(null); // Reset view when logging out
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const checkSession = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        const profile = await getProfile();
        setUser({
          id: profile.id,
          name: profile.name,
          email: profile.email,
          role: profile.role,
        });
      }
    } catch (error) {
      console.error('Session check error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
    setViewAsRole(null); // Reset view when logging in
  };

  const handleLogout = async () => {
    try {
      const { signOut } = await import('./lib/api');
      await signOut();
      setUser(null);
      setViewAsRole(null); // Reset view when logging out
    } catch (error) {
      console.error('Logout error:', error);
      setUser(null);
      setViewAsRole(null);
    }
  };

  // Handle role view switching (admin only)
  const handleViewAsRole = (role: UserRole) => {
    if (user?.role === 'admin') {
      setViewAsRole(role);
    }
  };

  const handleReturnToAdminView = () => {
    setViewAsRole(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 text-white animate-spin mx-auto mb-4" />
          <p className="text-white text-lg">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <LanguageProvider>
        <LoginPage onLogin={handleLogin} />
        <Toaster />
      </LanguageProvider>
    );
  }

  // Determine which dashboard to show
  const activeRole = user.role === 'admin' && viewAsRole ? viewAsRole : user.role;

  return (
    <LanguageProvider>
      {user.role === 'admin' && !viewAsRole && (
        <AdminDashboard 
          user={user} 
          onLogout={handleLogout} 
          onViewAsRole={handleViewAsRole}
        />
      )}
      {activeRole === 'consumer' && (
        <ConsumerDashboard 
          user={user} 
          onLogout={handleLogout}
          isAdminViewing={user.role === 'admin'}
          onReturnToAdmin={user.role === 'admin' ? handleReturnToAdminView : undefined}
        />
      )}
      {activeRole === 'vendor' && (
        <VendorDashboard 
          user={user} 
          onLogout={handleLogout}
          isAdminViewing={user.role === 'admin'}
          onReturnToAdmin={user.role === 'admin' ? handleReturnToAdminView : undefined}
        />
      )}
      {activeRole === 'business' && (
        <BusinessDashboard 
          user={user} 
          onLogout={handleLogout}
          isAdminViewing={user.role === 'admin'}
          onReturnToAdmin={user.role === 'admin' ? handleReturnToAdminView : undefined}
        />
      )}
      <Toaster />
    </LanguageProvider>
  );
}